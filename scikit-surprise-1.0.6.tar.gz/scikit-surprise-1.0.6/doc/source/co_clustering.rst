.. _pred_package_co_clustering:

Co-clustering
-------------

.. autoclass:: surprise.prediction_algorithms.co_clustering.CoClustering
    :show-inheritance:

