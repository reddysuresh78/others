var symbols = require('./symbols');
var recommender = require('./getall');
var fs = require("fs");
var elements = {};
var monitor = "";
var monitorElements = [];

const TelegramBot = require('node-telegram-bot-api');
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });

async function process() {
 
    var chatId;// = msg.chat.id;
    chatId = 378345990;

    var dateObj = new Date();
    var forDate = dateObj.getUTCDate() ;
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();

    var dateStr = forDate + "-" + forMonth + "-" + forYear;

    monitor = fs.readFileSync(__dirname + "/" + "ALL_MONITOR.csv");

    elements = await symbols.getAllSymbols();

    elementsArray = monitor.toString().split(" ");
    for (var i = 0; i < elementsArray.length - 1; i++) {
        console.log(elementsArray[i]);
        monitorElements.push(elements[elementsArray[i]]);
    }

    // console.log(monitorElements);
    await recommender.getAllRecommendations(forDate, forMonth, forYear, monitorElements, true, 
        
        function(monitorData){

            newStocks = processMonitorStocks(monitorData);
            prevStocks = getPrevStocks();
        
            finalRec = [];
            for (i = 0; i < newStocks.length; i++) {
                var existingRec = prevStocks[newStocks[i].name];
         
                if (existingRec) {
                    if (existingRec.rec != newStocks[i].rec) {
                        finalRec.push(newStocks[i]);
                        prevStocks[newStocks[i].name] = newStocks[i];
                    }
                } else {
                    
                    finalRec.push(newStocks[i]);
                    prevStocks[newStocks[i].name] = newStocks[i];
                }
            }
        
            console.log("Final recomendations: " , finalRec);
        
            for(var i =0; i< finalRec.length; i++) { 
                bot.sendMessage(chatId, finalRec[i].message,  { parse_mode: "HTML" });
            }
            saveToPrevStocks(prevStocks);
 
        });

    
 
}

function saveToPrevStocks(contents) {
    var dateObj = new Date();
    var forDate = dateObj.getUTCDate();
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();

    var dateStr = forDate + "-" + forMonth + "-" + forYear;
    var filePath = __dirname + "/" + dateStr + "_REC.txt"
    fs.writeFileSync(filePath, JSON.stringify(contents));

}

function getPrevStocks() {
    var dateObj = new Date();
    var forDate = dateObj.getUTCDate();
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();
    var dateStr = forDate + "-" + forMonth + "-" + forYear;
    var filePath = __dirname + "/" + dateStr + "_REC.txt"
    var elementsMap = {}

    if (fs.existsSync(filePath)) {
        prevStocks = fs.readFileSync(filePath);
        if (prevStocks) {
            elementsMap = JSON.parse(prevStocks);
        }
    }

    return elementsMap;
}

function getChartString(data, nolink) {
    var finalString = "";

    var dateObj = new Date();
    var forDate = dateObj.getUTCDate();
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();

    var dateStr = forDate + "-" + forMonth + "-" + forYear;

    finalString = "<b>" + data.stockname + ":</b>" + data.rating + " " + dateStr + " DIFF: " + data.diff;
    finalString = finalString + "\nDRS: " + data.defaultResistence + " " + data.defaultSupport;
    finalString = finalString + "\nTRHL: " + data.trendReversalHigh + " " + data.trendReversalLow;
    // finalString = finalString + "\nFC: " + data.firstCandleHigh + "-" + data.firstCandleLow + "=" + data.diff;
    finalString = finalString + "\nBT: " + data.buyTarget1 + " " + data.buyTarget2 + " " + data.buyTarget3;
    finalString = finalString + "\nST: " + data.sellTarget1 + " " + data.sellTarget2 + " " + data.sellTarget3;
    // finalString = finalString + "\nCC: " + data.firstCandleClose + " " + data.secondCandleClose + " " + data.thirdCandleClose;
    finalString = finalString + "\nIHL: " + data.todayHigh + " " + data.todayLow;
    finalString = finalString + "\n<a href='" + data.link + "'>CHART</a> " + "\n\n";

    return finalString;

}

function processMonitorStocks(recommendations) {
    var chatId;// = msg.chat.id;
    chatId = 378345990;
    var monitorStocks = [];
    //Now, we have all the data. Let us try to find out if any stocks are in buy zone or sell zone. 
    for (var k = 0; k < recommendations.length; k++) {

        console.log('Analyzing: ' + recommendations[k].stockname);
        var todayData = recommendations[k].todayjson.data;

        //between 10:00 and 10:15, don't process anything
        if (todayData.candles.length >= 9 && todayData.candles.length < 12) {
            saveToPrevStocks({}); //Also clear existing stuff so that we can only base recommendation on TR
            console.log("Nothing to monitor now.");
            //Nothing to monitor yet. 
            break;
        }

        var latestSupport = recommendations[k].defaultSupport;
        var latestResistance = recommendations[k].defaultResistence;

        if(todayData.candles.length > 9) { 
            latestSupport = recommendations[k].trendReversalLow;
            latestResistance = recommendations[k].trendReversalHigh;
        }

        console.log('Resistance/Support: ' + latestResistance + "/" + latestSupport);
 
        var intradayHigh = recommendations[k].todayHigh;
        var intradayLow = recommendations[k].todayLow;

        var buyStars = "";

        if (intradayHigh < recommendations[k].buyTarget1) {
            buyStars = "***";
        } else if (intradayHigh < recommendations[k].buyTarget2) {
            buyStars = "**";
        } else if (intradayHigh < recommendations[k].buyTarget3) {
            buyStars = "*";
        }
        var sellStars = "";
        if (intradayLow > recommendations[k].sellTarget1) {
            sellStars = "***";
        } else if (intradayLow > recommendations[k].sellTarget2) {
            sellStars = "**";
        } else if (intradayLow > recommendations[k].sellTarget3) {
            sellStars = "*";
        }

        var startIndex =   todayData.candles.length - 4;

      
        var sellNow = false;
        var buyNow = false;
        var strongSell = false;
        var strongBuy = false;
 
        if (todayData.candles[startIndex][3] > latestSupport && todayData.candles[startIndex][2] < latestResistance) {
            continue;
        }

        //This cannot be if else as first candle can hit bot high and low at the same time though it is rare

 

        //Check if first candle low is below support  
        if (todayData.candles[startIndex][3] <= latestSupport) {
            //next 2 candles should close below support
            if (todayData.candles[startIndex + 1][4] < latestSupport &&
                todayData.candles[startIndex + 2][4] < latestSupport &&
                //Also next 2 candles high also should not touch support 
                todayData.candles[startIndex + 1][2] < latestSupport &&
                todayData.candles[startIndex + 2][2] < latestSupport &&
                //Both candles should close below first candle close
                todayData.candles[startIndex + 1][4] < todayData.candles[startIndex][4] &&
                todayData.candles[startIndex + 2][4] < todayData.candles[startIndex + 1][4]
            ) {
                sellNow = true;
                strongSell = true;
            } else if (todayData.candles[startIndex + 1][2] > latestSupport && //second candle high should be above support and 3rd candle should close above support
                todayData.candles[startIndex + 2][4] > latestSupport &&
                //Also next 2 candles low also should not touch support 
                // todayData.candles[startIndex + 1][3] > latestSupport &&
                // todayData.candles[startIndex + 2][3] > latestSupport &&
                //Both candles should close above first candle close
                todayData.candles[startIndex + 1][4] > todayData.candles[startIndex][4] &&
                todayData.candles[startIndex + 2][4] > todayData.candles[startIndex + 1][4]
            ) {
                buyNow = true; //Commented to avoid many tips
            }
        }

        //Check if first candle high is above resistance
        if (todayData.candles[startIndex][2] >= latestResistance) {
            if (todayData.candles[startIndex + 1][4] > latestResistance &&
                todayData.candles[startIndex + 2][4] > latestResistance &&
                //Also next 2 candles low also should not touch resistance
                todayData.candles[startIndex + 1][3] > latestResistance &&
                todayData.candles[startIndex + 2][3] > latestResistance &&
                //Both candles should close above first candle close
                todayData.candles[startIndex + 1][4] > todayData.candles[startIndex][4] &&
                todayData.candles[startIndex + 2][4] > todayData.candles[startIndex + 1][4]
            ) {
                buyNow = true;
                strongBuy = true;
            } else if (todayData.candles[startIndex + 1][3] < latestResistance && //second candle low should be below support and 3rd candle should close below support
                todayData.candles[startIndex + 2][4] < latestResistance &&
                //Also next 2 candles high also should not touch resistance
                // todayData.candles[startIndex + 1][2] < latestResistance &&
                // todayData.candles[startIndex + 2][2] < latestResistance &&
                //Both candles should close below first candle close
                todayData.candles[startIndex + 1][4] < todayData.candles[startIndex][4] &&
                todayData.candles[startIndex + 2][4] < todayData.candles[startIndex + 1][4]
            ) {
                sellNow = true;  //Commented to avoid many tips
            }

        }
        //1-OPEN 2-HIGH 3-LOW 4-CLOSE
        var cmp = todayData.candles[startIndex + 2][4];

        console.log('sellnow/buynow: ' + sellNow + "/" + buyNow);

        if (buyNow) {
            var buyRecommendation = getChartString(recommendations[k], true);
            var message = buyRecommendation + " " + buyStars +  (strongBuy ? "S." :"") + " BUY, CMP " + cmp + " with targets ";
            if(buyStars.length >= 3) { 
                message = message + recommendations[k].buyTarget1 + " " ;
            }
            if(buyStars.length >= 2) { 
                message = message + recommendations[k].buyTarget2 + " " ;
            }
            if(buyStars.length >= 1) { 
                message = message + recommendations[k].buyTarget3 + " " ;
            }
             // bot.sendMessage(chatId, message,  { parse_mode: "HTML" });

            if(buyStars.length >0 ) { 
                monitorStocks.push({ "name": recommendations[k].stockname, "rec": "BUY", "message": message });
            }
            
        } else if (sellNow) {

            var sellRecommendation = getChartString(recommendations[k], true);
            var message = sellRecommendation + " " + sellStars + (strongSell ? "S." :"") + " SELL, CMP " + cmp + " with targets ";
            if(sellStars.length >= 3) {
                message = message + recommendations[k].sellTarget1 + " ";  
            } 
            if(sellStars.length >= 2) {
                message = message + recommendations[k].sellTarget2 + " ";  
            } 
            if(sellStars.length >= 1) {
                message = message + recommendations[k].sellTarget3 + " ";  
            } 
             
            // bot.sendMessage(chatId, message,  { parse_mode: "HTML" });
            if(sellStars.length > 0) { 
                monitorStocks.push({ "name": recommendations[k].stockname, "rec": "SELL", "message": message });
            }
       
        } else {
            // monitorStocks = monitorStocks + recommendations[k].stockname+ " ";
        }
    }
    return monitorStocks;

}
process();

