var symbols = require('./symbols');
var recommender = require('./getall');
var fs = require("fs");
var elements = {};
var monitor = "";
var monitorElements = [];

const TelegramBot = require('node-telegram-bot-api');
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });

async function process() {
    var chatId;// = msg.chat.id;
    chatId = 378345990;

    var dateObj = new Date();
    var forDate = dateObj.getUTCDate()    ;
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();
 
    var dateStr = forDate + "-" + forMonth + "-" + forYear;

    monitor = fs.readFileSync(__dirname + "/" + "ALL_MONITOR.csv");
    console.log(dateObj.getUTCHours() );
    console.log(dateObj.getUTCMinutes() );
  
    elements = await symbols.getAllSymbols();
  
    elementsArray = monitor.toString().split(" ");
    for (var i = 0; i < elementsArray.length - 1; i++) {
        console.log(elementsArray[i]);
        monitorElements.push(elements[elementsArray[i]]);
    }
  
    // console.log(monitorElements);
    monitorData = await recommender.getAllRecommendations(forDate, forMonth, forYear, monitorElements, true);

    monitorStocks = processMonitorStocks(monitorData);

    // fs.writeFile(__dirname + "/" + dateStr + "_MONITOR.txt", monitorStocks, (err) => {
    //     if (err) console.log(err);
    //     console.log("Successfully Written to File.");
    // });
  
    // //Send a heartbeat message once in an hour
    // if(dateObj.getUTCMinutes() > 30 && dateObj.getUTCMinutes() < 40 ){ 
    //     bot.sendMessage(378345990, "Monitoring MONITOR Stocks: "  +  monitorStocks);
    // }
      
}

function getChartString(data, nolink) {
    var finalString = "";

    var dateObj = new Date();
    var forDate = dateObj.getUTCDate()  ;
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();
 
    var dateStr = forDate + "-" + forMonth + "-" + forYear;
 
    finalString = "<b>" + data.stockname + ":</b>" + data.rating + " " + dateStr + " MONITOR_UNTIL_10";
    finalString = finalString + "\nDRS: " + data.defaultResistence + " " + data.defaultSupport;
    finalString = finalString + "\nFC: " + data.firstCandleHigh + "-" + data.firstCandleLow + "=" + data.diff;
    finalString = finalString + "\nBT: " + data.buyTarget1 + " " + data.buyTarget2 + " " + data.buyTarget3;
    finalString = finalString + "\nST: " + data.sellTarget1 + " " + data.sellTarget2 + " " + data.sellTarget3;
    finalString = finalString + "\nCC: " + data.firstCandleClose + " " + data.secondCandleClose + " " + data.thirdCandleClose;
    finalString = finalString + "\nIHL: " + data.todayHigh + " " + data.todayLow ;
    finalString = finalString + "\n<a href='" + data.link + "'>CHART</a> " + "\n\n";
     
    return finalString;

}
  
function processMonitorStocks(recommendations) {
    var chatId;// = msg.chat.id;
    chatId = 378345990;
    var monitorStocks = "";
    var buyMessage = "";
    var sellMessage = "";
    //Now, we have all the data. Let us try to find out if any stocks are in buy zone or sell zone. 
    for (var k = 0; k < recommendations.length; k++) {

        console.log('Analyzing: ' + recommendations[k].stockname);
        var todayData = recommendations[k].todayjson.data;
  
        //    // //Until trend reversal time, i.e., 10:00, we need to wait.
        if(todayData.candles.length > 10 || todayData.candles.length < 3) {
            console.log("Nothing to monitor from now on.");
            //Nothing to monitor from now. 
            break;
        }

        var avgPrice = (parseFloat(    recommendations[k].firstCandleHigh)  +  parseFloat(  recommendations[k].firstCandleLow))/2;
        console.log(recommendations[k].stockname + ': diff/avg: ' + recommendations[k].diff+ " " + avgPrice * 0.01 + " " + recommendations[k].firstCandleHigh);

        var threshold = 0;
        if(avgPrice <= 100) {
            threshold =  avgPrice * 0.02;
        } else if(avgPrice > 100 && avgPrice <= 1000) {
            threshold =  avgPrice * 0.01;
        } else if(avgPrice > 1000 && avgPrice <= 2000) {
            threshold =  avgPrice * 0.008;
        } else if(avgPrice > 2000 && avgPrice <= 5000) {
            threshold =  avgPrice * 0.005;
        } else if(avgPrice > 5000  ) {
            threshold =  avgPrice * 0.001;
        } 
  
        if(recommendations[k].diff < threshold) {
            continue;
        }

  
        var latestSupport = recommendations[k].defaultSupport;
        var latestResistance = recommendations[k].defaultResistence; 

        var intradayHigh = recommendations[k].todayHigh;
        var intradayLow =  recommendations[k].todayLow;
 
        var buyStars = "";

        if(intradayHigh < recommendations[k].buyTarget1) {
            buyStars = "***";
        }else if( intradayHigh < recommendations[k].buyTarget2) {
            buyStars = "**";
        }else if( intradayHigh < recommendations[k].buyTarget3) {
            buyStars = "*";
        }
        var sellStars = "";
        if(intradayLow > recommendations[k].sellTarget1) {
            sellStars = "***";
        }else if( intradayLow > recommendations[k].sellTarget2) {
            sellStars = "**";
        }else if( intradayLow > recommendations[k].sellTarget3) {
            sellStars = "*";
        }

        var startIndex = todayData.candles.length -3;
 
        var sellNow = false;
        var buyNow = false;
        var strongSell = false;
        var strongBuy = false;
 
        if (todayData.candles[startIndex][3] > latestSupport && todayData.candles[startIndex][2] < latestResistance) {
            continue;
        }
       //This cannot be 'if else' as first candle can hit both high and low at the same time though it is rare
        //Check if first candle low is below support  
        if (todayData.candles[startIndex][3] <= latestSupport) {
            //next 2 candles should close below support
            if(todayData.candles[startIndex + 1][4] < latestSupport &&
                todayData.candles[startIndex + 2][4] < latestSupport &&
               //Also next 2 candles high also should not touch support 
                todayData.candles[startIndex + 1][2] < latestSupport &&
                todayData.candles[startIndex + 2][2] < latestSupport 
                ) {
                    sellNow = true;
                    strongSell = true;
            } else if(todayData.candles[startIndex + 1][4] > latestSupport &&
                todayData.candles[startIndex + 2][4] > latestSupport  &&
                //Also next 2 candles low also should not touch support 
                todayData.candles[startIndex + 1][3] > latestSupport &&
                todayData.candles[startIndex + 2][3] > latestSupport 
                ) {
                    buyNow = true;
            }
        } 
        //Check if first candle high is above resistance
        if(todayData.candles[startIndex][2] >= latestResistance) {
            if(todayData.candles[startIndex + 1][4] > latestResistance &&
                todayData.candles[startIndex + 2][4] > latestResistance && 
                //Also next 2 candles low also should not touch resistance
                todayData.candles[startIndex + 1][3] > latestResistance &&
                todayData.candles[startIndex + 2][3] > latestResistance
                ) {
                    buyNow = true;
                    strongBuy = true;
            } else if(todayData.candles[startIndex + 1][4] < latestResistance &&
                todayData.candles[startIndex + 2][4] < latestResistance &&
                //Also next 2 candles high also should not touch resistance
                todayData.candles[startIndex + 1][4] < latestResistance &&
                todayData.candles[startIndex + 2][4] < latestResistance
                ) {
                    sellNow = true;
                    
            }

        }

        var cmp = todayData.candles[startIndex + 2][4];
         
        console.log('sellnow/buynow: ' + sellNow + "/" + buyNow);
  
        if(buyNow ){
            var buyRecommendation =  recommendations[k].stockname ; //getChartString(recommendations[k], true);
            buyMessage = buyMessage + buyRecommendation + " " + buyStars + (strongBuy ? "S." :"") + "BUY, CMP " + cmp + " target: " ;
            buyMessage = buyMessage + recommendations[k].buyTarget1 + "\n";
            // bot.sendMessage(chatId, message); //,  { parse_mode: "HTML" });
 
            console.log(recommendations[k].stockname + ' is ready for buy now above ' + latestResistance);
        } else if (sellNow) {
                 
            var sellRecommendation =  recommendations[k].stockname ; // getChartString(recommendations[k], true);
            sellMessage = sellMessage + sellRecommendation + " " + sellStars + (strongSell ? "S." :"") + "SELL, CMP " + cmp + " Target:" ;
            sellMessage = sellMessage + recommendations[k].sellTarget1 + "\n";
            // bot.sendMessage(chatId, message);//,  { parse_mode: "HTML" });

            console.log(recommendations[k].stockname + ' is ready for sell now below ' + latestSupport);
        }else {
            monitorStocks = monitorStocks + recommendations[k].stockname+ " ";
        }
    }
    //Send the message now
    if(buyMessage.length > 4000) {
        var message = buyMessage.substr(0,4000);
        bot.sendMessage(chatId, 'BUY:\n' + message);
        message = buyMessage.substring(4000 );
        bot.sendMessage(chatId, 'BUY:(remaining)\n' + message );   
    }else{ 
        if(buyMessage.length > 2) {
            bot.sendMessage(chatId, 'BUY:\n' + buyMessage);
        }
        
    }

    //Send the message now
    if(sellMessage.length > 4000) {
        var message = sellMessage.substr(0,4000);
        bot.sendMessage(chatId, 'SELL:\n' + message);
        message = sellMessage.substring(4000 );
        bot.sendMessage(chatId, 'SELL:(remaining)\n' + message );   
    }else{ 
        if(sellMessage.length > 2) {
            bot.sendMessage(chatId, 'SELL:\n' + sellMessage);
        }
    }

    return monitorStocks;
    
}
process();

