var symbols = require('./symbols');
var recommender = require('./getall');
var fs = require("fs");
var elements = {};
var notClear = "";
var notClearElements = [];

const TelegramBot = require('node-telegram-bot-api');
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });

async function process() {
    var chatId;// = msg.chat.id;
    chatId = 378345990;

    var dateObj = new Date();
    var dateStr = dateObj.getUTCDate() + "-" + (dateObj.getUTCMonth() + 1) + "-" + dateObj.getUTCFullYear();

    notClear = fs.readFileSync(__dirname + "/" + dateStr + "_NOTCLEAR.txt");
    buys = fs.readFileSync(__dirname + "/" + dateStr + "_BUY.txt");
    sells = fs.readFileSync(__dirname + "/" + dateStr + "_SELL.txt");

    elements = await symbols.getAllSymbols();
    // console.log(elements);
    // console.log("NOT CLEAR:" + notClear);

    elementsArray = notClear.toString().split(" ");
    for (var i = 0; i < elementsArray.length - 1; i++) {
        console.log(elementsArray[i]);
        notClearElements.push(elements[elementsArray[i]]);
    }

    // console.log(notClearElements);
    notClearData = await recommender.getAllRecommendations(dateObj.getUTCDate(), (dateObj.getUTCMonth() + 1), dateObj.getUTCFullYear(), notClearElements, true);

    processNotClearStocks(notClearData);

    buyElements = [];
    elementsArray = buys.toString().split(" ");
    for (var i = 0; i < elementsArray.length - 1; i++) {
        console.log(elementsArray[i]);
        buyElements.push(elements[elementsArray[i]]);
    }
 
    // console.log(notClearElements);
    buyData = await recommender.getAllRecommendations(dateObj.getUTCDate(), (dateObj.getUTCMonth() + 1), dateObj.getUTCFullYear(), buyElements, true);

    processBuyStocks(buyData);
  
    sellElements = [];
    elementsArray = sells.toString().split(" ");
    for (var i = 0; i < elementsArray.length - 1; i++) {
        console.log(elementsArray[i]);
        sellElements.push(elements[elementsArray[i]]);
    }

    // console.log(notClearElements);
    sellData = await recommender.getAllRecommendations(dateObj.getUTCDate(), (dateObj.getUTCMonth() + 1), dateObj.getUTCFullYear(), sellElements, true);

    processSellStocks(sellData);
}
function processSellStocks(recommendations) {
    var chatId;// = msg.chat.id;
    chatId = 378345990;
    //Now, we have all the data. Let us try to find out if any stocks are in buy zone or sell zone. 
    for (var k = 0; k < recommendations.length; k++) {
        var todayData = recommendations[k].todayjson.data;
        var brokeSupport = false;
        //Check until 10 AM, if it broke resistance or support at least once 
        for (var i = 3; i < 14; i++) {  //until 10 am
            if (todayData.candles[i][4] > recommendations[k].defaultSupport) {
                brokeSupport = true;
            }
        }

        if(!brokeSupport) {
            bot.sendMessage(chatId, recommendations[k].stockname + ' is a strong sell now with SL ' + recommendations[k].defaultSupport);
            console.log(recommendations[k].stockname + ' is a strong sell now with SL ' + recommendations[k].defaultSupport);
        }

    }      
}


function processBuyStocks(recommendations) {
    var chatId;// = msg.chat.id;
    chatId = 378345990;
    //Now, we have all the data. Let us try to find out if any stocks are in buy zone or sell zone. 
    for (var k = 0; k < recommendations.length; k++) {
        var todayData = recommendations[k].todayjson.data;
        var brokeResistence = false;
        // console.log('broke resistance ' ,recommendations[k]);
        //Check until 10 AM, if it broke resistance or support at least once 
        for (var i = 3; i < 14; i++) {  //until 10 am
            if (todayData.candles[i][4] < recommendations[k].defaultResistence) {
                
                brokeResistence = true;
            }
        }

        if(!brokeResistence) {
            bot.sendMessage(chatId, recommendations[k].stockname + ' is a strong buy now with SL ' + recommendations[k].defaultResistence);
            console.log(recommendations[k].stockname + ' is a strong buy now with SL ' + recommendations[k].defaultResistence);
        }

    }      
}
  

function processNotClearStocks(recommendations) {
    var chatId;// = msg.chat.id;
    chatId = 378345990;
    //Now, we have all the data. Let us try to find out if any stocks are in buy zone or sell zone. 
    for (var k = 0; k < recommendations.length; k++) {
        var todayData = recommendations[k].todayjson.data;

        // console.log("Recommendations are :", todayData);
        var brokeSupport = false;
        var brokerResistence = false;
        //Check until 10 AM, if it broke resistance or support at least once 
        for (var i = 0; i < 10; i++) {  //until 10 am
            if (todayData.candles[i][4] < recommendations[k].defaultSupport) {
                brokeSupport = true;
            }
            if (todayData.candles[i][4] > recommendations[k].defaultResistance) {
                brokerResistence = true;
            }
        }
        if (brokeSupport && brokerResistence) {


        } else if (!brokeSupport && !brokerResistence) {


        } else {

            console.log('Checking : ' + recommendations[k].stockname);
            var counter = 0;
            if (brokeSupport) {
                for (var i = 10; i < 14; i++) {
                    if (todayData.candles[i][4] > recommendations[k].defaultSupport) {
                        counter++;

                    }
                }
                if (counter == 4) {

                    bot.sendMessage(chatId, recommendations[k].stockname + ' is a buy now above ' + recommendations[k].trendReversalHigh);
 
                    console.log(recommendations[k].stockname + ' is a buy now above ' + recommendations[k].trendReversalHigh);
                }
            } else {
                for (var i = 10; i < 14; i++) {
                    if (todayData.candles[i][4] < recommendations[k].defaultResistance) {
                        counter++;
                    }
                }
                if (counter == 4) {
                    bot.sendMessage(chatId, recommendations[k].stockname + ' is a sell now below ' + recommendations[k].trendReversalLow);

                    console.log(recommendations[k].stockname + ' is a sell now below ' + recommendations[k].trendReversalLow);
                }

            }

        }
    }
}
process();

