var Excel = require('exceljs');
  
var workbook = new Excel.Workbook();

var sheet = workbook.addWorksheet('TRADES', {views:[{xSplit: 1 }]});

sheet.columns = [
    { header: 'Stock', key: 'Stock'},
    { header: 'Suggestion', key: 'Suggestion'},
    { header: 'FCHigh', key: 'FCHigh'},
    { header: 'FCLow', key: 'FCLow'},
    { header: 'FCDiff', key: 'FCDiff'},
    { header: 'Buy T1', key: 'BT1'},
    { header: 'Buy T2', key: 'BT2'},
    { header: 'Buy T3', key: 'BT3'},
    { header: 'Buy SL', key: 'BuySL'},
    { header: 'Sell T1', key: 'ST1'},
    { header: 'Sell T2', key: 'ST2'},
    { header: 'Sell T3', key: 'ST3'},
    { header: 'Sell SL', key: 'SellSL'},
    { header: 'Resist', key: 'Resist'},
    { header: 'Suprt', key: 'Suprt'},
    { header: 'Cdl1', key: 'Cdl1'},
    { header: 'Cdl2', key: 'Cdl2'},
    { header: 'Cdl3', key: 'Cdl3'},
    { header: 'AbvRes', key: 'AbvRes'},
    { header: 'DayHigh', key: 'DayHigh'},
    { header: 'DayLow', key: 'DayLow'}
];

sheet.addRow({Stock: 'INDUSINDBANK', Suggestion: 'Buy' });
 
workbook.xlsx.writeFile("generatedfile.xlsx")
    .then(function() {
        console.log('File written successfully');
    });