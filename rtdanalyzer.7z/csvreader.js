const csv = require('csv-parser');
const fs = require('fs');


const readAllData = () => {

    return new Promise((resolve, reject) => {
        let elements = [];
        fs.createReadStream('data.csv')
            .pipe(csv())
            .on('data', (row) => {
                elements.push(row);
            })
            .on('end', () => {
                console.log('CSV file successfully processed');
                resolve(elements);
            });

    });
} ;

// async function readAllData() { 
// fs.createReadStream('data.csv')  
//   .pipe(csv())
//   .on('data', (row) => {
//     elements.push(row);

//   })
//   .on('end', () => {
//     console.log('CSV file successfully processed');
//   });
// }
async function readAll(){
    elements = await readAllData();
    console.log(elements);
} 




readAll();

