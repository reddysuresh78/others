console.log(__dirname);

const TelegramBot = require('node-telegram-bot-api');
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });
 
bot.sendMessage(378345990,    "<b>STRONG SELL:</b>"  + "ABC DEF GHI" );
 

