var request = require('request');

request.get(
    'https://kitecharts-aws.zerodha.com/api/chart/14746370/5minute?from=2019-06-14&to=2019-06-14&oi=1&public_token=undefined&access_token=',

    function (err, res, body) {
        if (err) {

        } //TODO: handle err
        if (res.statusCode !== 200) {


        } //etc
        //console.log(body);

        datajson = JSON.parse(body);
        //console.log('received it');
        // console.log(datajson.data.candles[0][0]);
        for (i = 0; i < 3; i++) {
            var candleData = datajson.data.candles[i];
            var curData = new Date(candleData[0]);
            console.log(curData.getHours() + ":" + curData.getMinutes() + " " + candleData[1]
                + " " + candleData[2] + " " + candleData[3] + " " + candleData[4]);

        }

        //TODO Do something with response
    });