const TelegramBot = require('node-telegram-bot-api');

const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, {polling: true});

bot.on('message', (msg) => {
    


    bot.sendMessage(msg.chat.id, 'This is a test message');
  });