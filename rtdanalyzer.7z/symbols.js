const csv = require('csv-parser');
const fs = require('fs');

const readAllData = () => {
    return new Promise((resolve, reject) => {
        let elements = [];
        fs.createReadStream(__dirname + '/data.csv')
            .pipe(csv())
            .on('data', (row) => {
                elements.push(row);
            })
            .on('end', () => {
                console.log('CSV file successfully processed');
                resolve(elements);
            });
    });
};

async function getSymbols() {
    elements = await readAllData();
    elementsMap = {}
    for (i = 0; i < elements.length; i++) {
        elementsMap[elements[i].displayname] = elements[i];
    } 
   
    return elementsMap;
}

module.exports.getAllSymbols = async function () {
    return await getSymbols();
};
