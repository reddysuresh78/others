const csv = require('csv-parser');
const fs = require('fs');

const readAllData = () => {

    return new Promise((resolve, reject) => {
        let elements = [];
        fs.createReadStream(__dirname + '/data.csv')
            .pipe(csv())
            .on('data', (row) => {
                elements.push(row);
            })
            .on('end', () => {
                console.log('CSV file successfully processed');
                resolve(elements);
            });

    });
};

const getDataForScrip = (url) => {
    return new Promise((resolve, reject) => {
        const http = require('http'),
            https = require('https');

        let client = http;

        if (url.toString().indexOf("https") === 0) {
            client = https;
        }

        client.get(url, (resp) => {
            let data = '';

            // A chunk of data has been recieved.
            resp.on('data', (chunk) => {
                data += chunk;
            });

            // The whole response has been received. Print out the result.
            resp.on('end', () => {
                resolve(data);
            });

        }).on("error", (err) => {
            reject(err);
        });
    });
};


async function findTrend(day, month, year, id, name, displayname, keepScrapedData) {

    var trend = { stock: name, stockname: displayname };

    var analysisDate = new Date(year, month, day);

    // console.log(analysisDate);
    //2019-06-14
    var forDate = year + "-" + (month > 9 ? month : "0" + month) + "-" + (day > 9 ? day : "0" + day);

    trend.forDate = forDate;

    var url = 'https://kitecharts-aws.zerodha.com/api/chart/' + id + '/5minute?from=' + forDate + '&to=' + forDate + '&oi=1&public_token=undefined&access_token=';

    trend.link = 'https://kite.zerodha.com/chart/ext/tvc/NFO-FUT/' + name + '/' + id;

    // console.log(url);
    finaldata = await getDataForScrip(url);
    todayjson = JSON.parse(finaldata);

    if (keepScrapedData) {
        trend.todayjson = todayjson;
    }

    var firstCandleHigh = todayjson.data.candles[0][2];
    var firstCandleLow = todayjson.data.candles[0][3];

    var finalHourHigh = 0;
    var finalHourLow = 0;

    if (todayjson.data.candles.length > 60) { //2:15 PM
        finalHourLow = 9999999999;
        for (i = 0; i < todayjson.data.candles.length; i++) {
            var candleData = todayjson.data.candles[i];
            var curDate = new Date(candleData[0]);

            if (curDate.getUTCHours() >= 8) {
                if (curDate.getUTCHours() == 8 && curDate.getUTCMinutes() < 30)
                    continue;

                if (candleData[2] > finalHourHigh) {
                    finalHourHigh = candleData[2];
                }
                if (candleData[3] < finalHourLow) {
                    finalHourLow = candleData[3];
                }
            }
        }
    }

    trend.finalHourHigh = finalHourHigh;
    trend.finalHourLow = finalHourLow;
    trend.finalHourDiff = (finalHourHigh - finalHourLow).toFixed(2) ;

    var high = 0;
    var low = 9999999999;

    var prevDate = analysisDate;

    for (i = 1; i < 6; i++) {
        prevDate.setDate(prevDate.getDate() - 1);

        var prevMonth = prevDate.getMonth();
        var prevDay = prevDate.getDate();
        var prevYear = prevDate.getFullYear();

        var forDate = prevYear + "-" + (prevMonth > 9 ? prevMonth : "0" + prevMonth) + "-" + (prevDay > 9 ? prevDay : "0" + prevDay);

        var url = 'https://kitecharts-aws.zerodha.com/api/chart/' + id + '/5minute?from=' + forDate + '&to=' + forDate + '&oi=1&public_token=undefined&access_token=';

        // console.log(name + " " + url);
        var prevFinalData = await getDataForScrip(url);
        prevDayjson = JSON.parse(prevFinalData);

        if (prevDayjson.data == null) {
            console.log(name + " " + 'There is no data for ' + forDate);
            continue;
        }

        if (prevDayjson.data.candles.length == 0) {
            console.log(name + " " + 'There is no data for ' + forDate);
            continue;
        }

        for (i = 0; i < prevDayjson.data.candles.length; i++) {
            var candleData = prevDayjson.data.candles[i];
            var curDate = new Date(candleData[0]);

            if (curDate.getUTCHours() >= 8) {
                if (curDate.getUTCHours() == 8 && curDate.getUTCMinutes() < 30)
                    continue;

                if (candleData[2] > high) {

                    high = candleData[2];

                }
                if (candleData[3] < low) {
                    low = candleData[3];
                }
            }
        }
        break;
    }

    var todayHigh = 0;
    var todayLow = 99999999;
    for (i = 0; i < todayjson.data.candles.length; i++) {
        var candleData = todayjson.data.candles[i];
        if (candleData[2] > todayHigh) {
            todayHigh = candleData[2];
        }
        if (candleData[3] < todayLow) {
            todayLow = candleData[3];
        }
    }

    trend.trendReversalHigh = 0;
    trend.trendReversalLow = 0;
    //8
    var trendReversalHigh = 0;
    var trendReversalLow = 99999999;
    if (todayjson.data.candles.length >= 9) {
        for (i = 0; i < 9; i++) {
            var candleData = todayjson.data.candles[i];
            // console.log(candleData);
            if (candleData[2] > trendReversalHigh) {
                trendReversalHigh = candleData[2];
            }
            if (candleData[3] < trendReversalLow) {
                trendReversalLow = candleData[3];
            }
        }
        trend.trendReversalHigh = trendReversalHigh;
        trend.trendReversalLow = trendReversalLow;

    }


    trend.todayHigh = todayHigh;
    trend.todayLow = todayLow;

    // console.log(name + " " + "PREVDAY HIGH/LOW: " + high + "/" + low);
    var diff = (firstCandleHigh - firstCandleLow);
    console.log(name + " " + "FIRST CANDLE HIGH/LOW/DIFF: " + firstCandleHigh.toFixed(2) + "/" + firstCandleLow.toFixed(2) + "/" + diff.toFixed(2));

    trend.firstCandleHigh = firstCandleHigh;
    trend.firstCandleLow = firstCandleLow;
    trend.diff = diff.toFixed(2);

    diff = Math.trunc(diff);

    var bt1 = firstCandleHigh + (diff * 0.95);
    var bt2 = firstCandleHigh + (diff * 0.95) + (diff * 0.95);
    var bt3 = firstCandleHigh + (diff * 0.95) + (diff * 0.95) + (diff * 0.95);

    var st1 = firstCandleLow - (diff * 0.95);
    var st2 = firstCandleLow - (diff * 0.95) - (diff * 0.95);
    var st3 = firstCandleLow - (diff * 0.95) - (diff * 0.95) - (diff * 0.95);


    var defaultSupport = low;
    var defaultResistence = high;

    trend.defaultSupport = defaultSupport;
    trend.defaultResistence = defaultResistence;

    var belowSupportCloseCount = 0;
    var aboveResistenceCloseCount = 0;
    var aboveSupportCloseCount = 0;
    var belowResistenceCloseCount = 0;

    for (i = 0; i < 3; i++) {
        var candleData = todayjson.data.candles[i];

        if (candleData[4] < defaultSupport) {
            belowSupportCloseCount++;
        }
        if (candleData[4] >= defaultSupport) {
            aboveSupportCloseCount++;
        }

        if (candleData[4] > defaultResistence) {
            aboveResistenceCloseCount++;
        }
        if (candleData[4] <= defaultResistence) {
            belowResistenceCloseCount++;
        }

        var curData = new Date(candleData[0]);
        // console.log(name + " " + curData.getHours() + ":" + curData.getMinutes() + " " + candleData[1]
        //     + " " + candleData[2] + " " + candleData[3] + " " + candleData[4]);

    }
    // console.log(name + " " + "belowSupportCloseCount/aboveResistenceCloseCount: " + belowSupportCloseCount + "/" + aboveResistenceCloseCount);

    trend.firstCandleClose = todayjson.data.candles[0][4];
    trend.secondCandleClose = todayjson.data.candles[1][4];
    trend.thirdCandleClose = todayjson.data.candles[2][4];

    trend.belowSupportCloseCount = belowSupportCloseCount;
    trend.aboveSupportCloseCount = aboveSupportCloseCount;

    trend.aboveResistenceCloseCount = aboveResistenceCloseCount;
    trend.belowResistenceCloseCount = belowResistenceCloseCount;

    trend.sellTarget1 = st1.toFixed(0);
    trend.sellTarget2 = st2.toFixed(0);
    trend.sellTarget3 = st3.toFixed(0);

    trend.buyTarget1 = bt1.toFixed(0);
    trend.buyTarget2 = bt2.toFixed(0);
    trend.buyTarget3 = bt3.toFixed(0);

    trend.sellStopLoss = firstCandleHigh.toFixed(0);
    trend.buyStopLoss = firstCandleLow.toFixed(0);

    var candleData = todayjson.data.candles[0];
    var firstCandleClose = candleData[4];
    var firstCandleHigh = candleData[2];
    var firstCandleLow = candleData[3];

    candleData = todayjson.data.candles[1];
    var secondCandleClose = candleData[4];
    var secondCandleHigh = candleData[2];
    var secondCandleLow = candleData[3];

    candleData = todayjson.data.candles[2];
    var thirdCandleClose = candleData[4];
    var thirdCandleHigh = candleData[2];
    var thirdCandleLow = candleData[3];

    var avgPrice = (firstCandleHigh + firstCandleLow) / 2;

    var changePercent = (diff / avgPrice) * 100;
    var finalHourDiffPercent = (trend.finalHourDiff / avgPrice) * 100;

    trend.changePercent = changePercent.toFixed(2);
    trend.finalHourDiffPercent = finalHourDiffPercent.toFixed(2);

    trend.rating = "";

    if (thirdCandleClose < defaultSupport) {
        //SELL
        if (firstCandleClose < defaultSupport && secondCandleClose < defaultSupport) {
            trend.recommendation = "ST.SELL";
            //If atleast one of the candles touched resistance, only then we can be sure of sell.
        } else if (firstCandleHigh > defaultResistence || secondCandleHigh > defaultResistence || thirdCandleHigh > defaultResistence) {
            trend.recommendation = "SELL";
        } else {
            trend.recommendation = "NOT CLEAR";
        }


    } else if (thirdCandleClose > defaultResistence) {
        //BUY

        if (firstCandleClose > defaultResistence && secondCandleClose > defaultResistence) {
            trend.recommendation = "ST.BUY";

            if (firstCandleClose <= secondCandleClose && firstCandleClose <= thirdCandleClose) {
                trend.rating = "*";
            }

            //If atleast one of the candles touched support, only then we can be sure of buy.
        } else if (firstCandleLow < defaultSupport || secondCandleLow < defaultSupport || thirdCandleLow < defaultSupport) {
            trend.recommendation = "BUY";
        } else {
            trend.recommendation = "NOT CLEAR";
        }

    } else { //Trend is not clear
        if ((firstCandleHigh > defaultResistence && secondCandleLow > defaultSupport) ||
            (secondCandleHigh > defaultResistence && firstCandleLow > defaultSupport) ||
            (thirdCandleHigh > defaultResistence && thirdCandleLow > defaultSupport)

        ) {
            trend.recommendation = "SELL";
        } else if ((firstCandleLow < defaultSupport && secondCandleHigh > defaultResistence) ||
            (secondCandleLow < defaultSupport && firstCandleHigh > defaultResistence) ||
            (thirdCandleLow < defaultSupport && thirdCandleHigh > defaultResistence)
        ) {
            trend.recommendation = "BUY";
        } else {
            trend.recommendation = "NOT CLEAR";
        }
    }

    return trend;
}

async function getAllRecommendation(day, month, year, elements, recommendations, keepScrapedData) {

    for (const item of elements) {
        console.log('processing ', item.name);
        recommendations.push(await findTrend(day, month, year, item.id, item.name, item.displayname, keepScrapedData));
        // console.log("FINAL RETURN: " , await findTrend(day, month, year, item.id, item.name));

    }
    return recommendations;
}

async function getForAll(day, month, year, res) {
    elements = await readAllData();
    recommendations = [];
    // getAllRecommendation(10, 6, 2019, elements); //YESBANK
    await getAllRecommendation(day, month, year, elements, recommendations); //YESBANK
    console.log(recommendations);
    res.send(recommendations);
}

async function getForAllNonWeb(day, month, year) {
    elements = await readAllData();
    recommendations = [];
    // getAllRecommendation(10, 6, 2019, elements); //YESBANK
    await getAllRecommendation(day, month, year, elements, recommendations); //YESBANK
    console.log(recommendations);
    return recommendations;
}

module.exports.processAll = function (day, month, year, res) {
    console.log("Received " + day);
    getForAll(day, month, year, res);
};

module.exports.processAllForNonWeb = async function (day, month, year) {
    console.log("Received " + day);
    return getForAllNonWeb(day, month, year);
};

module.exports.findTrend = async function (day, month, year, id, name, displayname) {

    return findTrend(day, month, year, id, name, displayname);
};

module.exports.getAllRecommendations = async function (day, month, year, elements, keepScrapedData) {
    recommendations = [];
    return await getAllRecommendation(day, month, year, elements, recommendations, keepScrapedData); //YESBANK
    // console.log(recommendations);
    // return recommendations;
};




//processAll();
