var symbols = require('./symbols');
var fs = require("fs");

async function process() {

    var elements = await symbols.getAllSymbols();

    var onlyKeys = "";
    for (var key in elements) {
        onlyKeys = onlyKeys + key + " ";

    }
    console.log('Only keys: ' + onlyKeys);

    fs.writeFile(__dirname + "/" + "ALL_MONITOR.csv", onlyKeys, (err) => {
        if (err) console.log(err);
        console.log("Successfully Written ALL_MONITOR.csv");
    });
}

process();