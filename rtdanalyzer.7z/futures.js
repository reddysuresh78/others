let jsonData = require('./onlyfutures.json')
const csv = require('csv-parser');
const fs = require('fs');
 

var sharesMap = {};
 
for (i = 0; i < jsonData.length; i++) {
    monthIndices = {};

    var stock = jsonData[i][0];
    var firstVal = parseInt(jsonData[i][3][0][0]);
    firstVal = firstVal << 8;
    firstVal += 2;
    expiry = jsonData[i][3][0][1];
    firstKey = stock + expiry + "FUT";

    var secondKey = "";
    var secondVal = "";

    var thirdKey = "";
    var thirdVal = "";

    if (jsonData[i][3].length > 1) {
        // console.log(stock + expiry + "FUT " + firstVal)
   
        secondVal = parseInt(jsonData[i][3][1][0]);
        secondVal = secondVal << 8;
        secondVal = firstVal + secondVal;

        expiry = jsonData[i][3][1][1];
        secondKey = stock + expiry + "FUT";

    }

    // console.log(secondVal)
    if (jsonData[i][3].length > 2) {
        thirdVal = parseInt(jsonData[i][3][2][0]);
        thirdVal = thirdVal << 8;
        thirdVal = secondVal + thirdVal;
        expiry = jsonData[i][3][2][1];
        thirdKey = stock + expiry + "FUT";
    }
    // console.log(thirdVal)

    sharesMap[firstKey] = firstVal;
    sharesMap[secondKey] = secondVal;
    sharesMap[thirdKey] = thirdVal;


}


console.log(sharesMap)
 
const readAllData = () => {

    return new Promise((resolve, reject) => {
        let elements = [];
        fs.createReadStream('input.csv')
            .pipe(csv())
            .on('data', (row) => {
                elements.push(row);
            })
            .on('end', () => {
                console.log('CSV file successfully processed');
                resolve(elements);
            });

    });
} ;
 

const createCsvWriter = require('csv-writer').createObjectCsvWriter;  
const csvWriter = createCsvWriter({  
  path: 'output.csv',
  header: [
    {id: 'displayname', title: 'displayname'},
    {id: 'name', title: 'name'},
    {id: 'id', title: 'id'}
  ]
});




async function process(){
    elements = await readAllData();
    console.log(elements[0].displayname);

    data = [];

    

    for (var i=0;i<elements.length ; i++) {
        data.push( {  displayname: elements[i].displayname, name: elements[i].name, id:  sharesMap[elements[i].name]  }  ); 
        console.log(elements[i].displayname + " " + elements[i].name + " " +  sharesMap[elements[i].name]);
    }

    csvWriter  
    .writeRecords(data)
    .then(()=> console.log('The CSV file was written successfully'));
    
} 

process();

