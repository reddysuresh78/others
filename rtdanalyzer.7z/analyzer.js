var recommender = require('./getall');
const TelegramBot = require('node-telegram-bot-api');
var fs = require("fs");
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });

function getChartString(data, nolink) {
    var finalString = "";

    finalString = "<b>" + data.stockname + ":</b>" + data.rating + " " + data.diff + " " + data.buyTarget1 + " "+  data.sellTarget1 + "\n";
    // finalString = finalString + "\nDRS: " + data.defaultResistence + " " + data.defaultSupport;
    // finalString = finalString + "\nFC: " + data.firstCandleHigh + "-" + data.firstCandleLow + "=" + data.diff;
    // finalString = finalString + "\nBT: " + data.buyTarget1 + " " + data.buyTarget2 + " " + data.buyTarget3;
    // finalString = finalString + "\nST: " + data.sellTarget1 + " " + data.sellTarget2 + " " + data.sellTarget3;
    // finalString = finalString + "\nCC: " + data.firstCandleClose + " " + data.secondCandleClose + " " + data.thirdCandleClose;
    // finalString = finalString + "\nIHL: " + data.todayHigh + " " + data.todayLow ;

    // if(nolink) {
    //     finalString = finalString + "\n\n";
    // } else{ 
    //     finalString = finalString + "\n<a href='" + data.link + "'>CHART</a> " + "\n\n";
    // }

    return finalString;

}
async function getForAllNonWeb(msg) {

    var dateObj = new Date();

    var forDate = dateObj.getUTCDate()   ;
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();

    var chatId;// = msg.chat.id;
    chatId = 378345990;

    data = await recommender.processAllForNonWeb(forDate, forMonth, forYear);

    var dateStr = forDate + "-" + forMonth + "-" + forYear;

    var strongSell = "";
    var strongBuy = "";
    var buy = "";
    var sell = "";
    var notClear = "";

    var strongSellShares = "";
    var strongBuyShares = "";
    var buyShares = "";
    var sellShares = "";
    var notClearShares = "";
    var monitorStocks = "";

    for (var i = 0; i < data.length; i++) {
        var avgPrice = (parseFloat(    data[i].firstCandleHigh)  +  parseFloat(  data[i].firstCandleLow))/2;
        console.log(data[i].stockname + ': diff/avg: ' + data[i].diff+ " " + avgPrice * 0.01 + " " + data[i].firstCandleHigh);

        var threshold = 0;
        if(avgPrice <= 100) {
            threshold =  avgPrice * 0.02;
        } else if(avgPrice > 100 && avgPrice <= 1000) {
            threshold =  avgPrice * 0.01;
        } else if(avgPrice > 1000 && avgPrice <= 2000) {
            threshold =  avgPrice * 0.008;
        } else if(avgPrice > 2000 && avgPrice <= 5000) {
            threshold =  avgPrice * 0.005;
        } else if(avgPrice > 5000  ) {
            threshold =  avgPrice * 0.001;
        } 
  
        if(data[i].diff < threshold) {
            continue;
        }


        monitorStocks =monitorStocks + data[i].stockname + " ";
 
        if (data[i].recommendation == 'ST.SELL') {
            strongSell = strongSell + data[i].stockname + " ";
            strongSellShares = strongSellShares + getChartString(data[i]);
           
            if(strongSellShares.length > 3800) {
                bot.sendMessage(chatId, '<b>STRONG SELL: </b>' + dateStr + "\n" +strongSellShares, { parse_mode: "HTML" });
                strongSellShares = "";
                console.log('strong sell done');
            }
        }
        else if (data[i].recommendation == 'ST.BUY') {
            strongBuy = strongBuy + data[i].stockname + " ";

            strongBuyShares = strongBuyShares + getChartString(data[i]);
            if(strongBuyShares.length > 3800) {
                bot.sendMessage(chatId, '<b>STRONG BUY: </b>' + dateStr + "\n" +strongBuyShares, { parse_mode: "HTML" });
                strongBuyShares = "";
            }

            
        } else if (data[i].recommendation == 'SELL') {
            sell = sell + data[i].stockname + " ";

            sellShares = sellShares + getChartString(data[i]); 

            if(sellShares.length > 3800) {
                bot.sendMessage(chatId, '<b>*SELL:* </b>' + dateStr + "\n" +sellShares, { parse_mode: "HTML" });
                sellShares = "";
            }

             
        }
        else if (data[i].recommendation == 'BUY') {
            buy = buy + data[i].stockname + " ";

            buyShares = buyShares + getChartString(data[i]);
            if(buyShares.length > 3800) {
                bot.sendMessage(chatId, '<b>*BUY:* </b>' + dateStr + "\n" +buyShares, { parse_mode: "HTML" });
                buyShares = "";
            }

        } else {
            notClear = notClear + data[i].stockname + " ";

            notClearShares = notClearShares + getChartString(data[i], true);

            if(notClearShares.length > 3800) {
                // bot.sendMessage(chatId, '<b>*NOT CLEAR:* </b>' + dateStr + "\n" +notClearShares, { parse_mode: "HTML" });
                notClearShares = "";
            }
           
        }
        console.log(data[i].stockname + " : " + data[i].recommendation);
    }

    // console.log('Chat id: ' + msg.chat.id);

   
    bot.sendMessage(chatId, '<b>STRONG BUY: </b>' + dateStr + "\n" + strongBuyShares, { parse_mode: "HTML" });

    var sellArray = sell.split(" ");
    // bot.sendMessage(chatId, "STRONG SELLS", {
    //     "reply_markup": {
    //         "keyboard": [sellArray ]
    //         }
    //     });

    // const opts = {
    //     "reply_markup": {
    //                 "inline_keyboard": [[
    //                     {
    //                         "text": "A",
    //                         "callback_data": "A1"            
    //                     }, 
    //                     {
    //                         "text": "B",
    //                         "callback_data": "C1"            
    //                     }]
    //                 ]
    //             }
    //     }

    //     bot.sendMessage(chatId, '<b>*STRONG BUY:</b>' + strongBuy, opts);

    bot.sendMessage(chatId, '<b>STRONG SELL: </b>' + dateStr + "\n" +strongSellShares, { parse_mode: "HTML" });
    // bot.sendMessage(chatId, '<b>*BUY:* </b>' + dateStr + "\n" + buyShares, { parse_mode: "HTML" });
    // bot.sendMessage(chatId, '<b>*SELL:* </b>' + dateStr + "\n" +  sellShares, { parse_mode: "HTML" });

    // if(notClearShares.length > 4000) {
    //     var message = notClearShares.substr(0,4000);
    //     bot.sendMessage(chatId, 'NOT_CLEAR:\n' + message, { parse_mode: "HTML" });
    //     message = notClearShares.substring(4000 );
    //     bot.sendMessage(chatId, 'NOT_CLEAR:(remaining)\n' + message, { parse_mode: "HTML" });   
    // }else{ 
    //     bot.sendMessage(chatId, 'NOT_CLEAR:\n' + notClearShares, { parse_mode: "HTML" });
    // }
    // console.log('STRONG BUY:' + strongBuyShares);
    // console.log('STRONG SELL:' + strongSellShares);

    // console.log('BUY:' + buy);
    // console.log('SELL:' + sell);

    // console.log('NOT_CLEAR:' + notClear);

    // fs.writeFile(__dirname + "/" + dateStr + "_STSELL.txt", strongSell, (err) => {
    //     if (err) console.log(err);
    //     console.log("Successfully Written to File.");
    // });

    // fs.writeFile(__dirname + "/" + dateStr + "_STBUY.txt", strongBuy, (err) => {
    //     if (err) console.log(err);
    //     console.log("Successfully Written to File.");
    // });

    // fs.writeFile(__dirname + "/" + dateStr + "_BUY.txt", buy, (err) => {
    //     if (err) console.log(err);
    //     console.log("Successfully Written to File.");
    // });

    // fs.writeFile(__dirname + "/" + dateStr + "_SELL.txt", sell, (err) => {
    //     if (err) console.log(err);
    //     console.log("Successfully Written to File.");
    // });

    // fs.writeFile(__dirname + "/" + dateStr + "_NOTCLEAR.txt", notClear, (err) => {
    //     if (err) console.log(err);
    //     console.log("Successfully Written to File.");
    // });

    fs.writeFile(__dirname + "/" + dateStr + "_MONITOR.txt", monitorStocks, (err) => {
        if (err) console.log(err);
        console.log("Successfully Written to File.");


    });
    
    // bot.sendMessage(chatId, 'Monitoring NOW: ' + monitorStocks );

}

//getForAllNonWeb();

// bot.on('message', (msg) => {
//     getForAllNonWeb(msg);
// });

// bot.onText(/get (.+)/, (msg, match) => {
//     stocks = match[1];
//     bot.sendMessage( msg.chat.id , 'Received:' + stocks);
// });

getForAllNonWeb();
