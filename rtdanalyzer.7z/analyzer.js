var recommender = require('./getall');
const TelegramBot = require('node-telegram-bot-api');
var fs = require("fs");
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });
 
async function getForAllNonWeb(msg) {

    var dateObj = new Date();
    data = await recommender.processAllForNonWeb(dateObj.getUTCDate(), dateObj.getUTCMonth() + 1, dateObj.getUTCFullYear());

    var dateStr = dateObj.getUTCDate() + "-" + (dateObj.getUTCMonth() + 1) + "-" + dateObj.getUTCFullYear();

    console.log(dateObj.getUTCDate() + " " + dateObj.getUTCMonth() + " " + dateObj.getUTCFullYear());

    var strongSell = "";
    var strongBuy = "";
    var buy = "";
    var sell = "";
    var notClear = "";

    for (var i = 0; i < data.length; i++) {
        if (data[i].recommendation == 'ST.SELL') {
            strongSell = strongSell + data[i].stockname + " ";
        }
        else if (data[i].recommendation == 'ST.BUY') {
            strongBuy = strongBuy + data[i].stockname + " ";
        } else if (data[i].recommendation == 'SELL') {
            sell = sell + data[i].stockname + " ";
        }
        else if (data[i].recommendation == 'BUY') {
            buy = buy + data[i].stockname + " ";
        }else {
            notClear  = notClear + data[i].stockname + " ";
        }
        console.log(data[i].stockname + " : " + data[i].recommendation);
    }

    // console.log('Chat id: ' + msg.chat.id);

    var chatId;// = msg.chat.id;
    chatId = 378345990;
    bot.sendMessage(chatId, 'STRONG BUY:' + strongBuy);
    bot.sendMessage(chatId, 'STRONG SELL:' + strongSell);
    bot.sendMessage(chatId, 'BUY:' + buy);
    bot.sendMessage(chatId, 'SELL:' + sell);
    bot.sendMessage(chatId, 'NOT_CLEAR:' + notClear);
 
    console.log('STRONG BUY:' + strongBuy);
    console.log('STRONG SELL:' + strongSell);

    console.log('BUY:' + buy);
    console.log('SELL:' + sell);

    console.log('NOT_CLEAR:' + notClear);

    fs.writeFile(dateStr + "_STSELL.txt", strongSell, (err) => {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });

    fs.writeFile(dateStr + "_STBUY.txt", strongBuy, (err) => {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });

    fs.writeFile(dateStr + "_BUY.txt", buy, (err) => {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });

    fs.writeFile(dateStr + "_SELL.txt", sell, (err) => {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });

    fs.writeFile(dateStr + "_NOTCLEAR.txt", notClear, (err) => {
        if (err) console.log(err);
        console.log("Successfully Written to File.");
    });
 
}

//getForAllNonWeb();

// bot.on('message', (msg) => {
//     getForAllNonWeb(msg);
// });

// bot.onText(/get (.+)/, (msg, match) => {
//     stocks = match[1];
//     bot.sendMessage( msg.chat.id , 'Received:' + stocks);
// });

getForAllNonWeb();
