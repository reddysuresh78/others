var recommender=require('./getall');
// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
const TelegramBot = require('node-telegram-bot-api');

const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, {polling: true});

var dateObj = new Date();

AWS.config.update({
    accessKeyId: 'AKIAZZE6E37VQAKX3WNF',
    secretAccessKey: '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',
    region: 'us-east-1'
  });


async function getForAllNonWeb(msg) {
    data = await recommender.processAllForNonWeb(dateObj.getUTCDate(), dateObj.getUTCMonth(), dateObj.getUTCFullYear());
    var strongSell = "";
    var strongBuy = "";

    for(var i=0;i<data.length;i++) {
        if(data[i].recommendation == 'ST.SELL') {
            strongSell = strongSell + data[i].stockname + " ";
        }
        else if(data[i].recommendation == 'ST.BUY') {
            strongBuy = strongBuy + data[i].stockname + " ";
        }
        console.log(data[i].stockname + " : " + data[i].recommendation); 
    }

    // console.log('Chat id: ' + msg.chat.id);

    var chatId;// = msg.chat.id;
    chatId = 378345990;
    bot.sendMessage(chatId, 'SB:' + strongBuy);
    bot.sendMessage(chatId, 'SS:' + strongSell);

    
    sendSMS('SB:' + strongBuy);
    sendSMS('SS:' + strongSell);
    console.log(strongBuy);
    console.log(strongSell);
    
}

function sendSMS(message) {  
// Create publish parameters
var params = {
    Message: message,
    PhoneNumber: '+919000111935',
  };
  
  // Create promise and SNS service object
  var publishTextPromise = new AWS.SNS({apiVersion: '2010-03-31'}).publish(params).promise();
  
  // Handle promise's fulfilled/rejected states
  publishTextPromise.then(
    function(data) {
      console.log("MessageID is " + data.MessageId);
    }).catch(
      function(err) {
      console.error(err, err.stack);
    });
}
getForAllNonWeb();

// bot.on('message', (msg) => {
//     getForAllNonWeb(msg);
// });


