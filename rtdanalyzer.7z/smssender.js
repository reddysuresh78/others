// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
 

AWS.config.update({
    accessKeyId: 'AKIAZZE6E37VQAKX3WNF',
    secretAccessKey: 'l/mVNsWXFe19AeaF69GL5C/ZPWWPAHB5darbqqTh',
    region: 'us-east-1'
  });

// Create publish parameters
var params = {
  Message: 'Sample AWS Message', /* required */
  PhoneNumber: '+919000111935',
};

// Create promise and SNS service object
var publishTextPromise = new AWS.SNS({apiVersion: '2010-03-31'}).publish(params).promise();

// Handle promise's fulfilled/rejected states
publishTextPromise.then(
  function(data) {
    console.log("MessageID is " + data.MessageId);
  }).catch(
    function(err) {
    console.error(err, err.stack);
  });