import React from 'react';
import Typography from '@mui/material/Typography';

const MetricsDashboard = ({ numberOfRisks, numberOfControls }) => {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <div style={{ margin: '20px', alignItems: 'center' }}>
        <Typography variant="h4" style={{ fontWeight: 'bold' }}>
          Risks Count
        </Typography>
        <Typography variant="h2" style={{ fontWeight: 'bold', textAlign:'center', color: 'red' }}>
          {numberOfRisks}
        </Typography>
      </div>

      <div style={{ margin: '20px', alignItems: 'center' }}>
        <Typography variant="h4" style={{ fontWeight: 'bold' }}>
          Controls Count
        </Typography>
        <Typography variant="h2" style={{ fontWeight: 'bold', textAlign:'center', color: 'green' }}>
          {numberOfControls}
        </Typography>
      </div>
    </div>
  );
};

export default MetricsDashboard;
