import React from 'react';
import Dropdown from './DropDown';
import Accordian from './Accordian';
 
import './App.css'; 

const App = () => {
  return (
    <div className="container">
      <h1 className='header'>RCB Report</h1>
      <div className="dropdown-container"> {/* Add a dropdown container */}
        <Dropdown />
      </div>
      <div className='reportcontainer'> 
        <Accordian />
      </div>
    
    </div>
  );
};

export default App;
