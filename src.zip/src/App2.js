 
import './App.css';
 
import React from 'react';
import TreeView from './TreeView';

const App = () => {
  return (
    <div>
      <div style={{ display: 'flex' }}>
        <div style={{ width: '30%', marginRight: '1rem' }}>
          <h2>Tree View</h2>
          <TreeView />
        </div>
        <div style={{ flex: '1' }}>
          <h2>Right Panel</h2>
          <div id="tree"> </div>
        </div>
      </div>
    </div>
  );
};

export default App;
