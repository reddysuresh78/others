import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Grid from '@mui/material/Grid';
import RiskControlEffectiveness from './RiskControlEffectiveness';
import MetricsDashboard from './MetricsDashboard';

export default function ControlledAccordions() {
  const [expanded, setExpanded] = React.useState('panel1');

  const handleChange =
    (panel) => (event, isExpanded) => {
      setExpanded(isExpanded ? panel : false);
    };
 
    const numberOfRisks = 11; // Replace this with the actual number of risks from your data
  const numberOfControls = 77; // Replace this with the actual number of controls from your data



  return (
    <div style={{ width: '80%', margin: '0 auto' }}>
      <Accordion expanded={expanded === 'panel1'}  onChange={handleChange('panel1')}>
        <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography variant="h4" color="error" >RAU: 6209 - Onboarding Service</Typography>

        </AccordionSummary>
        <AccordionDetails>

          <Typography variant="h5"   style={{ marginTop: '0px' }}><b>LoB:</b> Strategy, Digital and Innovation</Typography>

          <Grid container spacing={2}>

            <Grid xs={8}>
              <Typography variant="h5"  style={{ marginTop: '30px', marginLeft: '15px' }}> <b>Owner:</b> Suresh Reddy</Typography>
            </Grid>

            <Grid xs={10}>
              <Typography variant="h5" style={{ marginTop: '10px', marginLeft: '15px' }}>
                <b> Descripton: </b> This RAU does something that others don't do. This RAU does something that others don't do.
                This RAU does something that others don't do. This RAU does something that others don't do.
                This RAU does something that others don't do. This RAU does something that others don't do.
                This RAU does something that others don't do. This RAU does something that others don't do.
              </Typography>
            </Grid>

          </Grid>

          <div style={{ marginTop: '15px' }}>
              <MetricsDashboard numberOfRisks={numberOfRisks} numberOfControls={numberOfControls} />

          </div>

        </AccordionDetails>
      </Accordion>


      <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >

          <Typography variant="h5" fontWeight="bold" sx={{ width: '21%', flexShrink: 0 }} style={{ marginTop: '0px' }}>Risk - Control Effectiveness</Typography>

          <Typography sx={{ color: 'text.secondary' }} style={{ marginTop: '6px' }}>
            Reports whether each control mitigates the risk instance
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <RiskControlEffectiveness />
        </AccordionDetails>
      </Accordion>

      <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >

          <Typography variant="h5" fontWeight="bold" sx={{ width: '21%', flexShrink: 0 }} style={{ marginTop: '0px' }}>Rationale Based Risk Ratings</Typography>

          <Typography sx={{ color: 'text.secondary' }} style={{ marginTop: '6px' }}>
            Reports whether each risk rating is accurate
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <RiskControlEffectiveness />
        </AccordionDetails>


      </Accordion>
      <Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}>

      <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >

          <Typography variant="h5" fontWeight="bold" sx={{ width: '21%', flexShrink: 0 }} style={{ marginTop: '0px' }}>Overlapping Controls</Typography>

          <Typography sx={{ color: 'text.secondary' }} style={{ marginTop: '6px' }}>
          Are some controls addresssing too many risks
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <RiskControlEffectiveness />
        </AccordionDetails>
        </Accordion>
 

      <Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}>

      <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >

          <Typography variant="h5" fontWeight="bold" sx={{ width: '21%', flexShrink: 0 }} style={{ marginTop: '0px' }}>Risk Finder</Typography>

          <Typography sx={{ color: 'text.secondary' }} style={{ marginTop: '6px' }}>
          Risks based on the Service model
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <RiskControlEffectiveness />
        </AccordionDetails>

         
      </Accordion>


    </div>
  );
}