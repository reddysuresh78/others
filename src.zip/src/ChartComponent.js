import React, { useEffect, useState } from 'react';
import Chart from 'chart.js';

const ChartComponent = () => {
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    // Fetch chart data from the server
    fetch('/chart-data')
      .then((response) => response.json())
      .then((data) => {
        setChartData(data);
      });
  }, []);

  useEffect(() => {
    // Create chart after data is fetched
    if (chartData.length > 0) {
      const ctx1 = document.getElementById('chart1').getContext('2d');
      const ctx2 = document.getElementById('chart2').getContext('2d');

      new Chart(ctx1, {
        type: 'bar',
        data: {
          labels: ['A', 'B', 'C', 'D', 'E'],
          datasets: [
            {
              label: 'Chart 1',
              data: chartData,
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1,
            },
          ],
        },
      });

      new Chart(ctx2, {
        type: 'line',
        data: {
          labels: ['A', 'B', 'C', 'D', 'E'],
          datasets: [
            {
              label: 'Chart 2',
              data: chartData.map((value) => value * 2),
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 1,
            },
          ],
        },
      });
    }
  }, [chartData]);

  return (
    <div>
      <h1>Charts</h1>
      <div style={{ display: 'flex' }}>
        <canvas id="chart1" width="400" height="200"></canvas>
        <canvas id="chart2" width="400" height="200"></canvas>
      </div>
    </div>
  );
};

export default ChartComponent;
