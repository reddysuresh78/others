 
import './App.css';
 
import React from 'react';
import AccordianView from './AppAccordian';

const App = () => {
  return (
    <div>
         <AccordianView />
     
    </div>
  );
};

export default App;
