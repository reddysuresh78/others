import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

const TreeView = () => {
  const [treeData, setTreeData] = useState([]);

  useEffect(() => {
    fetchTreeData();
  }, []);

  const fetchTreeData = async () => {
    try {
      const response = await axios.get('http://localhost:3000/api/tree-data'); // Replace with your API endpoint
      setTreeData(response.data);
    } catch (error) {
      console.error('Error fetching tree data:', error);
    }
  };

  const handleDragEnd = (result) => {
    // Handle drag and drop logic here
    // Retrieve the dragged item and destination
    const { source, destination } = result;
    // Perform the necessary operations based on the drag and drop action
    // For example, update the data or trigger an API request to update the server-side data
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <Droppable droppableId="tree">
        {(provided) => (
          <div ref={provided.innerRef} {...provided.droppableProps}>
            {treeData.map((node, index) => (
              <Draggable key={node.id} draggableId={node.id} index={index}>
                {(provided) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                  >
                    
                    <TreeNode node={node} />
                  </div>
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </DragDropContext>
  );
};

const TreeNode = ({ node }) => {
  return (
    <div>
      
      <div>{node.name}</div>
    </div>
  );
};

export default TreeView;
