import React from 'react';

const ActionsGrid = () => {
  // Define your list of actions here
  const actions = [
    { title: 'Action 1', description: 'Description 1' },
    { title: 'Action 2', description: 'Description 2' },
    { title: 'Action 3', description: 'Description 3' },
    { title: 'Action 4', description: 'Description 4' },
    { title: 'Action 5', description: 'Description 5' },
    { title: 'Action 6', description: 'Description 6' },
  ];

  return (
    <div className="parentgrid">
      <div className="grid">
      {actions.map((action, index) => (
        <div className="action-card" key={index}>
          <h2>{action.title}</h2>
          <p>{action.description}</p>
          <div className="button-container">
            <button>Button</button>
          </div>
        </div>
      ))}
    </div>
    </div>
  );
  
};

export default ActionsGrid;
