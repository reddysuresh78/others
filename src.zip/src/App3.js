import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearchPlus, faTimes, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import './App.css';

const App = () => {
  const [selectedCell, setSelectedCell] = useState(null);
  const [checkboxStates, setCheckboxStates] = useState({});
  const [isPopupOpen, setPopupOpen] = useState(false);
  const [prompt, setPrompt] = useState('');

  const [expandedNodes, setExpandedNodes] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);

  const [selectedContext, setSelectedContext] = useState([]);

  const [selectedRau, setSelectedRau] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedSheet, setSelectedSheet] = useState(null);

  const treeData = [
    {
      id: 1,
      name: 'RAU 6210',
      context: '6210',
      children: [
        {
          id: 2,
          name: 'Service Model',
          context: '6210/Service Model',
          children: [
            { id: 3, name: 'servicemodel', context: '6210/Service Model/servicemodel', children: [] },

          ],
        },
        {
          id: 5,
          name: 'ORQ',
          context: '6210/ORQ',
          children: [
            { id: 6, name: 'Op & Model', context: '6210/ORQ/OP & Model', children: [] },
            { id: 7, name: 'Compliance', context: '6210/ORQ/Compliance', children: [] },
          ],
        },
        {
          id: 8,
          name: 'Fact Pack',
          context: '6210/Fact Pack',
          children: [
            { id: 9, name: 'Check List', context: '6210/Fact Pack/Check List', children: [] },
            { id: 10, name: 'Tech Initiatives', context: '6210/Fact Pack/Tech Initiatives', children: [] },
          ],
        },
        {
          id: 11,
          name: 'Owners Report',
          context: '6210/Owners Report',
          children: [
            { id: 12, name: 'Risks & Controls', context: '6210/Owners Report/Risks & Controls', children: [] },
            { id: 13, name: 'Risks', context: '6210/Owners Report/Risks', children: [] },
          ],
        },
      ],
    },
    {
      id: 51,
      name: 'RAU 6312',
      children: [
        {
          id: 52,
          name: 'Service Model',
          children: [
            { id: 53, name: 'servicemodel', children: [] },

          ],
        },
        {
          id: 55,
          name: 'ORQ',
          children: [
            { id: 56, name: 'Op & Model', children: [] },
            { id: 57, name: 'Compliance', children: [] },
          ],
        },
        {
          id: 58,
          name: 'Fact Pack',
          children: [
            { id: 59, name: 'Check List', children: [] },
            { id: 60, name: 'Tech Initiatives', children: [] },
          ],
        },
        {
          id: 61,
          name: 'Owners Report',
          children: [
            { id: 62, name: 'Risks & Controls', children: [] },
            { id: 63, name: 'Risks', children: [] },
          ],
        },
      ],
    },
  ];

  const handleToggleExpand = (nodeId, nodeName, context) => {

    console.log(expandedNodes);

    setExpandedNodes((prevExpandedNodes) => {
      if (prevExpandedNodes.includes(nodeId)) {
        return prevExpandedNodes.filter((id) => id !== nodeId);
      } else {
        return [...prevExpandedNodes, nodeId];
      }
    });
    setSelectedNode(context);
  };


  const renderTree = (nodes) => {
    return (
      <ul>
        {nodes.map((node) => (
          <li key={node.id}>
            <span
              className={`node-name ${node.children && 'clickable'}`}
              onClick={() => handleToggleExpand(node.id, node.name, node.context)}
            >
              {node.children && (expandedNodes.includes(node.id) ? '-' : '+')}{' '}
              {node.name}
            </span>
            {node.children &&
              expandedNodes.includes(node.id) &&
              renderTree(node.children)}
          </li>
        ))}
      </ul>
    );
  };

  const gridData = [
    ['RAU Description', 'This RAU processes digital payments'],
    ['Step 1', 'This step initiates payments. It has few controls in place',],
    ['Step 2', 'This step reverses payments. it has some other controls in place. This is very long description',],
  ];

  const handleCellClick = (cell) => {
    setSelectedCell(cell);
    selectedContext.push(cell);
    setSelectedContext(selectedContext);
  };

  const handleCheckboxChange = (cell) => {
    setCheckboxStates((prevState) => ({
      ...prevState,
      [cell]: !prevState[cell],
    }));
  };

  const handleZoom = (event, cell) => {
    event.stopPropagation();
    setSelectedCell(cell);
    setPopupOpen(true);
  };

  const handleClosePopup = () => {
    setPopupOpen(false);
  };

  const handleProcessPrompt = () => {
    // Process the prompt value
    console.log('Processing prompt:', prompt);
    setPrompt('');
  };

  const handlePromptChange = (event) => {
    setPrompt(event.target.value);
  };

  return (
    <div className="app">

      <div className="section">   <h2>RAU Data</h2> 
        {renderTree(treeData)}</div>
      <div className="separator"></div>
      <div className="section">
        <h2>Selected Sheet: <span className='selected-sheet'>{selectedNode}</span></h2>


        <table>
          <tbody>
            {gridData.map((row, rowIndex) => (
              <tr key={rowIndex}>
                {row.map((cell, colIndex) => (
                  <td
                    key={colIndex}
                    className={`grid-cell ${selectedCell === cell ? 'selected' : ''
                      }`}
                    onClick={() => handleCellClick(cell)}
                  >
                    <label>
                      <input
                        type="checkbox"
                        checked={checkboxStates[cell] || false}
                        onChange={() => handleCheckboxChange(cell)}
                      />
                      {cell}
                    </label>
                    <div
                      className="zoom-button"
                      onClick={(event) => handleZoom(event, cell)}
                    >
                      <FontAwesomeIcon icon={faSearchPlus} />
                    </div>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>


      {isPopupOpen && (
        <div className="popup">
          <div className="popup-content">
            <div className="popup-close" onClick={handleClosePopup}>
              <FontAwesomeIcon icon={faTimes} />
            </div>
            <h2>Contents:</h2>
            <hr/>
            {selectedCell && <p>{selectedCell}</p>}
          </div>
        </div>
      )}
      <div className="separator"></div>
      <div className="section">
        <div className="vertical-section">

          <div>
          <h2>Selected Context:</h2>  
        
          {selectedContext.map((item) => (
              
                <label>
          <input
            type="checkbox"
            name={item}
     
            
          />
          {item}</label>
          
    
      ))}

        
 
          </div>
          </div>

          <div className="button-container">
            <button className="action-button">Compare</button>
            <button className="action-button">Search</button>
            <button className="action-button">Q&A</button>
            <button className="action-button">Summarize</button>
            <button className="action-button">Custom</button>
          </div>
        
        <div className="vertical-separator"></div>


        <div className="vertical-section">

          <div className="prompt-container">
            <input
              type="text"
              placeholder="Enter a prompt"
              value={prompt}
              onChange={handlePromptChange}
            />
            <button className="process-button" onClick={handleProcessPrompt}>
              <FontAwesomeIcon icon={faArrowRight} />
            </button>
          </div>
        </div>
      </div>


    </div>
  );
};

export default App;
