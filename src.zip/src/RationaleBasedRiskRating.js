import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { Tooltip } from '@mui/material';
import { styled } from '@mui/material/styles';
import  { tableCellClasses } from '@mui/material/TableCell';

const columns = [
  { id: 'riskId', label: 'Risk Tracking Id', minWidth: 30 },
  { id: 'riskName', label: 'Risk Instance Name', minWidth: 100 },
  { id: 'riskDesc', label: 'Risk Description', minWidth: 300 },
  { id: 'controlTrackingId', label: 'Control Tracking Id', minWidth: 50 },
  { id: 'controlDesc', label: 'Control Activity', minWidth: 300 },
  { id: 'controlEffective', label: 'Effective?', minWidth: 80 }
];

function createData(riskId, riskName, riskDesc, controlTrackingId, controlDesc, controlEffective) {

  const fullDesc = riskDesc;

  if (riskDesc.length > 8) {
    riskDesc = riskDesc.slice(0, 8) + "...";
  }
  return { riskId, riskName, riskDesc, controlTrackingId, controlDesc, controlEffective, fullDesc };
}

const rows = [
  createData('R-234', 'Financial Risk', "This is risk description for 1", "C-223", "Control description here", "yes"),
  createData('R-235', 'Security Risk', "This is risk description for 1", "C-224", "Control description 1 here", "yes"),
  createData('R-236', 'Third party Risk', "This is risk description for 1", "C-225", "Control description 2 here", "yes"),
  createData('R-237', 'Economic Risk', "This is risk description for 1", "C-226", "Control description 3 here", "yes"),
  createData('R-234', 'Financial Risk', "This is risk description for 1", "C-223", "Control description here", "yes"),
  createData('R-235', 'Security Risk', "This is risk description for 1", "C-224", "Control description 1 here", "yes"),
  createData('R-236', 'Third party Risk', "This is risk description for 1", "C-225", "Control description 2 here", "yes"),
  createData('R-237', 'Economic Risk', "This is risk description for 1", "C-226", "Control description 3 here", "yes"),
  createData('R-234', 'Financial Risk', "This is risk description for 1", "C-223", "Control description here", "yes"),
  createData('R-235', 'Security Risk', "This is risk description for 1", "C-224", "Control description 1 here", "yes"),
  createData('R-236', 'Third party Risk', "This is risk description for 1", "C-225", "Control description 2 here", "yes"),
  createData('R-237', 'Economic Risk', "This is risk description for 1", "C-226", "Control description 3 here", "yes"),
];

export default function StickyHeadTable() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));

  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: 400 }} style={{ minHeight: 400 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow style={{ fontWeight: 'bold', fontSize: '25px' }}>
              {columns.map((column) => (
       
                <StyledTableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth, fontWeight: 'bold', fontSize: '19px' }}
                  
                >
                  {column.label}
                </StyledTableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
           
            {rows
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row) => {
                return (
                  <StyledTableRow hover role="checkbox" tabIndex={-1} key={row.name}>
                    {
                    columns.map((column) => {
                      console.log(row);
                      const value = row[column.id];
                      return (
                        <StyledTableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth,    fontSize: '17px' }}
                  
                >
                   { value} 
                </StyledTableCell>

                       
                            
                      
                      );
                    })}
                  </StyledTableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  );
}
