var express=require('express');
var recommender=require('./getall');
var app=express();

var fs = require("fs");
  
const TelegramBot = require('node-telegram-bot-api');
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });

app.use(express.static('public'))

app.get('/getRecommendations',function(req,res)
{
 
    recommender.processAll(req.query.day, req.query.month, req.query.year, res);
     
});

app.get('/saveMonitorStocks',function(req,res)
{
     saveToMonitorList(req.query.shares);
     res.send({ status: 'Good' });
 
});

function saveToMonitorList(symbols){
 
    var dateObj = new Date();
    var dateStr = dateObj.getUTCDate() + "-" + (dateObj.getUTCMonth() + 1) + "-" + dateObj.getUTCFullYear();
       
    fs.writeFileSync(__dirname + "/" + dateStr + "_MONITOR.txt", symbols);

    bot.sendMessage(378345990, "New MANUAL List: " + symbols);
    return symbols;

}


var server=app.listen(3000,function() {});