var symbols = require('./symbols');
var recommender = require('./getall');
var fs = require("fs");
var elements = {};
var monitor = "";
var monitorElements = [];

const TelegramBot = require('node-telegram-bot-api');
const token = '896292620:AAGcScMjKHPr7JaBOfxnxOWLo4mLz7sk3F4';
const bot = new TelegramBot(token, { polling: false });

async function process() {
 
    var chatId;// = msg.chat.id;
    chatId = 378345990;

    var dateObj = new Date();
    var forDate = dateObj.getUTCDate()   ;
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();

    var dateStr = forDate + "-" + forMonth + "-" + forYear;

    monitor = fs.readFileSync(__dirname + "/" + "ALL_MONITOR.csv");

    elements = await symbols.getAllSymbols();

    elementsArray = monitor.toString().split(" ");
    for (var i = 0; i < elementsArray.length - 1; i++) {
        console.log(elementsArray[i]);
        monitorElements.push(elements[elementsArray[i]]);
    }

    // console.log(monitorElements);
    await recommender.getAllRecommendations(forDate, forMonth, forYear, monitorElements, true, 
        
        function(monitorData){

            newStocks = processMonitorStocks(monitorData);
           
            for(var i =0; i< newStocks.length; i++) { 
                bot.sendMessage(chatId, newStocks[i].message,  { parse_mode: "HTML" });
            }
            
 
        });

    
 
}

  

function getChartString(data, nolink) {
    var finalString = "";

    var dateObj = new Date();
    var forDate = dateObj.getUTCDate();
    var forMonth = dateObj.getUTCMonth() + 1;
    var forYear = dateObj.getUTCFullYear();

    var dateStr = forDate + "-" + forMonth + "-" + forYear;

    finalString = "<b>" + data.stockname + ":</b>" + data.rating + " " + dateStr + " DIFF: " + data.diff;
    finalString = finalString + "\nDRS: " + data.defaultResistence + " " + data.defaultSupport;
    finalString = finalString + "\nTRHL: " + data.trendReversalHigh + " " + data.trendReversalLow;
    // finalString = finalString + "\nFC: " + data.firstCandleHigh + "-" + data.firstCandleLow + "=" + data.diff;
    finalString = finalString + "\nBT: " + data.buyTarget1 + " " + data.buyTarget2 + " " + data.buyTarget3;
    finalString = finalString + "\nST: " + data.sellTarget1 + " " + data.sellTarget2 + " " + data.sellTarget3;
    // finalString = finalString + "\nCC: " + data.firstCandleClose + " " + data.secondCandleClose + " " + data.thirdCandleClose;
    finalString = finalString + "\nIHL: " + data.todayHigh + " " + data.todayLow;
    finalString = finalString + "\n<a href='" + data.link + "'>CHART</a> " + "\n\n";

    return finalString;

}

function processMonitorStocks(recommendations) {
    var chatId;// = msg.chat.id;
    chatId = 378345990;
    var monitorStocks = [];
    //Now, we have all the data. Let us try to find out if any stocks are in buy zone or sell zone. 
    for (var k = 0; k < recommendations.length; k++) {
 
        var todayData = recommendations[k].todayjson.data;
  
        var high2pm = todayData.candles[57][2];
        var low2pm = todayData.candles[57][3];

        // console.log('BTST High/Low: ' +  recommendations[k].stockname  + "- " + high2pm + "/" + low2pm);

        var highBefore3 = 0;
        var lowBefore3 = 99999999;
 
        var candleCount = todayData.candles.length;
        if(candleCount > 69) {
            candleCount = 69;
        }

        for (i = 0; i < candleCount; i++) {

            var candleData = todayData.candles[i];
            // console.log(candleData);
            if (candleData[2] > highBefore3) {
                highBefore3 = candleData[2];
            }
            if (candleData[3] < lowBefore3) {
                lowBefore3 = candleData[3];
            }
        }
        // console.log('BTST High/Low: ' +  recommendations[k].stockname  + "- " + highBefore3 + "/" + lowBefore3);

 
        var highAfter3= highBefore3;
        var lowAfter3 = lowBefore3; 

        if(todayjson.data.candles.length>69) {

            for (i = 69; i < todayData.candles.length; i++) {

                var candleData = todayData.candles[i];
                // console.log(candleData);
                if (candleData[2] > highAfter3) {
                    highAfter3 = candleData[2];
                }
                if (candleData[3] < lowAfter3) {
                    lowAfter3 = candleData[3];
                }
            }

        }
        var beyondThreshold = false;
        for (i = 58; i < todayData.candles.length  ; i++) {
            
            var candleData = todayData.candles[i];
            if (candleData[2] > high2pm) {
                // console.log('Broke high ' +  recommendations[k].stockname + " - " + candleData[2]);
                beyondThreshold = true;
                break;
            }
            if (candleData[3] < low2pm) {
                // console.log('Broke low ' + recommendations[k].stockname  + " - " + candleData[3] + " " + i);
                beyondThreshold = true;
                break;
            }
  
        }
        var message = "";
        if(!beyondThreshold) { 
            message = 'BTST High/Low: ' +  recommendations[k].stockname  + "- " + high2pm + "/" + low2pm ;
            bot.sendMessage(chatId, message);
        }

        if(highAfter3 > highBefore3) {
            message = 'BTST High : ' +   recommendations[k].stockname  + "- "  + highBefore3 + "- " + highAfter3 ;
            bot.sendMessage(chatId, message );
        }

        if(lowAfter3 < lowBefore3) {
            message = 'STBT Low: ' +   recommendations[k].stockname  + "- "  + lowBefore3 + "- " + lowAfter3 ;
            bot.sendMessage(chatId, message );
        }

        // var firstCandleHigh = recommendations[k].firstCandleHigh;
        // var firstCandleLow = recommendations[k].firstCandleLow;

        // var avgPrice = (parseFloat(firstCandleHigh) + parseFloat(firstCandleLow)) / 2;

        // var threshold = 0;
        // if (avgPrice <= 100) {
        //     threshold = avgPrice * 0.02;
        // } else if (avgPrice > 100 && avgPrice <= 1000) {
        //     threshold = avgPrice * 0.01;
        // } else if (avgPrice > 1000 && avgPrice <= 2000) {
        //     threshold = avgPrice * 0.008;
        // } else if (avgPrice > 2000 && avgPrice <= 5000) {
        //     threshold = avgPrice * 0.005;
        // } else if (avgPrice > 5000) {
        //     threshold = avgPrice * 0.001;
        // }


    
        //1-OPEN 2-HIGH 3-LOW 4-CLOSE
        // var cmp = todayData.candles[startIndex + 2][4];

        // console.log('sellnow/buynow: ' + sellNow + "/" + buyNow);

        // if (buyNow) {
        //     var buyRecommendation = getChartString(recommendations[k], true);
        //     var message = buyRecommendation + " " + buyStars +  (strongBuy ? "S." :"") + " BUY, CMP " + cmp + " with targets ";
        //     if(buyStars.length >= 3) { 
        //         message = message + recommendations[k].buyTarget1 + " " ;
        //     }
        //     if(buyStars.length >= 2) { 
        //         message = message + recommendations[k].buyTarget2 + " " ;
        //     }
        //     if(buyStars.length >= 1) { 
        //         message = message + recommendations[k].buyTarget3 + " " ;
        //     }
        //      // bot.sendMessage(chatId, message,  { parse_mode: "HTML" });

        //     if(buyStars.length >0 ) { 
        //         monitorStocks.push({ "name": recommendations[k].stockname, "rec": "BUY", "message": message });
        //     }
            
        // } else if (sellNow) {

        //     var sellRecommendation = getChartString(recommendations[k], true);
        //     var message = sellRecommendation + " " + sellStars + (strongSell ? "S." :"") + " SELL, CMP " + cmp + " with targets ";
        //     if(sellStars.length >= 3) {
        //         message = message + recommendations[k].sellTarget1 + " ";  
        //     } 
        //     if(sellStars.length >= 2) {
        //         message = message + recommendations[k].sellTarget2 + " ";  
        //     } 
        //     if(sellStars.length >= 1) {
        //         message = message + recommendations[k].sellTarget3 + " ";  
        //     } 
             
        //     // bot.sendMessage(chatId, message,  { parse_mode: "HTML" });
        //     if(sellStars.length > 0) { 
        //         monitorStocks.push({ "name": recommendations[k].stockname, "rec": "SELL", "message": message });
        //     }
       
        // } else {
        //     // monitorStocks = monitorStocks + recommendations[k].stockname+ " ";
        // }
    }
    return monitorStocks;

}
process();

