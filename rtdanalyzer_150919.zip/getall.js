const csv = require('csv-parser');
const fs = require('fs');
const request = require('request-promise');
var finalData = {};
const readAllData = () => {

    return new Promise((resolve, reject) => {
        let elements = [];
        fs.createReadStream(__dirname + '/data.csv')
            .pipe(csv())
            .on('data', (row) => {
                if (row.process == 'Y') {
                    elements.push(row);
                }
            })
            .on('end', () => {
                console.log('CSV file successfully processed');
                resolve(elements);
            });

    });
};

const getDataForScrip = (url) => {
    console.log(url);
    return new Promise((resolve, reject) => {
        const http = require('http'),
            https = require('https');

        let client = http;

        if (url.toString().indexOf("https") === 0) {
            client = https;
        }

        client.get(url, (resp) => {
            let data = '';

            // A chunk of data has been recieved.
            resp.on('data', (chunk) => {
                data += chunk;
            });

            // The whole response has been received. Print out the result.
            resp.on('end', () => {
                resolve(data);
            });

        }).on("error", (err) => {
            reject(err);
        });
    });
};


async function findPrevDate(day, month, year, id) {

    var analysisDate = new Date(year, month, day);

    var prevDate = analysisDate;

    for (i = 1; i < 6; i++) {
        prevDate.setDate(prevDate.getDate() - 1);

        var prevMonth = prevDate.getMonth();
        var prevDay = prevDate.getDate();
        var prevYear = prevDate.getFullYear();

        var forDate = prevYear + "-" + (prevMonth > 9 ? prevMonth : "0" + prevMonth) + "-" + (prevDay > 9 ? prevDay : "0" + prevDay);

        var url = 'https://kitecharts-aws.zerodha.com/api/chart/' + id + '/5minute?from=' + forDate + '&to=' + forDate + '&oi=1&public_token=undefined&access_token=';

        var prevFinalData = await getDataForScrip(url);
        prevDayjson = JSON.parse(prevFinalData);

        if (prevDayjson.data == null) {
            console.log('There is no data for ' + forDate);
            continue;
        }

        if (prevDayjson.data.candles.length == 0) {
            console.log('There is no data for ' + forDate);
            continue;
        }
        console.log('Prev day is ' + prevDate.getDate());
        return forDate;

    }
}

function findTrend(day, month, year, id, name, displayname, keepScrapedData, currentData, prevData) {

    var trend = { stock: name, stockname: displayname };

    var analysisDate = new Date(year, month, day);

    // console.log(analysisDate);
    //2019-06-14
    var forDate = year + "-" + (month > 9 ? month : "0" + month) + "-" + (day > 9 ? day : "0" + day);

    trend.forDate = forDate;

    var url = 'https://kitecharts-aws.zerodha.com/api/chart/' + id + '/5minute?from=' + forDate + '&to=' + forDate + '&oi=1&public_token=undefined&access_token=';

    trend.link = 'https://kite.zerodha.com/chart/ext/tvc/NFO-FUT/' + name + '/' + id;

    trend.link = 'https://kite.zerodha.com/chart/ext/tvc/NSE/' + name + '/' + id;

    todayjson = JSON.parse(currentData);

    if (keepScrapedData) {
        trend.todayjson = todayjson;
    }

    var firstCandleHigh = todayjson.data.candles[0][2];
    var firstCandleLow = todayjson.data.candles[0][3];

    var finalHourHigh = 0;
    var finalHourLow = 0;

    var high2pm = 0;
    var low2pm = 0;

    var above2pmHigh = false;
    var below2pmLow = false;

    if (todayjson.data.candles.length > 57) { //2:15 PM
        high2pm = todayjson.data.candles[57][2];
        low2pm = todayjson.data.candles[57][3];

        // finalHourLow = 9999999999;
        for (i = 58; i < todayjson.data.candles.length; i++) {
            var candleData = todayjson.data.candles[i];

            if (candleData[2] > high2pm) {
                above2pmHigh = true;
                break;
            }
            if (candleData[3] < low2pm) {
                below2pmLow = true;
                break;
            }
        }

    }

    trend.finalHourHigh = high2pm;
    trend.finalHourLow = low2pm;
    trend.finalHourDiff = (high2pm - low2pm).toFixed(2);

    trend.inLimits = "Y";

    if (above2pmHigh || below2pmLow) {
        trend.inLimits = "N";
    }

    var high = 0;
    var low = 9999999999;


    prevDayjson = JSON.parse(prevData);

    for (i = 0; i < prevDayjson.data.candles.length; i++) {
        var candleData = prevDayjson.data.candles[i];
        var curDate = new Date(candleData[0]);

        if (curDate.getUTCHours() >= 8) {
            if (curDate.getUTCHours() == 8 && curDate.getUTCMinutes() < 30)
                continue;

            if (candleData[2] > high) {

                high = candleData[2];

            }
            if (candleData[3] < low) {
                low = candleData[3];
            }
        }
    }

    var todayHigh = 0;
    var todayLow = 99999999;
    for (i = 0; i < todayjson.data.candles.length; i++) {
        var candleData = todayjson.data.candles[i];
        if (candleData[2] > todayHigh) {
            todayHigh = candleData[2];
        }
        if (candleData[3] < todayLow) {
            todayLow = candleData[3];
        }
    }

    trend.trendReversalHigh = 0;
    trend.trendReversalLow = 0;
    //8
    var trendReversalHigh = 0;
    var trendReversalLow = 99999999;
    if (todayjson.data.candles.length >= 9) {

        for (i = 0; i < 9; i++) {
            var candleData = todayjson.data.candles[i];
            // console.log(candleData);
            if (candleData[2] > trendReversalHigh) {
                trendReversalHigh = candleData[2];
            }
            if (candleData[3] < trendReversalLow) {
                trendReversalLow = candleData[3];
            }
        }
        trend.trendReversalHigh = trendReversalHigh;
        trend.trendReversalLow = trendReversalLow;

    }
    var lastCandle = todayjson.data.candles[todayjson.data.candles.length - 1];

    if (trendReversalHigh == 0) {
        trendReversalHigh = firstCandleHigh;
    }

    if (trendReversalLow == 99999999) {
        trendReversalLow = firstCandleLow;
    }

    trend.cmp = lastCandle[4];
    trend.cmp1 = lastCandle[4];

    trend.todayHigh = todayHigh;
    trend.todayLow = todayLow;

    trend.aboveTRHigh = "N";
    if (trendReversalHigh < todayHigh) {
        trend.aboveTRHigh = "Y";
    }

    trend.belowTRLow = "N";
    if (trendReversalLow > todayLow) {
        trend.belowTRLow = "Y";
    }

    trend.cmpAboveTRHigh = "N";
    if (trendReversalHigh < trend.cmp) {
        trend.cmpAboveTRHigh = "Y";
    }

    trend.cmpBelowTRLow = "N";
    if (trendReversalLow > trend.cmp) {
        trend.cmpBelowTRLow = "Y";
    }



    // console.log(name + " " + "PREVDAY HIGH/LOW: " + high + "/" + low);
    var diff = (firstCandleHigh - firstCandleLow);
    // console.log(name + " " + "FIRST CANDLE HIGH/LOW/DIFF: " + firstCandleHigh.toFixed(2) + "/" + firstCandleLow.toFixed(2) + "/" + diff.toFixed(2));

    trend.firstCandleHigh = firstCandleHigh;
    trend.firstCandleLow = firstCandleLow;
    trend.diff = parseFloat(diff.toFixed(2));

    diff = Math.trunc(diff);

    var bt1 = firstCandleHigh + diff;
    var bt2 = firstCandleHigh + diff + diff;
    var bt3 = firstCandleHigh + diff + diff + diff;

    var st1 = firstCandleLow - diff;
    var st2 = firstCandleLow - diff - diff;
    var st3 = firstCandleLow - diff - diff - diff;

    var avgPrice = (parseFloat(firstCandleHigh) + parseFloat(firstCandleLow)) / 2;

    var threshold = 0;
    if (avgPrice <= 100) {
        threshold = avgPrice * 0.02;
    } else if (avgPrice > 100 && avgPrice <= 1000) {
        threshold = avgPrice * 0.01;
    } else if (avgPrice > 1000 && avgPrice <= 2000) {
        threshold = avgPrice * 0.008;
    } else if (avgPrice > 2000 && avgPrice <= 5000) {
        threshold = avgPrice * 0.005;
    } else if (avgPrice > 5000) {
        threshold = avgPrice * 0.001;
    }

    trend.consider = 'Y';

    if (diff < threshold) {
        trend.consider = 'N';
    }

    var defaultSupport = low;
    var defaultResistence = high;

    trend.defaultSupport = defaultSupport;
    trend.defaultResistence = defaultResistence;

    var belowSupportCloseCount = 0;
    var aboveResistenceCloseCount = 0;
    var aboveSupportCloseCount = 0;
    var belowResistenceCloseCount = 0;

    for (i = 0; i < 3; i++) {
        var candleData = todayjson.data.candles[i];

        if (candleData[4] < defaultSupport) {
            belowSupportCloseCount++;
        }
        if (candleData[4] >= defaultSupport) {
            aboveSupportCloseCount++;
        }

        if (candleData[4] > defaultResistence) {
            aboveResistenceCloseCount++;
        }
        if (candleData[4] <= defaultResistence) {
            belowResistenceCloseCount++;
        }

        var curData = new Date(candleData[0]);
        // console.log(name + " " + curData.getHours() + ":" + curData.getMinutes() + " " + candleData[1]
        //     + " " + candleData[2] + " " + candleData[3] + " " + candleData[4]);

    }
    // console.log(name + " " + "belowSupportCloseCount/aboveResistenceCloseCount: " + belowSupportCloseCount + "/" + aboveResistenceCloseCount);

    trend.firstCandleClose = todayjson.data.candles[0][4];
    trend.secondCandleClose = todayjson.data.candles[1][4];
    trend.thirdCandleClose = todayjson.data.candles[2][4];

    trend.belowSupportCloseCount = belowSupportCloseCount;
    trend.aboveSupportCloseCount = aboveSupportCloseCount;

    trend.aboveResistenceCloseCount = aboveResistenceCloseCount;
    trend.belowResistenceCloseCount = belowResistenceCloseCount;

    trend.sellTarget1 = st1.toFixed(0);
    trend.sellTarget2 = st2.toFixed(0);
    trend.sellTarget3 = st3.toFixed(0);

    trend.buyTarget1 = bt1.toFixed(0);
    trend.buyTarget2 = bt2.toFixed(0);
    trend.buyTarget3 = bt3.toFixed(0);

    trend.sellStopLoss = firstCandleHigh.toFixed(0);
    trend.buyStopLoss = firstCandleLow.toFixed(0);

    var candleData = todayjson.data.candles[0];
    var firstCandleClose = candleData[4];
    var firstCandleHigh = candleData[2];
    var firstCandleLow = candleData[3];

    candleData = todayjson.data.candles[1];
    var secondCandleClose = candleData[4];
    var secondCandleHigh = candleData[2];
    var secondCandleLow = candleData[3];

    candleData = todayjson.data.candles[2];
    var thirdCandleClose = candleData[4];
    var thirdCandleHigh = candleData[2];
    var thirdCandleLow = candleData[3];

    var avgPrice = (firstCandleHigh + firstCandleLow) / 2;

    var changePercent = (diff / avgPrice) * 100;
    var finalHourDiffPercent = (trend.finalHourDiff / avgPrice) * 100;

    trend.changePercent = changePercent.toFixed(2);
    trend.finalHourDiffPercent = finalHourDiffPercent.toFixed(2);

    var buyStars = "";

    if (todayHigh < trend.buyTarget1) {
        buyStars = "***";
    } else if (todayHigh < trend.buyTarget2) {
        buyStars = "**";
    } else if (todayHigh < trend.buyTarget3) {
        buyStars = "*";
    }
    var sellStars = "";
    if (todayLow > trend.sellTarget1) {
        sellStars = "***";
    } else if (todayLow > trend.sellTarget2) {
        sellStars = "**";
    } else if (todayLow > trend.sellTarget3) {
        sellStars = "*";
    }

    trend.buyStars = buyStars;
    trend.sellStars = sellStars;
    trend.category = "Z";

    if (trend.cmpAboveTRHigh == "Y" && trend.buyStars.length >= 1) {
        trend["row-cls"] = "green";
        trend.category = "A"
    } else if (trend.aboveTRHigh == "Y" && trend.buyStars.length >= 1) {
        trend["row-cls"] = "greenyellow";
        trend.category = "B"
    }

    if (trend.cmpBelowTRLow == "Y" && trend.sellStars.length >= 1) {
        trend["row-cls"] = "red";
        trend.category = "C"
    } else if (trend.belowTRLow == "Y" && trend.sellStars.length >= 1) {
        trend["row-cls"] = "orangered";
        trend.category = "D"
    }

    if (trend.sellStars.length == 0 || trend.buyStars.length == 0) {
        trend["row-cls"] = "blue";
        trend.category = "E"
    }

    trend.rating = "";

    if (thirdCandleClose < defaultSupport) {
        //SELL
        if (firstCandleClose < defaultSupport && secondCandleClose < defaultSupport) {
            trend.recommendation = "ST.SELL";
            //If atleast one of the candles touched resistance, only then we can be sure of sell.
        } else if (firstCandleHigh > defaultResistence || secondCandleHigh > defaultResistence || thirdCandleHigh > defaultResistence) {
            trend.recommendation = "SELL";
        } else {
            trend.recommendation = "NOT CLEAR";
        }


    } else if (thirdCandleClose > defaultResistence) {
        //BUY

        if (firstCandleClose > defaultResistence && secondCandleClose > defaultResistence) {
            trend.recommendation = "ST.BUY";

            if (firstCandleClose <= secondCandleClose && firstCandleClose <= thirdCandleClose) {
                trend.rating = "*";
            }

            //If atleast one of the candles touched support, only then we can be sure of buy.
        } else if (firstCandleLow < defaultSupport || secondCandleLow < defaultSupport || thirdCandleLow < defaultSupport) {
            trend.recommendation = "BUY";
        } else {
            trend.recommendation = "NOT CLEAR";
        }

    } else { //Trend is not clear
        if ((firstCandleHigh > defaultResistence && secondCandleLow > defaultSupport) ||
            (secondCandleHigh > defaultResistence && firstCandleLow > defaultSupport) ||
            (thirdCandleHigh > defaultResistence && thirdCandleLow > defaultSupport)

        ) {
            trend.recommendation = "SELL";
        } else if ((firstCandleLow < defaultSupport && secondCandleHigh > defaultResistence) ||
            (secondCandleLow < defaultSupport && firstCandleHigh > defaultResistence) ||
            (thirdCandleLow < defaultSupport && thirdCandleHigh > defaultResistence)
        ) {
            trend.recommendation = "BUY";
        } else {
            trend.recommendation = "NOT CLEAR";
        }
    }

    return trend;
}

async function getAllRecommendation_Original(day, month, year, elements, recommendations, keepScrapedData) {

    for (const item of elements) {
        // console.log('processing ', item.name);
        recommendations.push(await findTrend(day, month, year, item.id, item.name, item.displayname, keepScrapedData));
        // console.log("FINAL RETURN: " , await findTrend(day, month, year, item.id, item.name));

    }
    return recommendations;
}

async function getAllRecommendation(day, month, year, elements, recommendations, keepScrapedData, res) {

    var prevDay = await findPrevDate(day, month, year, 5633);
    console.log(prevDay);

    var forDate = year + "-" + (month > 9 ? month : "0" + month) + "-" + (day > 9 ? day : "0" + day);

    selectedDateURLS = [];
    prevDateURLS = [];
    for (const item of elements) {

        // console.log('processing ', item.name);
        var url = 'https://kitecharts-aws.zerodha.com/api/chart/' + item.id + '/5minute?from=' + forDate + '&to=' + forDate + '&oi=1&public_token=undefined&access_token=';
        selectedDateURLS.push(url);
        var prevDayurl = 'https://kitecharts-aws.zerodha.com/api/chart/' + item.id + '/5minute?from=' + prevDay + '&to=' + prevDay + '&oi=1&public_token=undefined&access_token=';
        prevDateURLS.push(prevDayurl);
    }

    var currentDayData = [];
    var prevDayData = [];

    const promises = selectedDateURLS.map(url => request(url));

    Promise.all(promises).then((data) => {
        currentDayData.push(data);
        if (1 == currentDayData.length && 1 == prevDayData.length) {
            finalData = { todayData: currentDayData[0], prevdayData: prevDayData[0] };
            processItNow(day, month, year, elements, recommendations, keepScrapedData, res);
        }
    });

    const prevDayPromises = prevDateURLS.map(url => request(url));
    Promise.all(prevDayPromises).then((data) => {
        prevDayData.push(data);
        if (1 == currentDayData.length && 1 == prevDayData.length) {
            finalData = { todayData: currentDayData[0], prevdayData: prevDayData[0] };
            processItNow(day, month, year, elements, recommendations, keepScrapedData, res);
        }
    });

}

function processItNow(day, month, year, elements, recommendations, keepScrapedData, res) {
    console.log('Got the data and processing it now');
    var index = 0;
    for (const item of elements) {
        // console.log('processing ', item.name);
        recommendations.push(
            findTrend(day, month, year, item.id, item.name, item.displayname, keepScrapedData, finalData.todayData[index], finalData.prevdayData[index]));
        index++;
    }

    if (typeof res === "function") {
        res(recommendations);
    } else {
        res.send(recommendations);
    }
    return recommendations;
}

//This is what is called from web
async function getForAll(day, month, year, res) {
    elements = await readAllData();
    recommendations = [];
    // getAllRecommendation(10, 6, 2019, elements); //YESBANK

    await getAllRecommendation(day, month, year, elements, recommendations, false, res); //YESBANK
    console.log('Recommendations', recommendations);
    // res.send(recommendations);
}

async function getForAllNonWeb(day, month, year) {
    elements = await readAllData();
    recommendations = [];
    // getAllRecommendation(10, 6, 2019, elements); //YESBANK
    await getAllRecommendation(day, month, year, elements, recommendations); //YESBANK
    console.log(recommendations);
    return recommendations;
}

module.exports.processAll = function (day, month, year, res) {
    console.log("Received " + day);
    getForAll(day, month, year, res);
};

module.exports.processAllForNonWeb = async function (day, month, year) {
    console.log("Received " + day);
    return getForAllNonWeb(day, month, year);
};

module.exports.findTrend = async function (day, month, year, id, name, displayname) {

    return findTrend(day, month, year, id, name, displayname);
};

module.exports.getAllRecommendations = async function (day, month, year, elements, keepScrapedData, callback) {
    recommendations = [];
    return await getAllRecommendation(day, month, year, elements, recommendations, keepScrapedData, callback); //YESBANK
    // console.log(recommendations);
    // return recommendations;
};


// getForAll(8, 7, 2019);
