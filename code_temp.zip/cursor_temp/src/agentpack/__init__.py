"""agentpack: tool-agnostic AI coding agent rules, skills, and playbooks with bidirectional sync."""

__version__ = "0.1.0"
