"""Orchestration: export, status, and three-way sync across all adapters.

Sync classification per generated file:
  - native file on disk differs from lockfile hash  -> edited in-tool
  - canonical artifact differs from lockfile hash   -> edited in .agentpack/
  - both                                            -> conflict (never auto-overwrite)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .adapters.agentsmd import AgentsMdAdapter
from .adapters.base import Adapter, ImportedItem
from .adapters.claude import ClaudeAdapter
from .adapters.copilot import CopilotAdapter
from .adapters.cursor import CursorAdapter
from .adapters.devin import DevinAdapter
from .adapters.windsurf import WindsurfAdapter
from .core.fidelity import FidelityNote
from .core.lockfile import FileRecord, Lockfile, load_lockfile, save_lockfile
from .core.model import Pack, text_hash
from .core.pack import load_pack, pack_dir, save_pack

ADAPTERS: dict[str, Adapter] = {
    a.name: a
    for a in [
        AgentsMdAdapter(),
        CursorAdapter(),
        ClaudeAdapter(),
        WindsurfAdapter(),
        CopilotAdapter(),
        DevinAdapter(),
    ]
}

GITIGNORE_BEGIN = "# >>> agentpack generated (do not edit) >>>"
GITIGNORE_END = "# <<< agentpack generated <<<"
COMMITTED_FILES = {"AGENTS.md"}  # keep the open standard file in version control


@dataclass
class ExportReport:
    written: list[str] = field(default_factory=list)
    unchanged: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    notes: list[FidelityNote] = field(default_factory=list)


@dataclass
class FileStatus:
    target: str
    path: str
    state: str  # up-to-date | canonical-changed | modified-in-tool | conflict | missing | untracked
    artifacts: list[str] = field(default_factory=list)


@dataclass
class SyncReport:
    imported: list[str] = field(default_factory=list)
    conflicts: list[str] = field(default_factory=list)
    export: ExportReport | None = None
    notes: list[str] = field(default_factory=list)


def enabled_adapters(pack: Pack, only: list[str] | None = None) -> list[Adapter]:
    names = [t for t in pack.manifest.targets if only is None or t in only]
    return [ADAPTERS[n] for n in names if n in ADAPTERS]


def run_export(root: Path, targets: list[str] | None = None, dry_run: bool = False) -> ExportReport:
    pack = load_pack(root)
    lock = load_lockfile(pack_dir(root))
    report = ExportReport()

    for adapter in enabled_adapters(pack, targets):
        result = adapter.export(pack, root)
        report.notes.extend(result.notes)
        tlock = lock.target(adapter.name)
        generated_paths = set()

        for gf in result.files:
            generated_paths.add(gf.path)
            new_hash = text_hash(gf.content)
            existing = tlock.files.get(gf.path)
            disk = root / gf.path
            if existing and existing.hash == new_hash and disk.exists() \
                    and text_hash(disk.read_text(encoding="utf-8")) == new_hash:
                report.unchanged.append(gf.path)
                continue
            if not dry_run:
                disk.parent.mkdir(parents=True, exist_ok=True)
                disk.write_text(gf.content, encoding="utf-8")
                tlock.files[gf.path] = FileRecord(hash=new_hash, artifacts=gf.artifacts)
            report.written.append(gf.path)

        # Remove previously generated files that no longer exist canonically,
        # but only if the user has not modified them in-tool.
        for stale_path in [p for p in list(tlock.files) if p not in generated_paths]:
            record = tlock.files[stale_path]
            disk = root / stale_path
            if not dry_run:
                if disk.exists() and text_hash(disk.read_text(encoding="utf-8")) == record.hash:
                    disk.unlink()
                    report.removed.append(stale_path)
                del tlock.files[stale_path]
            else:
                report.removed.append(stale_path)

    if not dry_run:
        lock.artifacts = load_pack(root).artifact_hashes()
        save_lockfile(pack_dir(root), lock)
        if pack.manifest.gitignore_generated:
            _update_gitignore(root, lock)
    return report


def compute_status(root: Path) -> list[FileStatus]:
    pack = load_pack(root)
    lock = load_lockfile(pack_dir(root))
    current = pack.artifact_hashes()
    statuses: list[FileStatus] = []

    for target_name, tlock in lock.targets.items():
        for path, record in tlock.files.items():
            disk = root / path
            if not disk.exists():
                state = "missing"
            else:
                native_changed = text_hash(disk.read_text(encoding="utf-8")) != record.hash
                canonical_changed = any(
                    current.get(a) != lock.artifacts.get(a) for a in record.artifacts
                )
                if native_changed and canonical_changed:
                    state = "conflict"
                elif native_changed:
                    state = "modified-in-tool"
                elif canonical_changed:
                    state = "canonical-changed"
                else:
                    state = "up-to-date"
            statuses.append(FileStatus(target_name, path, state, record.artifacts))

    # New artifacts never exported yet.
    exported_artifacts = {a for t in lock.targets.values() for r in t.files.values() for a in r.artifacts}
    for key in current:
        if key not in lock.artifacts and key not in exported_artifacts and key != "context":
            statuses.append(FileStatus("-", f"(new artifact {key})", "canonical-changed", [key]))
    return statuses


def run_sync(root: Path, prefer: str | None = None, targets: list[str] | None = None) -> SyncReport:
    """Three-way sync: pull in-tool edits into canonical, then re-export everything."""
    pack = load_pack(root)
    lock = load_lockfile(pack_dir(root))
    current = pack.artifact_hashes()
    report = SyncReport()
    pack_changed = False

    for adapter in enabled_adapters(pack, targets):
        tlock = lock.target(adapter.name)
        result = adapter.import_(root)
        report.notes.extend(f"[{adapter.name}] {n}" for n in result.notes)

        for item in result.items:
            record = tlock.files.get(item.path)
            disk = root / item.path
            if not disk.exists():
                continue
            native_changed = (
                record is None  # file the tool user created by hand
                or text_hash(disk.read_text(encoding="utf-8")) != record.hash
            )
            if not native_changed:
                continue
            artifact_keys = record.artifacts if record else [item.key]
            canonical_changed = any(
                key in lock.artifacts and current.get(key) != lock.artifacts.get(key)
                for key in artifact_keys
            )
            label = f"{item.key} <- {item.path}"
            if canonical_changed and prefer is None:
                report.conflicts.append(label)
                continue
            if canonical_changed and prefer == "canonical":
                continue  # canonical wins; export below overwrites the native edit
            if _apply_import(pack, item):
                pack_changed = True
                report.imported.append(label)

    if pack_changed:
        save_pack(root, pack)
    report.export = run_export(root, targets)
    return report


def run_import(root: Path, sources: list[str]) -> tuple[list[str], list[str]]:
    """Bootstrap/merge canonical pack from existing native tool configs."""
    try:
        pack = load_pack(root)
    except FileNotFoundError:
        pack = Pack()
    imported: list[str] = []
    notes: list[str] = []
    for name in sources:
        adapter = ADAPTERS[name]
        result = adapter.import_(root)
        notes.extend(f"[{name}] {n}" for n in result.notes)
        for item in result.items:
            if _apply_import(pack, item):
                imported.append(f"{item.key} <- {item.path}")
    save_pack(root, pack)
    return imported, notes


def _apply_import(pack: Pack, item: ImportedItem) -> bool:
    if item.context is not None:
        if pack.context.strip() != item.context.strip():
            pack.context = item.context.strip()
            return True
        return False
    if item.rule is not None:
        existing = pack.rule_by_id(item.rule.id)
        merged = item.rule
        if existing is not None:
            # Preserve fields the native format cannot express.
            data = existing.model_dump()
            data["body"] = merged.body
            if merged.description:
                data["description"] = merged.description
            if merged.globs:
                data["globs"] = merged.globs
            data["activation"] = merged.activation
            merged = type(existing)(**data)
        if existing is None or existing.content_hash() != merged.content_hash():
            pack.upsert_rule(merged)
            return True
        return False
    if item.skill is not None:
        existing_skill = pack.skill_by_name(item.skill.name)
        merged_skill = item.skill
        if existing_skill is not None:
            data = existing_skill.model_dump()
            data["body"] = merged_skill.body
            if merged_skill.description:
                data["description"] = merged_skill.description
            for f in ("specifications", "advice", "forbidden_actions", "required_from_user"):
                if getattr(merged_skill, f):
                    data[f] = getattr(merged_skill, f)
            merged_skill = type(existing_skill)(**data)
        if existing_skill is None or existing_skill.content_hash() != merged_skill.content_hash():
            pack.upsert_skill(merged_skill)
            return True
        return False
    return False


def _update_gitignore(root: Path, lock: Lockfile) -> None:
    paths = sorted(
        {p for t in lock.targets.values() for p in t.files if p not in COMMITTED_FILES}
    )
    gi = root / ".gitignore"
    existing = gi.read_text(encoding="utf-8") if gi.exists() else ""
    lines = existing.splitlines()
    if GITIGNORE_BEGIN in lines and GITIGNORE_END in lines:
        start, stop = lines.index(GITIGNORE_BEGIN), lines.index(GITIGNORE_END)
        lines = lines[:start] + lines[stop + 1:]
    while lines and not lines[-1].strip():
        lines.pop()
    block = [GITIGNORE_BEGIN, *paths, GITIGNORE_END]
    content = "\n".join([*lines, "", *block]) .strip("\n") + "\n"
    gi.write_text(content, encoding="utf-8")
