"""agentpack CLI: init / import / export / sync / status / doctor / devin push|pull."""

from __future__ import annotations

import os
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from . import __version__
from .core.lockfile import load_lockfile, save_lockfile
from .core.model import ALL_TARGETS, Activation, Manifest, Pack, Rule, Skill
from .core.pack import PACK_DIRNAME, load_pack, pack_dir, save_pack
from .devin_api import DevinClient
from .doctor import run_doctor
from .engine import ADAPTERS, compute_status, run_export, run_import, run_sync

app = typer.Typer(
    name="agentpack",
    help="Tool-agnostic AI coding agent rules, skills, and playbooks with bidirectional sync.",
    no_args_is_help=True,
)
devin_app = typer.Typer(help="Push/pull knowledge notes and playbooks via the Devin v3 API.")
app.add_typer(devin_app, name="devin")

console = Console()

SAMPLE_CONTEXT = """\
# Project overview

Describe what this project is, the tech stack (language, framework, database),
and the setup/build/test commands. Every supported agent reads this via AGENTS.md.

## Setup commands
- Install dependencies: `...`
- Run tests: `...`

## Conventions
- Commit format: ...
"""

SAMPLE_RULE = Rule(
    id="example-conventions",
    description="Example scoped rule; applies when matching files are in context",
    activation=Activation.GLOB,
    globs=["src/**/*"],
    body="- Replace this with real conventions for the matched files.\n- Delete this rule when done.",
)

SAMPLE_SKILL = Skill(
    name="example-review",
    description="Example skill/playbook; invoked on demand in each tool",
    body="1. Read the diff.\n2. Check for issues.\n3. Report findings.",
    specifications=["A summary of findings is produced"],
    forbidden_actions=["Do not push directly to main"],
)


def _version_callback(value: bool):
    if value:
        console.print(f"agentpack {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True),
):
    pass


@app.command()
def init(
    root: Path = typer.Option(Path("."), "--root", help="Repository root"),
    project: str = typer.Option(None, "--project", help="Project name"),
):
    """Scaffold .agentpack/ with a sample rule and skill; detect existing tool configs."""
    root = root.resolve()
    pdir = pack_dir(root)
    if pdir.exists():
        console.print(f"[yellow]{PACK_DIRNAME}/ already exists in {root}[/yellow]")
        raise typer.Exit(1)

    pack = Pack(
        manifest=Manifest(project=project or root.name),
        context=SAMPLE_CONTEXT,
        rules=[SAMPLE_RULE],
        skills=[SAMPLE_SKILL],
    )
    save_pack(root, pack)
    console.print(f"[green]Initialized {PACK_DIRNAME}/ in {root}[/green]")

    detected = [name for name, a in ADAPTERS.items() if a.detect(root)]
    if detected:
        console.print(
            f"\nDetected existing native configs: [bold]{', '.join(detected)}[/bold]\n"
            f"Bootstrap the canonical pack from them with:\n"
            f"  agentpack import --from {' --from '.join(detected)}"
        )
    console.print("\nNext: edit .agentpack/, then run [bold]agentpack export[/bold].")


@app.command(name="import")
def import_cmd(
    sources: list[str] = typer.Option(..., "--from", help=f"Source tool(s): {list(ADAPTERS)} or 'all'"),
    root: Path = typer.Option(Path("."), "--root"),
):
    """Bootstrap or merge the canonical pack from existing native tool configs."""
    root = root.resolve()
    if "all" in sources:
        sources = [name for name, a in ADAPTERS.items() if a.detect(root)]
        if not sources:
            console.print("[yellow]No native tool configs detected.[/yellow]")
            raise typer.Exit(1)
    unknown = [s for s in sources if s not in ADAPTERS]
    if unknown:
        console.print(f"[red]Unknown source(s): {unknown}. Valid: {list(ADAPTERS)}[/red]")
        raise typer.Exit(1)

    imported, notes = run_import(root, sources)
    for note in notes:
        console.print(f"[dim]{note}[/dim]")
    if imported:
        console.print(f"[green]Imported {len(imported)} artifact(s):[/green]")
        for line in imported:
            console.print(f"  + {line}")
    else:
        console.print("Nothing new to import.")
    console.print("\nReview .agentpack/, then run [bold]agentpack export[/bold].")


@app.command()
def export(
    target: list[str] = typer.Option(None, "--target", help="Limit to specific targets"),
    root: Path = typer.Option(Path("."), "--root"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be written"),
):
    """Generate native config files for every enabled target."""
    root = root.resolve()
    targets = list(target) if target else None
    report = run_export(root, targets=targets, dry_run=dry_run)

    verb = "Would write" if dry_run else "Wrote"
    for path in report.written:
        console.print(f"[green]{verb}[/green] {path}")
    for path in report.removed:
        console.print(f"[red]{'Would remove' if dry_run else 'Removed'}[/red] {path}")
    if report.unchanged:
        console.print(f"[dim]{len(report.unchanged)} file(s) unchanged[/dim]")
    if report.notes:
        console.print("\n[bold yellow]Fidelity notes (lossy conversions):[/bold yellow]")
        for note in report.notes:
            console.print(f"  [yellow]![/yellow] {note}")


@app.command()
def status(root: Path = typer.Option(Path("."), "--root")):
    """Show sync state of every generated file vs the canonical pack."""
    root = root.resolve()
    statuses = compute_status(root)
    if not statuses:
        console.print("Nothing exported yet. Run [bold]agentpack export[/bold].")
        return
    table = Table(title="agentpack status")
    table.add_column("Target")
    table.add_column("File")
    table.add_column("State")
    colors = {
        "up-to-date": "green", "canonical-changed": "cyan",
        "modified-in-tool": "yellow", "conflict": "red", "missing": "red",
    }
    for s in statuses:
        table.add_row(s.target, s.path, f"[{colors.get(s.state, 'white')}]{s.state}[/]")
    console.print(table)
    if any(s.state in ("canonical-changed", "modified-in-tool") for s in statuses):
        console.print("Run [bold]agentpack sync[/bold] to reconcile.")
    if any(s.state == "conflict" for s in statuses):
        console.print("[red]Conflicts present[/red]: resolve with "
                      "[bold]agentpack sync --prefer canonical|native[/bold].")


@app.command()
def sync(
    prefer: str = typer.Option(None, "--prefer", help="Conflict resolution: canonical | native"),
    target: list[str] = typer.Option(None, "--target"),
    root: Path = typer.Option(Path("."), "--root"),
):
    """Bidirectional sync: pull in-tool edits into .agentpack/, then re-export everywhere."""
    root = root.resolve()
    if prefer is not None and prefer not in ("canonical", "native"):
        console.print("[red]--prefer must be 'canonical' or 'native'[/red]")
        raise typer.Exit(1)
    report = run_sync(root, prefer=prefer, targets=list(target) if target else None)

    for note in report.notes:
        console.print(f"[dim]{note}[/dim]")
    for line in report.imported:
        console.print(f"[cyan]Imported[/cyan] {line}")
    if report.conflicts:
        console.print("\n[bold red]Conflicts (both sides changed; skipped):[/bold red]")
        for line in report.conflicts:
            console.print(f"  [red]x[/red] {line}")
        console.print("Re-run with [bold]--prefer canonical[/bold] or [bold]--prefer native[/bold].")
    if report.export:
        for path in report.export.written:
            console.print(f"[green]Wrote[/green] {path}")
        if report.export.notes:
            console.print("\n[bold yellow]Fidelity notes:[/bold yellow]")
            for note in report.export.notes:
                console.print(f"  [yellow]![/yellow] {note}")
    if not report.imported and not report.conflicts:
        console.print("[green]In sync.[/green]")


@app.command()
def doctor(root: Path = typer.Option(Path("."), "--root")):
    """Lint the canonical pack: dead globs, missing descriptions, oversized rules, duplicates."""
    root = root.resolve()
    pack = load_pack(root)
    findings = run_doctor(root, pack)
    if not findings:
        console.print("[green]No issues found.[/green]")
        return
    errors = 0
    for f in findings:
        color = "red" if f.level == "error" else "yellow"
        console.print(f"[{color}]{f.level}[/{color}] {f.subject}: {f.message}")
        errors += f.level == "error"
    if errors:
        raise typer.Exit(1)


def _devin_client(root: Path) -> tuple[Pack, DevinClient]:
    pack = load_pack(root)
    cfg = pack.manifest.devin
    token = os.environ.get(cfg.api_key_env, "")
    return pack, DevinClient(cfg.api_base, cfg.org_id, token)


@devin_app.command()
def push(root: Path = typer.Option(Path("."), "--root")):
    """Push rules as Devin knowledge notes and skills as playbooks (idempotent)."""
    root = root.resolve()
    pack, client = _devin_client(root)
    lock = load_lockfile(pack_dir(root))
    report = client.push(pack, lock)
    save_lockfile(pack_dir(root), lock)
    for key in report.created:
        console.print(f"[green]Created[/green] {key}")
    for key in report.updated:
        console.print(f"[cyan]Updated[/cyan] {key}")
    if report.unchanged:
        console.print(f"[dim]{len(report.unchanged)} unchanged[/dim]")


@devin_app.command()
def pull(root: Path = typer.Option(Path("."), "--root")):
    """Pull Devin knowledge notes and playbooks into the canonical pack."""
    root = root.resolve()
    pack, client = _devin_client(root)
    lock = load_lockfile(pack_dir(root))
    report = client.pull(pack, lock)
    save_pack(root, pack)
    save_lockfile(pack_dir(root), lock)
    for key in report.added:
        console.print(f"[green]Added[/green] {key}")
    for key in report.updated:
        console.print(f"[cyan]Updated[/cyan] {key}")
    if report.unchanged:
        console.print(f"[dim]{len(report.unchanged)} unchanged[/dim]")
    if report.added or report.updated:
        console.print("Run [bold]agentpack export[/bold] to propagate to other tools.")


if __name__ == "__main__":
    app()
