"""Doctor: lint the canonical pack for problems that degrade agent behavior."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from wcmatch import glob as wglob

from .core.model import Activation, Pack

WINDSURF_CHAR_LIMIT = 12_000
BODY_LENGTH_WARN = 8_000  # chars; long rules dilute context

_SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__", ".agentpack"}


@dataclass
class Finding:
    level: str  # error | warning
    subject: str
    message: str


def _repo_files(root: Path, limit: int = 20_000) -> list[str]:
    files: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        rel_dir = Path(dirpath).relative_to(root)
        for fn in filenames:
            files.append((rel_dir / fn).as_posix())
            if len(files) >= limit:
                return files
    return files


def run_doctor(root: Path, pack: Pack) -> list[Finding]:
    findings: list[Finding] = []

    seen_rules: set[str] = set()
    for rule in pack.rules:
        if rule.id in seen_rules:
            findings.append(Finding("error", rule.key, "duplicate rule id"))
        seen_rules.add(rule.id)
    seen_skills: set[str] = set()
    for skill in pack.skills:
        if skill.name in seen_skills:
            findings.append(Finding("error", skill.key, "duplicate skill name"))
        seen_skills.add(skill.name)

    repo_files = _repo_files(root)
    for rule in pack.rules:
        if rule.activation is Activation.GLOB and not rule.globs:
            findings.append(Finding("error", rule.key, "activation is glob but no globs defined"))
        if rule.activation is Activation.MODEL_DECISION and not rule.description:
            findings.append(
                Finding("warning", rule.key,
                        "model_decision rule without a description; agents cannot decide relevance")
            )
        if not rule.body.strip():
            findings.append(Finding("error", rule.key, "rule body is empty"))
        if len(rule.body) > BODY_LENGTH_WARN:
            findings.append(
                Finding("warning", rule.key,
                        f"body is {len(rule.body)} chars; consider splitting (context bloat)")
            )
        if len(rule.body) > WINDSURF_CHAR_LIMIT and "windsurf" in pack.manifest.targets:
            findings.append(
                Finding("warning", rule.key,
                        f"over Windsurf's {WINDSURF_CHAR_LIMIT}-char limit; will be truncated there")
            )
        for pattern in rule.globs:
            try:
                matched = wglob.globfilter(repo_files, pattern,
                                           flags=wglob.GLOBSTAR | wglob.BRACE)
            except Exception:
                findings.append(Finding("error", rule.key, f"invalid glob pattern: {pattern!r}"))
                continue
            if not matched:
                findings.append(
                    Finding("warning", rule.key,
                            f"glob {pattern!r} matches no files in this repo (dead glob?)")
                )

    for skill in pack.skills:
        if not skill.description:
            findings.append(
                Finding("warning", skill.key,
                        "skill has no description; auto-invocation will not work in Claude/Devin")
            )
        if not skill.body.strip():
            findings.append(Finding("error", skill.key, "skill body (procedure) is empty"))

    if not pack.context.strip():
        findings.append(
            Finding("warning", "context",
                    "global context is empty; agents get no project overview via AGENTS.md")
        )
    return findings
