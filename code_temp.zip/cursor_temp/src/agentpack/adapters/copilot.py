"""GitHub Copilot adapter.

- Glob rules      -> .github/instructions/<id>.instructions.md with `applyTo`
- model_decision  -> .github/instructions/<id>.instructions.md with `description`
                     (VS Code applies these via semantic matching; other surfaces
                     require manual attachment — fidelity note emitted)
- always rules + context -> delivered via AGENTS.md when that target is enabled
                     (Copilot reads AGENTS.md); otherwise .github/copilot-instructions.md
- Skills          -> .github/prompts/<name>.prompt.md
"""

from __future__ import annotations

from pathlib import Path

from ..core.fidelity import FidelityNote
from ..core.markers import first_marker, marker, parse_markers, split_sections, strip_markers
from ..core.model import Activation, Pack, Rule, Skill, artifact_hash
from .base import Adapter, ExportResult, GeneratedFile, ImportedItem, ImportResult
from .common import (
    apply_sections,
    dump_frontmatter,
    globs_to_str,
    load_frontmatter,
    parse_globs,
    render_skill_sections,
    rule_from_marker,
    rule_marker,
    skill_marker,
)

REPO_WIDE = ".github/copilot-instructions.md"
INSTRUCTIONS_DIR = ".github/instructions"
PROMPTS_DIR = ".github/prompts"


class CopilotAdapter(Adapter):
    name = "copilot"
    description = "GitHub Copilot (.github/copilot-instructions.md, instructions/, prompts/)"

    def detect(self, root: Path) -> bool:
        return (root / REPO_WIDE).exists() or (root / INSTRUCTIONS_DIR).exists()

    def export(self, pack: Pack, root: Path) -> ExportResult:
        result = ExportResult()

        if "agentsmd" not in pack.manifest.targets:
            # No AGENTS.md layer: fall back to a generated repo-wide instructions file.
            parts = [
                marker("file", target=self.name),
                marker("context", hash=artifact_hash({"body": pack.context})),
                pack.context.strip(),
            ]
            artifacts = ["context"]
            for rule in pack.rules_for_target(self.name):
                if rule.activation is not Activation.ALWAYS:
                    continue
                parts += ["", rule_marker(rule), f"## {rule.description or rule.id}",
                          rule.body.strip()]
                artifacts.append(rule.key)
            result.files.append(
                GeneratedFile(REPO_WIDE, "\n".join(parts).strip() + "\n", artifacts)
            )

        for rule in pack.rules_for_target(self.name):
            if rule.activation is Activation.ALWAYS:
                continue  # handled above or via AGENTS.md
            meta: dict = {}
            if rule.activation is Activation.GLOB:
                meta["applyTo"] = globs_to_str(rule.globs)
            if rule.description:
                meta["description"] = rule.description
            if rule.activation is Activation.MODEL_DECISION:
                result.notes.append(
                    FidelityNote(self.name, rule.key,
                                 "model_decision maps to description-based matching "
                                 "(VS Code only); other Copilot surfaces need manual attach")
                )
            elif rule.activation is Activation.MANUAL:
                result.notes.append(
                    FidelityNote(self.name, rule.key,
                                 "manual rule exported without applyTo; attach manually in chat")
                )
            body = f"{rule_marker(rule)}\n\n{rule.body.strip()}"
            result.files.append(
                GeneratedFile(
                    f"{INSTRUCTIONS_DIR}/{rule.id}.instructions.md",
                    dump_frontmatter(meta, body),
                    [rule.key],
                )
            )

        for skill in pack.skills_for_target(self.name):
            meta = {"description": skill.description or skill.name}
            body_parts = [skill_marker(skill), "", skill.body.strip()]
            sections = render_skill_sections(skill)
            if sections:
                body_parts += ["", sections]
            result.files.append(
                GeneratedFile(
                    f"{PROMPTS_DIR}/{skill.name}.prompt.md",
                    dump_frontmatter(meta, "\n".join(body_parts)),
                    [skill.key],
                )
            )
        return result

    def import_(self, root: Path) -> ImportResult:
        result = ImportResult()

        repo_wide = root / REPO_WIDE
        if repo_wide.exists():
            text = repo_wide.read_text(encoding="utf-8")
            if first_marker(text, "file") is None:
                result.items.append(
                    ImportedItem(
                        path=REPO_WIDE,
                        rule=Rule(id="copilot-instructions-imported",
                                  activation=Activation.ALWAYS, body=text.strip()),
                    )
                )
                result.notes.append(f"{REPO_WIDE}: hand-written; imported as always-on rule")
            else:
                all_markers = parse_markers(text)
                ctx_end = next((end for k, _, _, end in all_markers if k == "context"), None)
                if ctx_end is not None:
                    first_rule = next((s for k, _, s, _ in all_markers if k == "rule"), len(text))
                    result.items.append(
                        ImportedItem(path=REPO_WIDE,
                                     context=strip_markers(text[ctx_end:first_rule]))
                    )
                for attrs, section in split_sections(text, "rule"):
                    lines = section.splitlines()
                    if lines and lines[0].lstrip().startswith("## "):
                        lines = lines[1:]
                    result.items.append(
                        ImportedItem(path=REPO_WIDE,
                                     rule=rule_from_marker(attrs, "\n".join(lines).strip()))
                    )

        instructions_dir = root / INSTRUCTIONS_DIR
        if instructions_dir.exists():
            for path in sorted(instructions_dir.rglob("*.instructions.md")):
                text = path.read_text(encoding="utf-8")
                meta, body = load_frontmatter(text)
                rel = path.relative_to(root).as_posix()
                attrs = first_marker(body, "rule")
                if attrs:
                    rule = rule_from_marker(attrs, body)
                    rule = self._merge_native(rule, meta, body)
                else:
                    globs = parse_globs(meta.get("applyTo"))
                    stem = path.name.removesuffix(".instructions.md")
                    rule = Rule(
                        id=stem,
                        description=str(meta.get("description") or ""),
                        activation=Activation.GLOB if globs else Activation.MODEL_DECISION,
                        globs=globs,
                        body=strip_markers(body),
                    )
                    result.notes.append(f"{rel}: no marker; inferred rule '{rule.id}'")
                result.items.append(ImportedItem(path=rel, rule=rule))

        prompts_dir = root / PROMPTS_DIR
        if prompts_dir.exists():
            for path in sorted(prompts_dir.glob("*.prompt.md")):
                meta, body = load_frontmatter(path.read_text(encoding="utf-8"))
                rel = f"{PROMPTS_DIR}/{path.name}"
                attrs = first_marker(body, "skill")
                name = attrs["name"] if attrs else path.name.removesuffix(".prompt.md")
                kwargs = apply_sections(
                    {"name": name, "description": str(meta.get("description") or "")}, body
                )
                result.items.append(ImportedItem(path=rel, skill=Skill(**kwargs)))
        return result

    @staticmethod
    def _merge_native(rule: Rule, meta: dict, body: str) -> Rule:
        data = rule.model_dump()
        data["body"] = strip_markers(body)
        if "description" in meta:
            data["description"] = str(meta.get("description") or "")
        native_globs = parse_globs(meta.get("applyTo"))
        if native_globs:
            data["globs"] = native_globs
            data["activation"] = Activation.GLOB
        return Rule(**data)
