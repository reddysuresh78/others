"""Helpers shared by adapters: frontmatter rendering, marker round-trips,
and Devin-style structured skill sections."""

from __future__ import annotations

import io
import re

import frontmatter
from ruamel.yaml import YAML

from ..core.markers import marker, strip_markers
from ..core.model import Activation, Rule, Skill

_yaml = YAML()
_yaml.default_flow_style = False

SECTION_FIELDS = [
    ("specifications", "Specifications"),
    ("advice", "Advice"),
    ("forbidden_actions", "Forbidden Actions"),
    ("required_from_user", "Required from User"),
]


def dump_frontmatter(metadata: dict, body: str) -> str:
    buf = io.StringIO()
    _yaml.dump(metadata, buf)
    return f"---\n{buf.getvalue()}---\n\n{body.strip()}\n"


def load_frontmatter(text: str) -> tuple[dict, str]:
    post = frontmatter.loads(text)
    return dict(post.metadata), post.content.strip()


def globs_to_str(globs: list[str]) -> str:
    return ",".join(globs)


def parse_globs(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [g.strip() for g in value.split(",") if g.strip()]
    return [str(g).strip() for g in value if str(g).strip()]


def rule_marker(rule: Rule) -> str:
    """Marker carrying full activation metadata so lossy targets round-trip cleanly."""
    attrs = {
        "id": rule.id,
        "hash": rule.content_hash(),
        "activation": rule.activation.value,
    }
    if rule.globs:
        attrs["globs"] = globs_to_str(rule.globs)
    if rule.description:
        attrs["description"] = rule.description
    return marker("rule", **attrs)


def skill_marker(skill: Skill) -> str:
    return marker("skill", name=skill.name, hash=skill.content_hash())


def rule_from_marker(attrs: dict[str, str], body: str) -> Rule:
    return Rule(
        id=attrs["id"],
        description=attrs.get("description", ""),
        activation=Activation(attrs.get("activation", "always")),
        globs=parse_globs(attrs.get("globs")),
        body=strip_markers(body),
    )


def render_skill_sections(skill: Skill) -> str:
    """Render structured playbook sections as markdown appended to the body."""
    parts = []
    for field_name, heading in SECTION_FIELDS:
        values = getattr(skill, field_name)
        if values:
            bullets = "\n".join(f"- {v}" for v in values)
            parts.append(f"## {heading}\n{bullets}")
    return "\n\n".join(parts)


_SECTION_RE = re.compile(
    r"^##\s+(Specifications|Advice|Forbidden Actions|Required from User)\s*$",
    re.IGNORECASE | re.MULTILINE,
)
_HEADING_TO_FIELD = {h.lower(): f for f, h in SECTION_FIELDS}


def parse_skill_sections(text: str) -> tuple[str, dict[str, list[str]]]:
    """Split structured sections back out of a rendered skill body.

    Returns (body_without_sections, {field: [bullet, ...]}).
    """
    matches = list(_SECTION_RE.finditer(text))
    if not matches:
        return text.strip(), {}
    body = text[: matches[0].start()].strip()
    sections: dict[str, list[str]] = {}
    for i, m in enumerate(matches):
        stop = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        chunk = text[m.end():stop]
        field_name = _HEADING_TO_FIELD[m.group(1).lower()]
        bullets = [
            line.strip()[2:].strip()
            for line in chunk.splitlines()
            if line.strip().startswith("- ")
        ]
        sections[field_name] = bullets
    return body, sections


def apply_sections(skill_kwargs: dict, body: str) -> dict:
    """Parse rendered sections out of `body` and fold them into Skill kwargs."""
    clean_body, sections = parse_skill_sections(body)
    skill_kwargs["body"] = strip_markers(clean_body)
    skill_kwargs.update(sections)
    return skill_kwargs
