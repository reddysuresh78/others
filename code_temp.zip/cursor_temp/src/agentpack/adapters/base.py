"""Adapter interface: every tool adapter implements export (canonical -> native)
and import (native -> canonical)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

from ..core.fidelity import FidelityNote
from ..core.model import Pack, Rule, Skill


@dataclass
class GeneratedFile:
    path: str  # repo-root-relative posix path
    content: str
    artifacts: list[str] = field(default_factory=list)  # artifact keys contained


@dataclass
class ExportResult:
    files: list[GeneratedFile] = field(default_factory=list)
    notes: list[FidelityNote] = field(default_factory=list)


@dataclass
class ImportedItem:
    """One canonical artifact recovered from a native file."""

    path: str  # repo-root-relative source file
    rule: Rule | None = None
    skill: Skill | None = None
    context: str | None = None

    @property
    def key(self) -> str:
        if self.rule is not None:
            return self.rule.key
        if self.skill is not None:
            return self.skill.key
        return "context"


@dataclass
class ImportResult:
    items: list[ImportedItem] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


class Adapter(ABC):
    name: str = ""
    description: str = ""

    @abstractmethod
    def detect(self, root: Path) -> bool:
        """True if this tool's native config exists in the repo."""

    @abstractmethod
    def export(self, pack: Pack, root: Path) -> ExportResult:
        """Render canonical artifacts into native files (in memory; engine writes)."""

    @abstractmethod
    def import_(self, root: Path) -> ImportResult:
        """Parse native files back into canonical artifacts."""
