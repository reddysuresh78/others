"""Claude Code adapter.

- Rules are exported as modular files under .claude/rules/, referenced from a thin
  CLAUDE.md via @imports (preserves modularity instead of flattening to a monolith).
- Skills are exported natively as .claude/skills/<name>/SKILL.md.
- Claude has no conditional activation, so glob/model_decision metadata is preserved
  in provenance markers plus a human-readable "Applies to" line, and a fidelity note
  is emitted for the degradation.
"""

from __future__ import annotations

from pathlib import Path

from ..core.fidelity import FidelityNote
from ..core.markers import first_marker, marker, strip_markers
from ..core.model import Activation, Pack, Rule, Skill
from .base import Adapter, ExportResult, GeneratedFile, ImportedItem, ImportResult
from .common import (
    apply_sections,
    dump_frontmatter,
    load_frontmatter,
    render_skill_sections,
    rule_from_marker,
    rule_marker,
    skill_marker,
)

CLAUDE_MD = "CLAUDE.md"
RULES_DIR = ".claude/rules"
SKILLS_DIR = ".claude/skills"


class ClaudeAdapter(Adapter):
    name = "claude"
    description = "Claude Code (CLAUDE.md with @imports, .claude/skills/*/SKILL.md)"

    def detect(self, root: Path) -> bool:
        return (root / CLAUDE_MD).exists() or (root / ".claude").exists()

    def export(self, pack: Pack, root: Path) -> ExportResult:
        result = ExportResult()
        imports: list[str] = []

        for rule in pack.rules_for_target(self.name):
            if rule.activation is Activation.ALWAYS and "agentsmd" in pack.manifest.targets:
                continue  # delivered once via @AGENTS.md import below
            parts = [rule_marker(rule)]
            if rule.activation is Activation.GLOB and rule.globs:
                parts.append(f"Applies to files matching: `{', '.join(rule.globs)}`")
                result.notes.append(
                    FidelityNote(self.name, rule.key,
                                 "glob activation degraded to always-loaded (annotated in file)")
                )
            elif rule.activation is Activation.MODEL_DECISION:
                result.notes.append(
                    FidelityNote(self.name, rule.key,
                                 "model_decision activation degraded to always-loaded")
                )
            elif rule.activation is Activation.MANUAL:
                result.notes.append(
                    FidelityNote(self.name, rule.key,
                                 "manual rule is always-loaded in Claude Code")
                )
            parts += ["", rule.body.strip()]
            rel = f"{RULES_DIR}/{rule.id}.md"
            result.files.append(GeneratedFile(rel, "\n".join(parts).strip() + "\n", [rule.key]))
            imports.append(f"@{rel}")

        claude_lines = [
            marker("file", target=self.name),
            f"# {pack.manifest.project}",
            "",
        ]
        if "agentsmd" in pack.manifest.targets:
            claude_lines += ["Project context and always-on conventions:", "", "@AGENTS.md", ""]
        if imports:
            claude_lines += ["## Rules", ""] + imports + [""]
        result.files.append(
            GeneratedFile(CLAUDE_MD, "\n".join(claude_lines).strip() + "\n", [])
        )

        for skill in pack.skills_for_target(self.name):
            meta: dict = {"name": skill.name, "description": skill.description}
            if skill.allowed_tools:
                meta["allowed-tools"] = ", ".join(skill.allowed_tools)
            body_parts = [skill_marker(skill), "", skill.body.strip()]
            sections = render_skill_sections(skill)
            if sections:
                body_parts += ["", sections]
            result.files.append(
                GeneratedFile(
                    f"{SKILLS_DIR}/{skill.name}/SKILL.md",
                    dump_frontmatter(meta, "\n".join(body_parts)),
                    [skill.key],
                )
            )
        return result

    def import_(self, root: Path) -> ImportResult:
        result = ImportResult()

        rules_dir = root / RULES_DIR
        if rules_dir.exists():
            for path in sorted(rules_dir.glob("*.md")):
                text = path.read_text(encoding="utf-8")
                rel = f"{RULES_DIR}/{path.name}"
                attrs = first_marker(text, "rule")
                if attrs:
                    rule = rule_from_marker(attrs, self._strip_applies_line(text))
                else:
                    rule = Rule(id=path.stem, activation=Activation.ALWAYS,
                                body=strip_markers(text))
                    result.notes.append(f"{rel}: no marker; imported as always-on rule")
                result.items.append(ImportedItem(path=rel, rule=rule))

        claude_md = root / CLAUDE_MD
        if claude_md.exists():
            text = claude_md.read_text(encoding="utf-8")
            if first_marker(text, "file") is None:
                # Hand-written CLAUDE.md: import as an always-on rule.
                result.items.append(
                    ImportedItem(
                        path=CLAUDE_MD,
                        rule=Rule(id="claude-md-imported", activation=Activation.ALWAYS,
                                  body=text.strip()),
                    )
                )
                result.notes.append(f"{CLAUDE_MD}: hand-written; imported as rule 'claude-md-imported'")

        skills_dir = root / SKILLS_DIR
        if skills_dir.exists():
            for skill_md in sorted(skills_dir.glob("*/SKILL.md")):
                meta, body = load_frontmatter(skill_md.read_text(encoding="utf-8"))
                rel = f"{SKILLS_DIR}/{skill_md.parent.name}/SKILL.md"
                tools_raw = meta.get("allowed-tools") or ""
                tools = ([t.strip() for t in tools_raw.split(",") if t.strip()]
                         if isinstance(tools_raw, str) else list(tools_raw))
                kwargs = apply_sections(
                    {
                        "name": str(meta.get("name") or skill_md.parent.name),
                        "description": str(meta.get("description") or ""),
                        "allowed_tools": tools,
                    },
                    body,
                )
                result.items.append(ImportedItem(path=rel, skill=Skill(**kwargs)))

        # Legacy commands become skills on import (Claude merged commands into skills).
        commands_dir = root / ".claude/commands"
        if commands_dir.exists():
            for path in sorted(commands_dir.glob("*.md")):
                meta, body = load_frontmatter(path.read_text(encoding="utf-8"))
                rel = f".claude/commands/{path.name}"
                kwargs = apply_sections(
                    {"name": path.stem, "description": str(meta.get("description") or "")},
                    body,
                )
                result.items.append(ImportedItem(path=rel, skill=Skill(**kwargs)))
                result.notes.append(f"{rel}: legacy command imported as skill '{path.stem}'")
        return result

    @staticmethod
    def _strip_applies_line(text: str) -> str:
        lines = [
            line for line in strip_markers(text).splitlines()
            if not line.strip().startswith("Applies to files matching:")
        ]
        return "\n".join(lines).strip()
