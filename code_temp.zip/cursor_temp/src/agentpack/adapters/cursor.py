"""Cursor adapter: .cursor/rules/*.mdc (rules) and .cursor/commands/*.md (skills).

Cursor's four activation modes map 1:1 onto the canonical model:
  always         -> alwaysApply: true
  glob           -> globs + alwaysApply: false
  model_decision -> description + alwaysApply: false
  manual         -> alwaysApply: false, no globs/description
"""

from __future__ import annotations

from pathlib import Path

from ..core.fidelity import FidelityNote
from ..core.markers import first_marker, strip_markers
from ..core.model import Activation, Pack, Rule, Skill
from .base import Adapter, ExportResult, GeneratedFile, ImportedItem, ImportResult
from .common import (
    apply_sections,
    dump_frontmatter,
    globs_to_str,
    load_frontmatter,
    parse_globs,
    render_skill_sections,
    rule_from_marker,
    rule_marker,
    skill_marker,
)

RULES_DIR = ".cursor/rules"
COMMANDS_DIR = ".cursor/commands"


class CursorAdapter(Adapter):
    name = "cursor"
    description = "Cursor (.cursor/rules/*.mdc, .cursor/commands/*.md)"

    def detect(self, root: Path) -> bool:
        return (root / RULES_DIR).exists() or (root / ".cursorrules").exists()

    def export(self, pack: Pack, root: Path) -> ExportResult:
        result = ExportResult()
        for rule in pack.rules_for_target(self.name):
            if rule.activation is Activation.ALWAYS and "agentsmd" in pack.manifest.targets:
                # Always-on content is delivered once via AGENTS.md, which Cursor reads.
                continue
            meta: dict = {"description": rule.description or None}
            if rule.activation is Activation.ALWAYS:
                meta["alwaysApply"] = True
            else:
                meta["alwaysApply"] = False
                if rule.activation is Activation.GLOB:
                    meta["globs"] = globs_to_str(rule.globs)
                elif rule.activation is Activation.MANUAL:
                    meta["description"] = None
            meta = {k: v for k, v in meta.items() if v is not None}
            body = f"{rule_marker(rule)}\n\n{rule.body.strip()}"
            result.files.append(
                GeneratedFile(f"{RULES_DIR}/{rule.id}.mdc", dump_frontmatter(meta, body), [rule.key])
            )

        for skill in pack.skills_for_target(self.name):
            parts = [skill_marker(skill), f"# {skill.name}", ""]
            if skill.description:
                parts += [skill.description, ""]
            parts.append(skill.body.strip())
            sections = render_skill_sections(skill)
            if sections:
                parts += ["", sections]
            content = "\n".join(parts).strip() + "\n"
            result.files.append(
                GeneratedFile(f"{COMMANDS_DIR}/{skill.name}.md", content, [skill.key])
            )
            if skill.allowed_tools:
                result.notes.append(
                    FidelityNote(self.name, skill.key,
                                 "allowed-tools not supported by Cursor commands; omitted")
                )
        return result

    def import_(self, root: Path) -> ImportResult:
        result = ImportResult()
        rules_dir = root / RULES_DIR
        if rules_dir.exists():
            for path in sorted(rules_dir.glob("*.mdc")):
                text = path.read_text(encoding="utf-8")
                meta, body = load_frontmatter(text)
                rel = f"{RULES_DIR}/{path.name}"
                attrs = first_marker(body, "rule")
                if attrs:
                    rule = rule_from_marker(attrs, body)
                    # Native frontmatter/body edits win over stale marker copies.
                    rule = self._merge_native(rule, meta, body)
                else:
                    rule = self._infer_rule(path.stem, meta, body)
                    result.notes.append(f"{rel}: no marker; inferred rule '{rule.id}'")
                result.items.append(ImportedItem(path=rel, rule=rule))

        legacy = root / ".cursorrules"
        if legacy.exists():
            body = legacy.read_text(encoding="utf-8").strip()
            result.items.append(
                ImportedItem(
                    path=".cursorrules",
                    rule=Rule(id="cursorrules-legacy", activation=Activation.ALWAYS, body=body),
                )
            )
            result.notes.append(".cursorrules (legacy): imported as always-on rule 'cursorrules-legacy'")

        commands_dir = root / COMMANDS_DIR
        if commands_dir.exists():
            for path in sorted(commands_dir.glob("*.md")):
                text = path.read_text(encoding="utf-8")
                rel = f"{COMMANDS_DIR}/{path.name}"
                attrs = first_marker(text, "skill")
                name = attrs["name"] if attrs else path.stem
                body = strip_markers(text)
                lines = body.splitlines()
                description = ""
                if lines and lines[0].startswith("# "):
                    lines = lines[1:]
                    if lines and lines[0].strip() == "":
                        lines = lines[1:]
                    if lines and lines[0].strip() and not lines[0].startswith("#"):
                        description = lines[0].strip()
                        lines = lines[1:]
                kwargs = apply_sections(
                    {"name": name, "description": description}, "\n".join(lines).strip()
                )
                result.items.append(ImportedItem(path=rel, skill=Skill(**kwargs)))
        return result

    @staticmethod
    def _merge_native(rule: Rule, meta: dict, body: str) -> Rule:
        data = rule.model_dump()
        data["body"] = strip_markers(body)
        if "description" in meta:
            data["description"] = str(meta.get("description") or "")
        native_globs = parse_globs(meta.get("globs"))
        if native_globs:
            data["globs"] = native_globs
        if meta.get("alwaysApply") is True:
            data["activation"] = Activation.ALWAYS
        elif native_globs:
            data["activation"] = Activation.GLOB
        return Rule(**data)

    @staticmethod
    def _infer_rule(stem: str, meta: dict, body: str) -> Rule:
        globs = parse_globs(meta.get("globs"))
        description = str(meta.get("description") or "")
        if meta.get("alwaysApply") is True:
            activation = Activation.ALWAYS
        elif globs:
            activation = Activation.GLOB
        elif description:
            activation = Activation.MODEL_DECISION
        else:
            activation = Activation.MANUAL
        return Rule(
            id=stem, description=description, activation=activation,
            globs=globs, body=strip_markers(body),
        )
