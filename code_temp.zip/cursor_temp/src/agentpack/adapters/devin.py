"""Devin adapter (file mode).

Devin reads AGENTS.md natively (handled by the agentsmd adapter), so file mode only
needs to materialize skills as playbook markdown under .devin/playbooks/ — these can
be attached to a Devin session or pushed to the org Library with `agentpack devin push`.

Conditionally-activated rules (glob / model_decision) have no repo-file representation
for Devin; they are covered by API mode (knowledge notes with trigger descriptions).
"""

from __future__ import annotations

from pathlib import Path

from ..core.fidelity import FidelityNote
from ..core.markers import first_marker, strip_markers
from ..core.model import Activation, Pack, Skill
from .base import Adapter, ExportResult, GeneratedFile, ImportedItem, ImportResult
from .common import apply_sections, render_skill_sections, skill_marker

PLAYBOOKS_DIR = ".devin/playbooks"


def render_playbook(skill: Skill) -> str:
    """Render a canonical skill as a Devin playbook (Procedure/Specifications/...)."""
    parts = [skill_marker(skill), f"# {skill.name}", ""]
    if skill.description:
        parts += [skill.description, ""]
    parts += ["## Procedure", skill.body.strip()]
    sections = render_skill_sections(skill)
    if sections:
        parts += ["", sections]
    return "\n".join(parts).strip() + "\n"


def parse_playbook(name: str, text: str) -> Skill:
    attrs = first_marker(text, "skill")
    skill_name = attrs["name"] if attrs else name
    body = strip_markers(text)

    lines = body.splitlines()
    description = ""
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
        while lines and not lines[0].strip():
            lines = lines[1:]
        desc_lines = []
        while lines and lines[0].strip() and not lines[0].startswith("#"):
            desc_lines.append(lines[0].strip())
            lines = lines[1:]
        description = " ".join(desc_lines)
    body = "\n".join(lines).strip()
    if body.startswith("## Procedure"):
        body = body[len("## Procedure"):].lstrip("\n")

    kwargs = apply_sections({"name": skill_name, "description": description}, body)
    return Skill(**kwargs)


class DevinAdapter(Adapter):
    name = "devin"
    description = "Devin (AGENTS.md via agentsmd, .devin/playbooks/, v3 API push/pull)"

    def detect(self, root: Path) -> bool:
        return (root / ".devin").exists()

    def export(self, pack: Pack, root: Path) -> ExportResult:
        result = ExportResult()
        for skill in pack.skills_for_target(self.name):
            result.files.append(
                GeneratedFile(f"{PLAYBOOKS_DIR}/{skill.name}.md", render_playbook(skill),
                              [skill.key])
            )
        for rule in pack.rules_for_target(self.name):
            if rule.activation in (Activation.GLOB, Activation.MODEL_DECISION):
                result.notes.append(
                    FidelityNote(self.name, rule.key,
                                 "conditional rules have no Devin repo-file form; "
                                 "run `agentpack devin push` to sync as a knowledge note")
                )
        return result

    def import_(self, root: Path) -> ImportResult:
        result = ImportResult()
        playbooks_dir = root / PLAYBOOKS_DIR
        if playbooks_dir.exists():
            for path in sorted(playbooks_dir.glob("*.md")):
                rel = f"{PLAYBOOKS_DIR}/{path.name}"
                skill = parse_playbook(path.stem, path.read_text(encoding="utf-8"))
                result.items.append(ImportedItem(path=rel, skill=skill))
        return result
