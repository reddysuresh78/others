"""AGENTS.md adapter: the shared always-on layer.

All five supported tools (Cursor, Claude Code, Windsurf, Copilot, Devin) read
AGENTS.md natively, so the global context plus every `activation: always` rule is
emitted here exactly once instead of being duplicated into each tool's config.
"""

from __future__ import annotations

from pathlib import Path

from ..core.markers import first_marker, marker, parse_markers, split_sections, strip_markers
from ..core.model import Activation, Pack, artifact_hash
from .base import Adapter, ExportResult, GeneratedFile, ImportedItem, ImportResult
from .common import rule_from_marker, rule_marker

AGENTS_MD = "AGENTS.md"


class AgentsMdAdapter(Adapter):
    name = "agentsmd"
    description = "AGENTS.md (open standard, read by all supported tools)"

    def detect(self, root: Path) -> bool:
        return (root / AGENTS_MD).exists()

    def export(self, pack: Pack, root: Path) -> ExportResult:
        parts = [
            marker("file", target=self.name),
            f"# {pack.manifest.project} — Agent Instructions",
            "",
            marker("context", hash=artifact_hash({"body": pack.context})),
            pack.context.strip(),
        ]
        artifacts = ["context"]
        for rule in pack.rules_for_target(self.name):
            if rule.activation is not Activation.ALWAYS:
                continue
            parts += ["", rule_marker(rule), f"## {rule.description or rule.id}", rule.body.strip()]
            artifacts.append(rule.key)
        content = "\n".join(parts).strip() + "\n"
        return ExportResult(files=[GeneratedFile(AGENTS_MD, content, artifacts)])

    def import_(self, root: Path) -> ImportResult:
        path = root / AGENTS_MD
        result = ImportResult()
        if not path.exists():
            return result
        text = path.read_text(encoding="utf-8")

        if first_marker(text, "file") is None and first_marker(text, "context") is None:
            # Hand-written AGENTS.md: treat the whole file as global context.
            result.items.append(ImportedItem(path=AGENTS_MD, context=text.strip()))
            result.notes.append(f"{AGENTS_MD}: no agentpack markers; imported whole file as context")
            return result

        all_markers = parse_markers(text)
        context_start = next((end for k, _, _, end in all_markers if k == "context"), None)
        if context_start is not None:
            first_rule_start = next((start for k, _, start, _ in all_markers if k == "rule"), len(text))
            body = text[context_start:first_rule_start].strip()
            result.items.append(ImportedItem(path=AGENTS_MD, context=strip_markers(body)))

        for attrs, section_body in split_sections(text, "rule"):
            # Drop the generated "## heading" line; the body follows it.
            lines = section_body.splitlines()
            if lines and lines[0].lstrip().startswith("## "):
                lines = lines[1:]
            rule = rule_from_marker(attrs, "\n".join(lines).strip())
            result.items.append(ImportedItem(path=AGENTS_MD, rule=rule))
        return result
