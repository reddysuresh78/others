"""Windsurf adapter: .windsurf/rules/*.md and .windsurf/workflows/*.md.

Windsurf's trigger model maps 1:1 to canonical activation:
  always         -> trigger: always_on
  glob           -> trigger: glob + globs
  model_decision -> trigger: model_decision + description
  manual         -> trigger: manual

Workspace rule files are limited to 12,000 characters; oversized exports get a
fidelity warning (Windsurf truncates over-budget rules).
"""

from __future__ import annotations

from pathlib import Path

from ..core.fidelity import FidelityNote
from ..core.markers import first_marker, strip_markers
from ..core.model import Activation, Pack, Rule, Skill
from .base import Adapter, ExportResult, GeneratedFile, ImportedItem, ImportResult
from .common import (
    apply_sections,
    dump_frontmatter,
    globs_to_str,
    load_frontmatter,
    parse_globs,
    render_skill_sections,
    rule_from_marker,
    rule_marker,
    skill_marker,
)

RULES_DIR = ".windsurf/rules"
WORKFLOWS_DIR = ".windsurf/workflows"
CHAR_LIMIT = 12_000

_ACTIVATION_TO_TRIGGER = {
    Activation.ALWAYS: "always_on",
    Activation.GLOB: "glob",
    Activation.MODEL_DECISION: "model_decision",
    Activation.MANUAL: "manual",
}
_TRIGGER_TO_ACTIVATION = {v: k for k, v in _ACTIVATION_TO_TRIGGER.items()}


class WindsurfAdapter(Adapter):
    name = "windsurf"
    description = "Windsurf (.windsurf/rules/*.md, .windsurf/workflows/*.md)"

    def detect(self, root: Path) -> bool:
        return (root / ".windsurf").exists() or (root / ".windsurfrules").exists()

    def export(self, pack: Pack, root: Path) -> ExportResult:
        result = ExportResult()
        for rule in pack.rules_for_target(self.name):
            if rule.activation is Activation.ALWAYS and "agentsmd" in pack.manifest.targets:
                continue  # delivered via AGENTS.md, which Windsurf reads
            meta: dict = {"trigger": _ACTIVATION_TO_TRIGGER[rule.activation]}
            if rule.description:
                meta["description"] = rule.description
            if rule.activation is Activation.GLOB:
                meta["globs"] = globs_to_str(rule.globs)
            body = f"{rule_marker(rule)}\n\n{rule.body.strip()}"
            content = dump_frontmatter(meta, body)
            if len(content) > CHAR_LIMIT:
                result.notes.append(
                    FidelityNote(self.name, rule.key,
                                 f"rule is {len(content)} chars, over Windsurf's {CHAR_LIMIT} limit; "
                                 "it will be truncated by Windsurf — consider splitting")
                )
            result.files.append(
                GeneratedFile(f"{RULES_DIR}/{rule.id}.md", content, [rule.key])
            )

        for skill in pack.skills_for_target(self.name):
            meta = {"description": skill.description or skill.name}
            body_parts = [skill_marker(skill), "", skill.body.strip()]
            sections = render_skill_sections(skill)
            if sections:
                body_parts += ["", sections]
            result.files.append(
                GeneratedFile(
                    f"{WORKFLOWS_DIR}/{skill.name}.md",
                    dump_frontmatter(meta, "\n".join(body_parts)),
                    [skill.key],
                )
            )
            if skill.allowed_tools:
                result.notes.append(
                    FidelityNote(self.name, skill.key,
                                 "allowed-tools not supported by Windsurf workflows; omitted")
                )
        return result

    def import_(self, root: Path) -> ImportResult:
        result = ImportResult()
        rules_dir = root / RULES_DIR
        if rules_dir.exists():
            for path in sorted(rules_dir.glob("*.md")):
                text = path.read_text(encoding="utf-8")
                meta, body = load_frontmatter(text)
                rel = f"{RULES_DIR}/{path.name}"
                attrs = first_marker(body, "rule")
                if attrs:
                    rule = rule_from_marker(attrs, body)
                    rule = self._merge_native(rule, meta, body)
                else:
                    activation = _TRIGGER_TO_ACTIVATION.get(
                        str(meta.get("trigger", "")), Activation.MODEL_DECISION
                    )
                    rule = Rule(
                        id=path.stem,
                        description=str(meta.get("description") or ""),
                        activation=activation,
                        globs=parse_globs(meta.get("globs")),
                        body=strip_markers(body),
                    )
                    result.notes.append(f"{rel}: no marker; inferred rule '{rule.id}'")
                result.items.append(ImportedItem(path=rel, rule=rule))

        legacy = root / ".windsurfrules"
        if legacy.exists():
            result.items.append(
                ImportedItem(
                    path=".windsurfrules",
                    rule=Rule(id="windsurfrules-legacy", activation=Activation.ALWAYS,
                              body=legacy.read_text(encoding="utf-8").strip()),
                )
            )
            result.notes.append(".windsurfrules (legacy): imported as always-on rule")

        workflows_dir = root / WORKFLOWS_DIR
        if workflows_dir.exists():
            for path in sorted(workflows_dir.glob("*.md")):
                meta, body = load_frontmatter(path.read_text(encoding="utf-8"))
                rel = f"{WORKFLOWS_DIR}/{path.name}"
                attrs = first_marker(body, "skill")
                name = attrs["name"] if attrs else path.stem
                kwargs = apply_sections(
                    {"name": name, "description": str(meta.get("description") or "")}, body
                )
                result.items.append(ImportedItem(path=rel, skill=Skill(**kwargs)))
        return result

    @staticmethod
    def _merge_native(rule: Rule, meta: dict, body: str) -> Rule:
        data = rule.model_dump()
        data["body"] = strip_markers(body)
        if "description" in meta:
            data["description"] = str(meta.get("description") or "")
        trigger = str(meta.get("trigger") or "")
        if trigger in _TRIGGER_TO_ACTIVATION:
            data["activation"] = _TRIGGER_TO_ACTIVATION[trigger]
        native_globs = parse_globs(meta.get("globs"))
        if native_globs:
            data["globs"] = native_globs
        return Rule(**data)
