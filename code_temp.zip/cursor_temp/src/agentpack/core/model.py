"""Canonical data model: the single source of truth stored in .agentpack/."""

from __future__ import annotations

import hashlib
import json
from enum import Enum

from pydantic import BaseModel, Field, field_validator

# Target identifiers. "agentsmd" is the shared always-on layer read by all five tools.
ALL_TARGETS = ["agentsmd", "cursor", "claude", "windsurf", "copilot", "devin"]


class Activation(str, Enum):
    """Superset of activation semantics across Cursor, Windsurf, Copilot, Claude, Devin."""

    ALWAYS = "always"                  # cursor alwaysApply / windsurf always_on / AGENTS.md
    GLOB = "glob"                      # cursor globs / windsurf glob / copilot applyTo
    MODEL_DECISION = "model_decision"  # cursor description mode / windsurf model_decision / devin trigger
    MANUAL = "manual"                  # cursor @mention / windsurf manual


class Rule(BaseModel):
    """A passive context rule (knowledge) with conditional activation."""

    id: str
    description: str = ""
    activation: Activation = Activation.MODEL_DECISION
    globs: list[str] = Field(default_factory=list)
    targets: list[str] | None = None  # None means all enabled targets
    body: str = ""

    @field_validator("id")
    @classmethod
    def _id_slug(cls, v: str) -> str:
        if not v or any(c for c in v if not (c.isalnum() or c in "-_")):
            raise ValueError(f"rule id must be a slug (letters, digits, -, _): {v!r}")
        return v

    @property
    def key(self) -> str:
        return f"rule:{self.id}"

    def content_hash(self) -> str:
        return artifact_hash(self.model_dump(mode="json"))


class Skill(BaseModel):
    """An invocable procedure: skill / command / workflow / prompt file / playbook."""

    name: str
    description: str = ""
    allowed_tools: list[str] = Field(default_factory=list)
    # Devin playbook-style structured sections; folded into body text for other tools.
    specifications: list[str] = Field(default_factory=list)
    advice: list[str] = Field(default_factory=list)
    forbidden_actions: list[str] = Field(default_factory=list)
    required_from_user: list[str] = Field(default_factory=list)
    targets: list[str] | None = None
    body: str = ""  # the procedure itself, markdown

    @field_validator("name")
    @classmethod
    def _name_slug(cls, v: str) -> str:
        if not v or any(c for c in v if not (c.isalnum() or c in "-_")):
            raise ValueError(f"skill name must be a slug (letters, digits, -, _): {v!r}")
        return v

    @property
    def key(self) -> str:
        return f"skill:{self.name}"

    def content_hash(self) -> str:
        return artifact_hash(self.model_dump(mode="json"))


class DevinConfig(BaseModel):
    org_id: str = ""
    api_base: str = "https://api.devin.ai"
    api_key_env: str = "DEVIN_API_KEY"


class Manifest(BaseModel):
    project: str = "my-project"
    targets: list[str] = Field(default_factory=lambda: list(ALL_TARGETS))
    gitignore_generated: bool = True
    devin: DevinConfig = Field(default_factory=DevinConfig)

    @field_validator("targets")
    @classmethod
    def _known_targets(cls, v: list[str]) -> list[str]:
        unknown = [t for t in v if t not in ALL_TARGETS]
        if unknown:
            raise ValueError(f"unknown targets {unknown}; valid: {ALL_TARGETS}")
        return v


class Pack(BaseModel):
    """Everything under .agentpack/ parsed into memory."""

    manifest: Manifest = Field(default_factory=Manifest)
    context: str = ""  # global project context -> AGENTS.md body
    rules: list[Rule] = Field(default_factory=list)
    skills: list[Skill] = Field(default_factory=list)

    def rule_by_id(self, rule_id: str) -> Rule | None:
        return next((r for r in self.rules if r.id == rule_id), None)

    def skill_by_name(self, name: str) -> Skill | None:
        return next((s for s in self.skills if s.name == name), None)

    def upsert_rule(self, rule: Rule) -> None:
        for i, r in enumerate(self.rules):
            if r.id == rule.id:
                self.rules[i] = rule
                return
        self.rules.append(rule)

    def upsert_skill(self, skill: Skill) -> None:
        for i, s in enumerate(self.skills):
            if s.name == skill.name:
                self.skills[i] = skill
                return
        self.skills.append(skill)

    def artifact_hashes(self) -> dict[str, str]:
        hashes: dict[str, str] = {"context": artifact_hash({"body": self.context})}
        for r in self.rules:
            hashes[r.key] = r.content_hash()
        for s in self.skills:
            hashes[s.key] = s.content_hash()
        return hashes

    def rules_for_target(self, target: str) -> list[Rule]:
        return [r for r in self.rules if r.targets is None or target in r.targets]

    def skills_for_target(self, target: str) -> list[Skill]:
        return [s for s in self.skills if s.targets is None or target in s.targets]


def artifact_hash(data: dict) -> str:
    """Stable short hash of a canonical artifact for lockfile + provenance markers."""
    blob = json.dumps(data, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:12]


def text_hash(text: str) -> str:
    """Hash of a generated file's content (newline-normalized)."""
    normalized = text.replace("\r\n", "\n").strip() + "\n"
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:12]
