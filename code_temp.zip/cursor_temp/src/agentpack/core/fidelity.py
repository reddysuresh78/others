"""Fidelity notes: explicit warnings whenever an export is lossy for a target."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class FidelityNote:
    target: str
    artifact: str  # artifact key, e.g. "rule:typescript"
    message: str

    def __str__(self) -> str:
        return f"[{self.target}] {self.artifact}: {self.message}"
