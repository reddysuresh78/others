"""Read and write the canonical .agentpack/ directory.

Layout:
    .agentpack/
    ├── pack.yaml               # Manifest
    ├── context/project.md      # global context -> AGENTS.md body
    ├── rules/<id>.md           # frontmatter: description, activation, globs, targets
    ├── skills/<name>/SKILL.md  # frontmatter: description, allowed-tools, devin sections
    └── lock.json
"""

from __future__ import annotations

import io
from pathlib import Path

import frontmatter
from ruamel.yaml import YAML

from .model import Activation, Manifest, Pack, Rule, Skill

PACK_DIRNAME = ".agentpack"

_yaml = YAML()
_yaml.default_flow_style = False


def pack_dir(root: Path) -> Path:
    return root / PACK_DIRNAME


def _dump_frontmatter(metadata: dict, body: str) -> str:
    """Serialize markdown + YAML frontmatter (stable key order, no python-specific tags)."""
    buf = io.StringIO()
    _yaml.dump(metadata, buf)
    return f"---\n{buf.getvalue()}---\n\n{body.strip()}\n"


def load_pack(root: Path) -> Pack:
    pdir = pack_dir(root)
    if not pdir.exists():
        raise FileNotFoundError(
            f"No {PACK_DIRNAME}/ directory found in {root}. Run `agentpack init` first."
        )

    manifest_path = pdir / "pack.yaml"
    manifest = Manifest()
    if manifest_path.exists():
        data = _yaml.load(manifest_path.read_text(encoding="utf-8")) or {}
        manifest = Manifest.model_validate(dict(data))

    context = ""
    context_path = pdir / "context" / "project.md"
    if context_path.exists():
        context = context_path.read_text(encoding="utf-8").strip()

    rules: list[Rule] = []
    rules_dir = pdir / "rules"
    if rules_dir.exists():
        for path in sorted(rules_dir.glob("*.md")):
            post = frontmatter.loads(path.read_text(encoding="utf-8"))
            meta = dict(post.metadata)
            globs = meta.get("globs") or []
            if isinstance(globs, str):
                globs = [g.strip() for g in globs.split(",") if g.strip()]
            rules.append(
                Rule(
                    id=str(meta.get("id") or path.stem),
                    description=str(meta.get("description") or ""),
                    activation=Activation(meta.get("activation", "model_decision")),
                    globs=list(globs),
                    targets=meta.get("targets"),
                    body=post.content.strip(),
                )
            )

    skills: list[Skill] = []
    skills_dir = pdir / "skills"
    if skills_dir.exists():
        for skill_md in sorted(skills_dir.glob("*/SKILL.md")):
            post = frontmatter.loads(skill_md.read_text(encoding="utf-8"))
            meta = dict(post.metadata)
            skills.append(
                Skill(
                    name=str(meta.get("name") or skill_md.parent.name),
                    description=str(meta.get("description") or ""),
                    allowed_tools=list(meta.get("allowed-tools") or []),
                    specifications=list(meta.get("specifications") or []),
                    advice=list(meta.get("advice") or []),
                    forbidden_actions=list(meta.get("forbidden_actions") or []),
                    required_from_user=list(meta.get("required_from_user") or []),
                    targets=meta.get("targets"),
                    body=post.content.strip(),
                )
            )

    return Pack(manifest=manifest, context=context, rules=rules, skills=skills)


def save_pack(root: Path, pack: Pack) -> None:
    pdir = pack_dir(root)
    pdir.mkdir(parents=True, exist_ok=True)

    buf = io.StringIO()
    _yaml.dump(pack.manifest.model_dump(mode="json"), buf)
    (pdir / "pack.yaml").write_text(buf.getvalue(), encoding="utf-8")

    context_dir = pdir / "context"
    context_dir.mkdir(exist_ok=True)
    (context_dir / "project.md").write_text(pack.context.strip() + "\n", encoding="utf-8")

    rules_dir = pdir / "rules"
    rules_dir.mkdir(exist_ok=True)
    wanted_rules = {f"{r.id}.md" for r in pack.rules}
    for stale in rules_dir.glob("*.md"):
        if stale.name not in wanted_rules:
            stale.unlink()
    for rule in pack.rules:
        meta: dict = {
            "id": rule.id,
            "description": rule.description,
            "activation": rule.activation.value,
        }
        if rule.globs:
            meta["globs"] = list(rule.globs)
        if rule.targets is not None:
            meta["targets"] = list(rule.targets)
        (rules_dir / f"{rule.id}.md").write_text(
            _dump_frontmatter(meta, rule.body), encoding="utf-8"
        )

    skills_dir = pdir / "skills"
    skills_dir.mkdir(exist_ok=True)
    for skill in pack.skills:
        sdir = skills_dir / skill.name
        sdir.mkdir(exist_ok=True)
        meta = {"name": skill.name, "description": skill.description}
        if skill.allowed_tools:
            meta["allowed-tools"] = list(skill.allowed_tools)
        for field in ("specifications", "advice", "forbidden_actions", "required_from_user"):
            values = getattr(skill, field)
            if values:
                meta[field] = list(values)
        if skill.targets is not None:
            meta["targets"] = list(skill.targets)
        (sdir / "SKILL.md").write_text(_dump_frontmatter(meta, skill.body), encoding="utf-8")
