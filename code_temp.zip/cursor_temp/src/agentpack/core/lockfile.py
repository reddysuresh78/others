"""Lockfile: records what was exported where, enabling three-way sync.

.agentpack/lock.json stores, per target, the hash of each generated file at export
time, plus the canonical hash of every artifact. At sync time we compare:

  - native file on disk vs lockfile hash  -> did someone edit in-tool?
  - canonical artifact vs lockfile hash   -> did someone edit .agentpack/?
"""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import BaseModel, Field

LOCK_FILENAME = "lock.json"


class FileRecord(BaseModel):
    hash: str
    artifacts: list[str] = Field(default_factory=list)  # artifact keys contained in file


class RemoteRecord(BaseModel):
    """A Devin API object (knowledge note or playbook) created from an artifact."""

    remote_id: str
    hash: str  # canonical artifact hash at last push


class TargetLock(BaseModel):
    files: dict[str, FileRecord] = Field(default_factory=dict)  # repo-relative path -> record
    remote: dict[str, RemoteRecord] = Field(default_factory=dict)  # artifact key -> record


class Lockfile(BaseModel):
    version: int = 1
    artifacts: dict[str, str] = Field(default_factory=dict)  # artifact key -> canonical hash
    targets: dict[str, TargetLock] = Field(default_factory=dict)

    def target(self, name: str) -> TargetLock:
        if name not in self.targets:
            self.targets[name] = TargetLock()
        return self.targets[name]


def lock_path(pack_dir: Path) -> Path:
    return pack_dir / LOCK_FILENAME


def load_lockfile(pack_dir: Path) -> Lockfile:
    path = lock_path(pack_dir)
    if not path.exists():
        return Lockfile()
    return Lockfile.model_validate(json.loads(path.read_text(encoding="utf-8")))


def save_lockfile(pack_dir: Path, lock: Lockfile) -> None:
    path = lock_path(pack_dir)
    path.write_text(json.dumps(lock.model_dump(mode="json"), indent=2) + "\n", encoding="utf-8")
