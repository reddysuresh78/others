"""Provenance markers embedded in generated files.

Generated native files carry HTML comments like:

    <!-- agentpack:rule id="typescript" hash="a1b2c3d4e5f6" -->

so that (a) reverse sync can map native files back to canonical artifacts even in
composite files, and (b) metadata a target cannot express (globs, activation) survives
a round trip without silent data loss.
"""

from __future__ import annotations

import re

_MARKER_RE = re.compile(
    r"<!--\s*agentpack:(?P<kind>[a-z]+)\s*(?P<attrs>(?:\s*[a-zA-Z_]+=\"[^\"]*\")*)\s*-->"
)
_ATTR_RE = re.compile(r'([a-zA-Z_]+)="([^"]*)"')


def marker(kind: str, **attrs: str) -> str:
    parts = " ".join(f'{k}="{v}"' for k, v in attrs.items() if v is not None)
    return f"<!-- agentpack:{kind}{(' ' + parts) if parts else ''} -->"


def parse_markers(text: str) -> list[tuple[str, dict[str, str], int, int]]:
    """Return all markers as (kind, attrs, start_offset, end_offset)."""
    out = []
    for m in _MARKER_RE.finditer(text):
        attrs = dict(_ATTR_RE.findall(m.group("attrs") or ""))
        out.append((m.group("kind"), attrs, m.start(), m.end()))
    return out


def first_marker(text: str, kind: str | None = None) -> dict[str, str] | None:
    for k, attrs, _, _ in parse_markers(text):
        if kind is None or k == kind:
            return attrs
    return None


def strip_markers(text: str) -> str:
    return _MARKER_RE.sub("", text).strip()


def split_sections(text: str, kind: str) -> list[tuple[dict[str, str], str]]:
    """Split a composite file into (marker_attrs, section_body) chunks.

    Each section runs from its marker to the next marker of the same kind
    (or end of file). Content before the first marker is ignored by callers
    that handle it separately (e.g. context).
    """
    found = [(attrs, start, end) for k, attrs, start, end in parse_markers(text) if k == kind]
    sections = []
    for i, (attrs, _, end) in enumerate(found):
        stop = found[i + 1][1] if i + 1 < len(found) else len(text)
        sections.append((attrs, text[end:stop].strip()))
    return sections
