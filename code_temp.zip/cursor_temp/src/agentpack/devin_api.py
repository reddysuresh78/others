"""Devin v3 API mode: push/pull knowledge notes and playbooks.

Endpoints (bearer auth with a service-user credential, prefix cog_):
  GET/POST   /v3/organizations/{org_id}/knowledge/notes
  PUT/DELETE /v3/organizations/{org_id}/knowledge/notes/{note_id}
  GET/POST   /v3/organizations/{org_id}/playbooks
  PUT/DELETE /v3/organizations/{org_id}/playbooks/{playbook_id}

Rules (non-manual) map to knowledge notes {name, body, trigger}; skills map to
playbooks {title, body}. Remote IDs and pushed hashes are tracked in the lockfile
so pushes are idempotent and pulls can be matched back to canonical artifacts.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import httpx

from .core.lockfile import Lockfile, RemoteRecord
from .core.model import Activation, Pack, Rule, Skill
from .adapters.devin import parse_playbook, render_playbook

TARGET = "devin-api"


def trigger_text(rule: Rule) -> str:
    """Devin knowledge triggers are natural language, not globs."""
    if rule.description:
        return rule.description
    if rule.activation is Activation.GLOB and rule.globs:
        return f"Use when working with files matching: {', '.join(rule.globs)}"
    if rule.activation is Activation.ALWAYS:
        return "Always relevant; apply to every session in this project."
    return f"Apply when relevant to '{rule.id}'."


def slugify(name: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_-]+", "-", name.strip()).strip("-").lower()
    return slug or "unnamed"


@dataclass
class PushReport:
    created: list[str] = field(default_factory=list)
    updated: list[str] = field(default_factory=list)
    unchanged: list[str] = field(default_factory=list)


@dataclass
class PullReport:
    added: list[str] = field(default_factory=list)
    updated: list[str] = field(default_factory=list)
    unchanged: list[str] = field(default_factory=list)


class DevinClient:
    def __init__(self, api_base: str, org_id: str, token: str,
                 transport: httpx.BaseTransport | None = None):
        if not org_id:
            raise ValueError("Devin org_id is not set; add it under `devin.org_id` in pack.yaml")
        if not token:
            raise ValueError("Devin API token missing; set the configured API key env var")
        self.org_id = org_id
        self._client = httpx.Client(
            base_url=f"{api_base.rstrip('/')}/v3/organizations/{org_id}",
            headers={"Authorization": f"Bearer {token}"},
            timeout=30.0,
            transport=transport,
        )

    # -- raw endpoints ------------------------------------------------------

    @staticmethod
    def _items(payload, *keys: str) -> list[dict]:
        if isinstance(payload, list):
            return payload
        if isinstance(payload, dict):
            for key in (*keys, "items", "results", "data"):
                if isinstance(payload.get(key), list):
                    return payload[key]
        return []

    def list_notes(self) -> list[dict]:
        r = self._client.get("/knowledge/notes")
        r.raise_for_status()
        return self._items(r.json(), "notes", "knowledge")

    def create_note(self, name: str, body: str, trigger: str) -> dict:
        r = self._client.post("/knowledge/notes",
                              json={"name": name, "body": body, "trigger": trigger})
        r.raise_for_status()
        return r.json()

    def update_note(self, note_id: str, name: str, body: str, trigger: str) -> dict:
        r = self._client.put(f"/knowledge/notes/{note_id}",
                             json={"name": name, "body": body, "trigger": trigger})
        r.raise_for_status()
        return r.json()

    def list_playbooks(self) -> list[dict]:
        r = self._client.get("/playbooks")
        r.raise_for_status()
        return self._items(r.json(), "playbooks")

    def create_playbook(self, title: str, body: str) -> dict:
        r = self._client.post("/playbooks", json={"title": title, "body": body})
        r.raise_for_status()
        return r.json()

    def update_playbook(self, playbook_id: str, title: str, body: str) -> dict:
        r = self._client.put(f"/playbooks/{playbook_id}",
                             json={"title": title, "body": body})
        r.raise_for_status()
        return r.json()

    # -- sync operations ----------------------------------------------------

    def push(self, pack: Pack, lock: Lockfile) -> PushReport:
        report = PushReport()
        remote = lock.target(TARGET).remote

        for rule in pack.rules_for_target("devin"):
            if rule.activation is Activation.MANUAL:
                continue
            current_hash = rule.content_hash()
            record = remote.get(rule.key)
            if record and record.hash == current_hash:
                report.unchanged.append(rule.key)
                continue
            if record:
                self.update_note(record.remote_id, rule.id, rule.body, trigger_text(rule))
                remote[rule.key] = RemoteRecord(remote_id=record.remote_id, hash=current_hash)
                report.updated.append(rule.key)
            else:
                created = self.create_note(rule.id, rule.body, trigger_text(rule))
                note_id = str(created.get("note_id") or created.get("id") or "")
                remote[rule.key] = RemoteRecord(remote_id=note_id, hash=current_hash)
                report.created.append(rule.key)

        for skill in pack.skills_for_target("devin"):
            current_hash = skill.content_hash()
            record = remote.get(skill.key)
            body = render_playbook(skill)
            if record and record.hash == current_hash:
                report.unchanged.append(skill.key)
                continue
            if record:
                self.update_playbook(record.remote_id, skill.name, body)
                remote[skill.key] = RemoteRecord(remote_id=record.remote_id, hash=current_hash)
                report.updated.append(skill.key)
            else:
                created = self.create_playbook(skill.name, body)
                playbook_id = str(created.get("playbook_id") or created.get("id") or "")
                remote[skill.key] = RemoteRecord(remote_id=playbook_id, hash=current_hash)
                report.created.append(skill.key)
        return report

    def pull(self, pack: Pack, lock: Lockfile) -> PullReport:
        report = PullReport()
        remote = lock.target(TARGET).remote
        id_to_key = {rec.remote_id: key for key, rec in remote.items()}

        for note in self.list_notes():
            note_id = str(note.get("note_id") or note.get("id") or "")
            name = str(note.get("name") or "")
            body = str(note.get("body") or "")
            trigger = str(note.get("trigger") or note.get("trigger_description") or "")
            key = id_to_key.get(note_id)
            rule_id = key.removeprefix("rule:") if key and key.startswith("rule:") else slugify(name)
            existing = pack.rule_by_id(rule_id)
            rule = Rule(
                id=rule_id,
                description=trigger,
                activation=existing.activation if existing else Activation.MODEL_DECISION,
                globs=existing.globs if existing else [],
                targets=existing.targets if existing else None,
                body=body.strip(),
            )
            if existing and existing.content_hash() == rule.content_hash():
                report.unchanged.append(rule.key)
            else:
                report.updated.append(rule.key) if existing else report.added.append(rule.key)
                pack.upsert_rule(rule)
            remote[rule.key] = RemoteRecord(remote_id=note_id, hash=rule.content_hash())

        for pb in self.list_playbooks():
            playbook_id = str(pb.get("playbook_id") or pb.get("id") or "")
            title = str(pb.get("title") or "")
            body = str(pb.get("body") or "")
            key = id_to_key.get(playbook_id)
            name = key.removeprefix("skill:") if key and key.startswith("skill:") else slugify(title)
            skill = parse_playbook(name, body)
            existing_skill = pack.skill_by_name(skill.name)
            if existing_skill and existing_skill.content_hash() == skill.content_hash():
                report.unchanged.append(skill.key)
            else:
                report.updated.append(skill.key) if existing_skill else report.added.append(skill.key)
                pack.upsert_skill(skill)
            remote[skill.key] = RemoteRecord(remote_id=playbook_id, hash=skill.content_hash())
        return report
