Use it from the **root of the existing repo**. Typical flow:

### 1. Install so the CLI is available

From your agentpack checkout (or after you publish it):

```bash
# from the agentpack project:
uv sync

# then either run via the venv:
/path/to/agentpack/.venv/bin/agentpack --help

# or add that bin to PATH / use:
uv run --directory /path/to/agentpack agentpack --help
```

Once on PyPI: `uvx agentpack` or `pipx run agentpack`.

### 2. Go into the target repo

```bash
cd /path/to/your-existing-repo
```

### 3. Choose how to bootstrap

**A — You already have Cursor / Claude / Windsurf / Copilot / Devin configs**

```bash
agentpack init
agentpack import --from all          # or: --from cursor --from claude ...
```

`init` creates `.agentpack/` (and prints which tools it detected).  
`import` pulls existing rules/skills into the canonical pack.

**B — Clean repo, no agent configs yet**

```bash
agentpack init
# edit .agentpack/context/project.md, rules/*.md, skills/*/SKILL.md
```

### 4. Export native configs for every tool

```bash
agentpack export
```

That writes/updates things like `AGENTS.md`, `.cursor/rules/`, `CLAUDE.md`, `.windsurf/`, `.github/instructions/`, `.devin/playbooks/`, etc. Generated tool files (except `AGENTS.md`) are added to a managed block in `.gitignore` by default so they don’t pollute the shared repo.

### 5. Day-to-day

| Goal | Command |
|------|---------|
| See drift | `agentpack status` |
| Pull in-tool edits → canonical → re-export | `agentpack sync` |
| Conflict (both sides edited) | `agentpack sync --prefer native` or `--prefer canonical` |
| Lint rules | `agentpack doctor` |

### 6. What to commit

Commit:

- `.agentpack/` (especially `pack.yaml`, `context/`, `rules/`, `skills/`)
- `AGENTS.md` (kept out of the ignore list on purpose)

Usually **don’t** commit generated Cursor/Claude/Windsurf/Copilot dirs unless you set `gitignore_generated: false` in `.agentpack/pack.yaml`.

### 7. Optional Devin cloud sync

In `.agentpack/pack.yaml` set `devin.org_id`, then:

```bash
export DEVIN_API_KEY=cog_...
agentpack devin push    # rules → knowledge notes, skills → playbooks
agentpack devin pull    # reverse
```

---

**Minimal path for a repo that already has Cursor rules:**

```bash
cd your-repo
agentpack init
agentpack import --from cursor   # add more --from as needed
# review/edit .agentpack/
agentpack export
agentpack doctor
git add .agentpack AGENTS.md .gitignore
```