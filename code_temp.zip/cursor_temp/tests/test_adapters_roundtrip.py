"""Round-trip: export canonical -> native files -> import -> identical artifacts."""

from __future__ import annotations

import pytest

from agentpack.adapters.agentsmd import AgentsMdAdapter
from agentpack.adapters.claude import ClaudeAdapter
from agentpack.adapters.copilot import CopilotAdapter
from agentpack.adapters.cursor import CursorAdapter
from agentpack.adapters.devin import DevinAdapter
from agentpack.adapters.windsurf import WindsurfAdapter
from agentpack.core.model import Activation, Rule


def _write_all(root, result):
    for gf in result.files:
        path = root / gf.path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(gf.content, encoding="utf-8")


def _imported_rules(result):
    return {item.rule.id: item.rule for item in result.items if item.rule is not None}


def _imported_skills(result):
    return {item.skill.name: item.skill for item in result.items if item.skill is not None}


@pytest.mark.parametrize("adapter_cls", [CursorAdapter, WindsurfAdapter, CopilotAdapter, ClaudeAdapter])
def test_rule_roundtrip_preserves_metadata(tmp_path, sample_pack, adapter_cls):
    adapter = adapter_cls()
    _write_all(tmp_path, adapter.export(sample_pack, tmp_path))
    rules = _imported_rules(adapter.import_(tmp_path))

    # always-style is routed through AGENTS.md (agentsmd target enabled), not this adapter
    assert "always-style" not in rules

    ts = rules["typescript"]
    assert ts.activation == Activation.GLOB
    assert ts.globs == ["src/**/*.ts", "src/**/*.tsx"]
    assert ts.body == "- Strict mode everywhere.\n- No `any`."
    assert ts.description == "TypeScript conventions"

    api = rules["api-design"]
    assert api.activation == Activation.MODEL_DECISION
    assert api.description == "REST API conventions for endpoint work"

    manual = rules["scratchpad"]
    assert manual.activation == Activation.MANUAL


@pytest.mark.parametrize(
    "adapter_cls", [CursorAdapter, WindsurfAdapter, CopilotAdapter, ClaudeAdapter, DevinAdapter]
)
def test_skill_roundtrip_preserves_sections(tmp_path, sample_pack, adapter_cls):
    adapter = adapter_cls()
    _write_all(tmp_path, adapter.export(sample_pack, tmp_path))
    skills = _imported_skills(adapter.import_(tmp_path))

    skill = skills["security-review"]
    assert "1. Read the diff." in skill.body
    assert skill.specifications == ["A findings report exists"]
    assert skill.advice == ["Focus on injection risks"]
    assert skill.forbidden_actions == ["Do not push to main"]
    assert skill.required_from_user == ["Target branch name"]


def test_agentsmd_roundtrip(tmp_path, sample_pack):
    adapter = AgentsMdAdapter()
    _write_all(tmp_path, adapter.export(sample_pack, tmp_path))
    result = adapter.import_(tmp_path)

    contexts = [item.context for item in result.items if item.context is not None]
    assert len(contexts) == 1
    assert "A sample project." in contexts[0]

    rules = _imported_rules(result)
    assert list(rules) == ["always-style"]  # only always rules live in AGENTS.md
    assert rules["always-style"].activation == Activation.ALWAYS
    assert rules["always-style"].body == "- Use spaces, not tabs."


def test_agentsmd_handwritten_import(tmp_path):
    (tmp_path / "AGENTS.md").write_text("# My project\n\nUse pnpm.\n", encoding="utf-8")
    result = AgentsMdAdapter().import_(tmp_path)
    contexts = [i.context for i in result.items if i.context is not None]
    assert contexts == ["# My project\n\nUse pnpm."]


def test_cursor_infers_unmarked_native_rule(tmp_path):
    rules_dir = tmp_path / ".cursor/rules"
    rules_dir.mkdir(parents=True)
    (rules_dir / "react.mdc").write_text(
        "---\ndescription: React rules\nglobs: '**/*.tsx'\nalwaysApply: false\n---\n\nUse hooks.\n",
        encoding="utf-8",
    )
    rules = _imported_rules(CursorAdapter().import_(tmp_path))
    rule = rules["react"]
    assert rule.activation == Activation.GLOB
    assert rule.globs == ["**/*.tsx"]
    assert rule.body == "Use hooks."


def test_windsurf_char_limit_warning(tmp_path, sample_pack):
    sample_pack.upsert_rule(
        Rule(id="huge", activation=Activation.GLOB, globs=["**/*"], body="x" * 13000)
    )
    result = WindsurfAdapter().export(sample_pack, tmp_path)
    assert any("12000 limit" in n.message.replace(",", "") for n in result.notes)


def test_copilot_glob_maps_to_applyto(tmp_path, sample_pack):
    result = CopilotAdapter().export(sample_pack, tmp_path)
    ts_file = next(f for f in result.files if "typescript.instructions.md" in f.path)
    assert 'applyTo: src/**/*.ts,src/**/*.tsx' in ts_file.content


def test_claude_claude_md_imports_agents_md(tmp_path, sample_pack):
    result = ClaudeAdapter().export(sample_pack, tmp_path)
    claude_md = next(f for f in result.files if f.path == "CLAUDE.md")
    assert "@AGENTS.md" in claude_md.content
    assert "@.claude/rules/typescript.md" in claude_md.content
