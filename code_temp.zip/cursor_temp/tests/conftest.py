from __future__ import annotations

import pytest

from agentpack.core.model import Activation, Manifest, Pack, Rule, Skill


@pytest.fixture
def sample_pack() -> Pack:
    return Pack(
        manifest=Manifest(project="acme"),
        context="# Acme\n\nA sample project.\n\n## Setup\n- `make install`",
        rules=[
            Rule(
                id="always-style",
                description="Universal code style",
                activation=Activation.ALWAYS,
                body="- Use spaces, not tabs.",
            ),
            Rule(
                id="typescript",
                description="TypeScript conventions",
                activation=Activation.GLOB,
                globs=["src/**/*.ts", "src/**/*.tsx"],
                body="- Strict mode everywhere.\n- No `any`.",
            ),
            Rule(
                id="api-design",
                description="REST API conventions for endpoint work",
                activation=Activation.MODEL_DECISION,
                body="- Version every endpoint.",
            ),
            Rule(
                id="scratchpad",
                activation=Activation.MANUAL,
                body="- Manual-only notes.",
            ),
        ],
        skills=[
            Skill(
                name="security-review",
                description="Run an OWASP-aligned security review of the diff",
                allowed_tools=["Read", "Grep"],
                body="1. Read the diff.\n2. Check OWASP top 10.\n3. Report findings.",
                specifications=["A findings report exists"],
                advice=["Focus on injection risks"],
                forbidden_actions=["Do not push to main"],
                required_from_user=["Target branch name"],
            ),
        ],
    )
