"""Devin v3 API push/pull against a mocked httpx transport."""

from __future__ import annotations

import json

import httpx
import pytest

from agentpack.core.lockfile import Lockfile
from agentpack.core.model import Activation
from agentpack.devin_api import DevinClient, trigger_text


class FakeDevin:
    """Minimal in-memory Devin v3 API."""

    def __init__(self):
        self.notes: dict[str, dict] = {}
        self.playbooks: dict[str, dict] = {}
        self._seq = 0

    def _next_id(self, prefix: str) -> str:
        self._seq += 1
        return f"{prefix}-{self._seq}"

    def handler(self, request: httpx.Request) -> httpx.Response:
        path = request.url.path
        body = json.loads(request.content) if request.content else {}
        if path.endswith("/knowledge/notes") and request.method == "POST":
            note_id = self._next_id("note")
            self.notes[note_id] = {"note_id": note_id, **body}
            return httpx.Response(200, json=self.notes[note_id])
        if path.endswith("/knowledge/notes") and request.method == "GET":
            return httpx.Response(200, json={"notes": list(self.notes.values())})
        if "/knowledge/notes/" in path and request.method == "PUT":
            note_id = path.rsplit("/", 1)[-1]
            self.notes[note_id].update(body)
            return httpx.Response(200, json=self.notes[note_id])
        if path.endswith("/playbooks") and request.method == "POST":
            pb_id = self._next_id("playbook")
            self.playbooks[pb_id] = {"playbook_id": pb_id, **body}
            return httpx.Response(200, json=self.playbooks[pb_id])
        if path.endswith("/playbooks") and request.method == "GET":
            return httpx.Response(200, json={"playbooks": list(self.playbooks.values())})
        if "/playbooks/" in path and request.method == "PUT":
            pb_id = path.rsplit("/", 1)[-1]
            self.playbooks[pb_id].update(body)
            return httpx.Response(200, json=self.playbooks[pb_id])
        return httpx.Response(404)


@pytest.fixture
def fake_devin():
    return FakeDevin()


@pytest.fixture
def client(fake_devin):
    return DevinClient(
        "https://api.devin.ai", "org-test", "cog_token",
        transport=httpx.MockTransport(fake_devin.handler),
    )


def test_push_creates_notes_and_playbooks(client, fake_devin, sample_pack):
    lock = Lockfile()
    report = client.push(sample_pack, lock)

    # manual rule excluded; always + glob + model_decision pushed
    assert sorted(report.created) == [
        "rule:always-style", "rule:api-design", "rule:typescript", "skill:security-review",
    ]
    assert len(fake_devin.notes) == 3
    assert len(fake_devin.playbooks) == 1

    ts_note = next(n for n in fake_devin.notes.values() if n["name"] == "typescript")
    assert ts_note["trigger"] == "TypeScript conventions"
    pb = next(iter(fake_devin.playbooks.values()))
    assert pb["title"] == "security-review"
    assert "## Procedure" in pb["body"]
    assert "## Forbidden Actions" in pb["body"]


def test_push_is_idempotent(client, sample_pack):
    lock = Lockfile()
    client.push(sample_pack, lock)
    report = client.push(sample_pack, lock)
    assert report.created == [] and report.updated == []
    assert len(report.unchanged) == 4


def test_push_updates_changed_rule(client, fake_devin, sample_pack):
    lock = Lockfile()
    client.push(sample_pack, lock)
    rule = sample_pack.rule_by_id("typescript")
    rule.body += "\n- new line"
    sample_pack.upsert_rule(rule)
    report = client.push(sample_pack, lock)
    assert report.updated == ["rule:typescript"]
    ts_note = next(n for n in fake_devin.notes.values() if n["name"] == "typescript")
    assert "new line" in ts_note["body"]


def test_pull_roundtrip(client, sample_pack):
    lock = Lockfile()
    client.push(sample_pack, lock)

    # Simulate an edit made in the Devin dashboard.
    import copy
    edited_pack = copy.deepcopy(sample_pack)
    report = client.pull(edited_pack, lock)
    assert report.unchanged  # nothing changed remotely yet -> mostly unchanged

    # Remote edit: change the note body directly.
    note_id = lock.target("devin-api").remote["rule:typescript"].remote_id
    client.update_note(note_id, "typescript", "- remote edit", "TypeScript conventions")
    report = client.pull(edited_pack, lock)
    assert "rule:typescript" in report.updated
    assert edited_pack.rule_by_id("typescript").body == "- remote edit"
    # Activation/globs preserved from canonical (API cannot express them).
    assert edited_pack.rule_by_id("typescript").activation == Activation.GLOB


def test_trigger_text_derivation(sample_pack):
    glob_rule = sample_pack.rule_by_id("typescript")
    glob_rule.description = ""
    assert "src/**/*.ts" in trigger_text(glob_rule)
    always = sample_pack.rule_by_id("always-style")
    always.description = ""
    assert "every session" in trigger_text(always)
