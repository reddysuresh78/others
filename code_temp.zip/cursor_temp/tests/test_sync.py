"""End-to-end engine tests: export, status, three-way sync, conflicts, gitignore."""

from __future__ import annotations

from agentpack.core.model import Activation
from agentpack.core.pack import load_pack, save_pack
from agentpack.engine import compute_status, run_export, run_import, run_sync


def _setup(tmp_path, sample_pack):
    save_pack(tmp_path, sample_pack)
    run_export(tmp_path)
    return tmp_path


def test_export_writes_all_targets(tmp_path, sample_pack):
    _setup(tmp_path, sample_pack)
    assert (tmp_path / "AGENTS.md").exists()
    assert (tmp_path / ".cursor/rules/typescript.mdc").exists()
    assert (tmp_path / "CLAUDE.md").exists()
    assert (tmp_path / ".claude/skills/security-review/SKILL.md").exists()
    assert (tmp_path / ".windsurf/rules/typescript.md").exists()
    assert (tmp_path / ".github/instructions/typescript.instructions.md").exists()
    assert (tmp_path / ".github/prompts/security-review.prompt.md").exists()
    assert (tmp_path / ".devin/playbooks/security-review.md").exists()

    gitignore = (tmp_path / ".gitignore").read_text()
    assert ".cursor/rules/typescript.mdc" in gitignore
    assert "AGENTS.md" not in gitignore  # committed, not ignored


def test_export_idempotent(tmp_path, sample_pack):
    _setup(tmp_path, sample_pack)
    report = run_export(tmp_path)
    assert report.written == []
    assert all(s.state == "up-to-date" for s in compute_status(tmp_path))


def test_native_edit_flows_back_to_canonical(tmp_path, sample_pack):
    _setup(tmp_path, sample_pack)
    mdc = tmp_path / ".cursor/rules/typescript.mdc"
    mdc.write_text(mdc.read_text().replace("No `any`.", "No `any`. Prefer `unknown`."))

    assert any(s.state == "modified-in-tool" for s in compute_status(tmp_path))
    report = run_sync(tmp_path)
    assert any("rule:typescript" in line for line in report.imported)

    pack = load_pack(tmp_path)
    rule = pack.rule_by_id("typescript")
    assert "Prefer `unknown`." in rule.body
    assert rule.activation == Activation.GLOB  # metadata preserved through sync
    assert rule.globs == ["src/**/*.ts", "src/**/*.tsx"]

    # The edit propagated to other tools.
    assert "Prefer `unknown`." in (tmp_path / ".windsurf/rules/typescript.md").read_text()
    assert "Prefer `unknown`." in (
        tmp_path / ".github/instructions/typescript.instructions.md"
    ).read_text()


def test_canonical_edit_flows_to_native(tmp_path, sample_pack):
    _setup(tmp_path, sample_pack)
    pack = load_pack(tmp_path)
    rule = pack.rule_by_id("api-design")
    rule.body += "\n- Paginate all list endpoints."
    pack.upsert_rule(rule)
    save_pack(tmp_path, pack)

    assert any(s.state == "canonical-changed" for s in compute_status(tmp_path))
    run_sync(tmp_path)
    assert "Paginate all list endpoints." in (
        tmp_path / ".cursor/rules/api-design.mdc"
    ).read_text()
    assert all(s.state == "up-to-date" for s in compute_status(tmp_path))


def test_conflict_detected_and_resolved(tmp_path, sample_pack):
    _setup(tmp_path, sample_pack)

    # Edit both sides of the same rule.
    pack = load_pack(tmp_path)
    rule = pack.rule_by_id("typescript")
    rule.body += "\n- canonical edit"
    pack.upsert_rule(rule)
    save_pack(tmp_path, pack)
    mdc = tmp_path / ".cursor/rules/typescript.mdc"
    mdc.write_text(mdc.read_text() + "\n- native edit\n")

    report = run_sync(tmp_path)
    assert any("rule:typescript" in c for c in report.conflicts)
    # Canonical edit survived; conflict was not auto-resolved.
    assert "canonical edit" in load_pack(tmp_path).rule_by_id("typescript").body

    # Resolve preferring native.
    mdc.write_text(mdc.read_text() + "\n- native wins\n")
    report = run_sync(tmp_path, prefer="native")
    assert not report.conflicts
    assert "native wins" in load_pack(tmp_path).rule_by_id("typescript").body


def test_removed_rule_deletes_generated_files(tmp_path, sample_pack):
    _setup(tmp_path, sample_pack)
    pack = load_pack(tmp_path)
    pack.rules = [r for r in pack.rules if r.id != "scratchpad"]
    save_pack(tmp_path, pack)
    report = run_export(tmp_path)
    assert any("scratchpad" in p for p in report.removed)
    assert not (tmp_path / ".cursor/rules/scratchpad.mdc").exists()


def test_bootstrap_import_from_existing_configs(tmp_path):
    # A repo that already uses Cursor and Claude, no .agentpack yet.
    rules_dir = tmp_path / ".cursor/rules"
    rules_dir.mkdir(parents=True)
    (rules_dir / "python.mdc").write_text(
        "---\ndescription: Python rules\nglobs: '**/*.py'\nalwaysApply: false\n---\n\nUse type hints.\n"
    )
    (tmp_path / "CLAUDE.md").write_text("# Legacy\n\nAlways run make lint.\n")

    imported, _ = run_import(tmp_path, ["cursor", "claude"])
    assert any("rule:python" in i for i in imported)
    assert any("rule:claude-md-imported" in i for i in imported)

    pack = load_pack(tmp_path)
    assert pack.rule_by_id("python").globs == ["**/*.py"]
    assert pack.rule_by_id("claude-md-imported").activation == Activation.ALWAYS
