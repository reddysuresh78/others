from __future__ import annotations

from agentpack.core.pack import load_pack, save_pack


def test_pack_save_load_roundtrip(tmp_path, sample_pack):
    save_pack(tmp_path, sample_pack)
    loaded = load_pack(tmp_path)

    assert loaded.manifest.project == "acme"
    assert loaded.context == sample_pack.context.strip()
    assert [r.id for r in loaded.rules] == sorted(r.id for r in sample_pack.rules)
    for original in sample_pack.rules:
        loaded_rule = loaded.rule_by_id(original.id)
        assert loaded_rule is not None
        assert loaded_rule.activation == original.activation
        assert loaded_rule.globs == original.globs
        assert loaded_rule.body == original.body.strip()

    skill = loaded.skill_by_name("security-review")
    assert skill is not None
    assert skill.allowed_tools == ["Read", "Grep"]
    assert skill.specifications == ["A findings report exists"]
    assert skill.forbidden_actions == ["Do not push to main"]
    assert skill.required_from_user == ["Target branch name"]


def test_artifact_hash_stability(sample_pack):
    h1 = sample_pack.artifact_hashes()
    h2 = sample_pack.artifact_hashes()
    assert h1 == h2
    sample_pack.rules[0].body += "\n- changed"
    assert sample_pack.artifact_hashes() != h1
