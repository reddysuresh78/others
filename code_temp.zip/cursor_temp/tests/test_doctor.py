from __future__ import annotations

from agentpack.core.model import Activation, Pack, Rule, Skill
from agentpack.doctor import run_doctor


def test_doctor_clean_pack(tmp_path, sample_pack):
    (tmp_path / "src").mkdir()
    (tmp_path / "src/app.ts").write_text("export {}\n")
    findings = run_doctor(tmp_path, sample_pack)
    assert not any(f.level == "error" for f in findings)


def test_doctor_flags_problems(tmp_path):
    pack = Pack(
        context="",
        rules=[
            Rule(id="dead-glob", activation=Activation.GLOB,
                 globs=["nonexistent/**/*.zig"], body="x"),
            Rule(id="no-globs", activation=Activation.GLOB, body="x"),
            Rule(id="no-desc", activation=Activation.MODEL_DECISION, body="x"),
            Rule(id="empty", activation=Activation.ALWAYS, body="  "),
        ],
        skills=[Skill(name="vague", body="")],
    )
    findings = run_doctor(tmp_path, pack)
    messages = {(f.subject, f.level) for f in findings}
    assert ("rule:no-globs", "error") in messages
    assert ("rule:empty", "error") in messages
    assert ("skill:vague", "error") in messages
    assert any(f.subject == "rule:dead-glob" and "dead glob" in f.message for f in findings)
    assert any(f.subject == "rule:no-desc" and f.level == "warning" for f in findings)
    assert any(f.subject == "context" for f in findings)
