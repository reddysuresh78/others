# agentpack

Tool-agnostic management of AI coding agent **rules, skills, and playbooks** with true
**bidirectional sync**. Keep one canonical source of truth in `.agentpack/` and use it
from **Cursor, Claude Code, Windsurf, GitHub Copilot, and Devin** — edits made in any
tool flow back to the canonical pack and out to every other tool.

## Why

Every AI coding tool has its own configuration format:

| Tool | Rules | Skills / procedures |
|---|---|---|
| Cursor | `.cursor/rules/*.mdc` (frontmatter: `globs`, `alwaysApply`) | `.cursor/commands/*.md` |
| Claude Code | `CLAUDE.md` (+ `@imports`) | `.claude/skills/*/SKILL.md` |
| Windsurf | `.windsurf/rules/*.md` (frontmatter: `trigger`) | `.windsurf/workflows/*.md` |
| GitHub Copilot | `.github/copilot-instructions.md`, `.github/instructions/*.instructions.md` (`applyTo`) | `.github/prompts/*.prompt.md` |
| Devin | `AGENTS.md` + Knowledge notes (cloud) | Playbooks (cloud, via v3 API) |

agentpack stores everything once, in a superset format, and converts both ways.

## Install / run

```bash
uv sync                     # from a checkout
uv run agentpack --help

# once published to PyPI:
uvx agentpack --help
pipx run agentpack --help
```

## Quick start

```bash
# 1. Scaffold the canonical pack (detects existing tool configs)
agentpack init

# 2. Or bootstrap from what you already have
agentpack import --from cursor --from claude     # or: --from all

# 3. Generate native configs for every tool
agentpack export

# 4. See what's drifted
agentpack status

# 5. Bidirectional sync: pull in-tool edits back, re-export everywhere
agentpack sync
agentpack sync --prefer native    # resolve conflicts in favor of in-tool edits

# 6. Lint the pack (dead globs, missing descriptions, oversized rules)
agentpack doctor

# 7. Devin cloud sync (knowledge notes + playbooks via the v3 API)
export DEVIN_API_KEY=cog_...      # service-user credential
agentpack devin push
agentpack devin pull
```

## Canonical format

```
.agentpack/
├── pack.yaml                # project, enabled targets, Devin org config
├── context/project.md       # global context -> AGENTS.md body
├── rules/<id>.md            # frontmatter: description, activation, globs, targets
├── skills/<name>/SKILL.md   # frontmatter: description, allowed-tools, devin sections
└── lock.json                # export hashes powering three-way sync (generated)
```

A rule:

```markdown
---
id: typescript
description: TypeScript conventions
activation: glob            # always | glob | model_decision | manual
globs:
  - src/**/*.ts
  - src/**/*.tsx
---

- Strict mode everywhere.
- No `any`.
```

A skill (SKILL.md-compatible, with Devin playbook extensions):

```markdown
---
name: security-review
description: Run an OWASP-aligned security review of the diff
allowed-tools:
  - Read
  - Grep
specifications:
  - A findings report exists
forbidden_actions:
  - Do not push to main
required_from_user:
  - Target branch name
---

1. Read the diff.
2. Check OWASP top 10.
3. Report findings.
```

## How activation maps per tool

| canonical | Cursor | Windsurf | Copilot | Claude Code | Devin |
|---|---|---|---|---|---|
| `always` | via AGENTS.md | via AGENTS.md | via AGENTS.md | via `@AGENTS.md` | via AGENTS.md |
| `glob` | `globs` | `trigger: glob` | `applyTo` | annotated, always-on * | knowledge trigger text * |
| `model_decision` | `description` | `trigger: model_decision` | `description` * | always-on * | knowledge `trigger` |
| `manual` | `@mention` | `trigger: manual` | manual attach * | always-on * | not pushed |

`*` = lossy conversion; agentpack prints a **fidelity note** for every one, and embeds
the original metadata as provenance markers (`<!-- agentpack:rule ... -->`) inside the
generated files, so nothing is silently lost and reverse sync restores it exactly.

## How sync works

`lock.json` records the hash of every generated file at export time, plus every
canonical artifact hash. On `agentpack sync`, each file is classified:

- native changed, canonical unchanged -> **imported** back into `.agentpack/`
- canonical changed, native unchanged -> **re-exported**
- both changed -> **conflict**: reported and skipped until you pass
  `--prefer canonical` or `--prefer native` (never auto-overwritten)

Generated files (except `AGENTS.md`, which is meant to be committed) are added to a
managed `.gitignore` block so each developer can use their own tool without polluting
the repo. Set `gitignore_generated: false` in `pack.yaml` to commit them instead.

## Development

```bash
uv sync
uv run pytest
```
