package gctest;

public class GCCreator {
 	
	public static void main(String[] args) {
		
		int max = Integer.MAX_VALUE;
		
		System.out.println("Count " + args.length);
		
		if(args.length== 1) {
			max = Integer.parseInt(args[0]);
		}
	 
		System.out.println("Starting the string creation now for max " + max);
		for(int i=0;i<max; i++ ) {
			new String("Test string to force gc at regular intervals " + i);
		}
		System.out.println("Ended the string creation");
	}

}
