package logwriter;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class LogWriter {
 	
	public static void main(String[] args) throws IOException {
		
		List<String> lines = new ArrayList<>();
        BufferedReader br = null;  
        
        FileWriter f= new FileWriter(args[0]);
 
        while(true) {
	        try {
	            br = new BufferedReader(new InputStreamReader(System.in));
	            String newLine= br.readLine();
	            if(newLine != null) {
	            	lines.add(newLine);
	            
		            if(lines.size()>=2) {
		             
		            	for(String line: lines)
		            		f.write(line+"\n");
		            	
		            	f.flush();
		            	
		            	lines.clear();
		            }
	            }
		 
 	        }
	        catch (IOException e) {
	            System.out.println(e);
	            break;
	        }
	        
        }
        f.close();
	}

}
