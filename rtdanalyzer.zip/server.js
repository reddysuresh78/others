var express=require('express');
var recommender=require('./getall');
var app=express();

app.use(express.static('public'))

app.get('/getRecommendations',function(req,res)
{
 
    recommender.processAll(req.query.day, req.query.month, req.query.year, res);
     
});
var server=app.listen(3000,function() {});